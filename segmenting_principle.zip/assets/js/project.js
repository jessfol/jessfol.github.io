if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si500:{
name:'Paragraph_1',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si500c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"left":10,"right":10,"top":292,"bottom":292},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si508',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"padding":{"left":10,"right":10,"top":292,"bottom":292},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'DEFAULT_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si500c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:500,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si500',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si508:{
name:'Paragraph_Group_1',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si508c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si500',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si516',
t:1250
}
,{
n:'si536',
t:1250
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si500',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si508c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:508,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si508',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si516:{
name:'Text_1',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si516c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{},"meta":{"textHighlightEnable":true,"textOutlineEnable":true,"textShadowEnable":true}}}',
parentGroup:'si508',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
524:{
efdu:0.6,
efde:0,
efa:3,
efre:1,
efdi:16,
efe:203,
efty:0,
eftd:0,
efdaa:false,
efva:[]
}

}
,
eflh:[524],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9k0kt","text":"    The Segmenting Principle","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"textShadow:none"},{"offset":0,"length":28,"style":"textShadowX:0px"},{"offset":0,"length":28,"style":"fontStretch:normal"},{"offset":0,"length":28,"style":"fontType:regular"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"textShadowY:4px"},{"offset":0,"length":28,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":28,"style":"desktop-fontSize:80"},{"offset":0,"length":28,"style":"lineHeight:135%"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textTransform:none"},{"offset":0,"length":28,"style":"textShadowOpacity:none"},{"offset":0,"length":28,"style":"overridden:true"},{"offset":0,"length":28,"style":"textDecoration:none"},{"offset":0,"length":28,"style":"borderBottomStyle:none"},{"offset":0,"length":28,"style":"mobile-fontSize:60"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"fontWeight:normal"},{"offset":0,"length":28,"style":"textShadowBlur:8px"},{"offset":0,"length":28,"style":"color:#34623F"},{"offset":0,"length":28,"style":"tablet-fontSize:72"},{"offset":0,"length":28,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"fontStyle:normal"},{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"fontFamily:Krungthep"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"letterSpacing:-4%"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"hlnke:true"},{"offset":0,"length":28,"style":"defaultTextShadow:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"10%","presetId":"text-heading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[516]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si516c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:516,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si516',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si536:{
name:'Text_3',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si536c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si508',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"afen4","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":309,"style":"hlnk:"},{"offset":0,"length":309,"style":"hlnkt:wp"},{"offset":0,"length":309,"style":"opacity:0"},{"offset":0,"length":309,"style":"textOutlineEnable:false"},{"offset":0,"length":309,"style":"hlnke:true"},{"offset":0,"length":309,"style":"backgroundColor:unset"},{"offset":0,"length":309,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":309,"style":"textHighlightEnable:false"},{"offset":0,"length":309,"style":"textShadowEnable:false"},{"offset":0,"length":309,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[536]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si536c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:536,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si536',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
Slide388:{
lb:'Welcome Title',
id:388,
from:1,
to:90,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide388c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si500',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/0478.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:478,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide388c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:388,
dn:'Slide388',
visible:'1'
},
si1337:{
name:'Character_Block_1',
type:1268,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si1337c',
tag:'character-block-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":654,"autoFit":false,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":38,"bottom":38},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"32px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column","gap":"24px"},"mobile_landscape":{"display":"flex","flexDirection":"row","gap":"32px"}},"appearanceProperties":{}}',
retainState:false,
immo:false,
apsn:'Slide480',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1345',
t:1268
}
,{
n:'si1367',
t:1268
}
]
,
containerType:'character-block',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":654,"autoFit":false,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":38,"bottom":38},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"32px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column","gap":"24px"},"mobile_landscape":{"display":"flex","flexDirection":"row","gap":"32px"}},"appearanceProperties":{}}',
option:'DEFAULT_SINGLE_CHARACTER_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1337c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1337,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1337',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1345:{
name:'character-image_1',
type:1268,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si1345c',
tag:'character-container-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"padding":{"top":10,"bottom":10,"left":2,"right":2},"visibilityInfo":{"character-image":true},"alignment":{},"canBeCard":false,"imageBehavior":"IG_FIT","isCharacterImageContainer":true,"designOptionStyles":{"all":{"width":"280px"},"tablet":{},"mobile":{"width":"150px","alignSelf":"center"}}}',
parentGroup:'si1337',
retainState:false,
immo:false,
apsn:'Slide480',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1355',
t:15
}
]
,
containerType:'character-container-1',
widgetProps:'{"shouldRender":true,"padding":{"top":10,"bottom":10,"left":2,"right":2},"visibilityInfo":{"character-image":true},"alignment":{},"canBeCard":false,"imageBehavior":"IG_FIT","isCharacterImageContainer":true,"designOptionStyles":{"all":{"width":"280px"},"tablet":{},"mobile":{"width":"150px","alignSelf":"center"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1337',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1345c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1345,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1345',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1355:{
name:'Melanie15',
type:15,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si1355c',
tag:'character-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1345',
retainState:false,
immo:false,
apsn:'Slide480',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:867,
irh:2000,
w:867,
h:2000,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1355]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1355c:{
b:[0,0,867,2000],
fh:false,
fw:false,
uid:1355,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/01411.png',
dn:'si1355',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,868,2001],
vb:[-1,-1,868,2001]
},
si1367:{
name:'Character_Group_1',
type:1268,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si1367c',
tag:'character-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":true,"card":false},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":true,"color":"var(--c6)","size":3,"type":1},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"color":"var(--design-option-color3)","type":1,"enabled":true}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si1337',
retainState:false,
immo:false,
apsn:'Slide480',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1375',
t:1250
}
,{
n:'si1385',
t:1250
}
,{
n:'si1395',
t:29
}
]
,
containerType:'character-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":true,"card":false},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":true,"color":"var(--c6)","size":3,"type":1},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"color":"var(--design-option-color3)","type":1,"enabled":true}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1337',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1367c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1367,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1367',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1375:{
name:'Text_7',
type:1250,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si1375c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si1367',
retainState:false,
immo:false,
apsn:'Slide480',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9i41m","text":"Objectives","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"fontType:regular"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textShadowY:4px"},{"offset":0,"length":10,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textTransform:none"},{"offset":0,"length":10,"style":"desktop-fontSize:60"},{"offset":0,"length":10,"style":"lineHeight:110%"},{"offset":0,"length":10,"style":"textShadowOpacity:none"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"fontWeight:bold"},{"offset":0,"length":10,"style":"mobile-fontSize:60"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"textShadowBlur:8px"},{"offset":0,"length":10,"style":"color:#34623F"},{"offset":0,"length":10,"style":"tablet-fontSize:72"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"fontFamily:Krungthep"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"letterSpacing:-4%"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"defaultTextShadow:none"},{"offset":0,"length":10,"style":"textShadow:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1375]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1375c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1375,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1375',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1385:{
name:'Text_8',
type:1250,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si1385c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1367',
retainState:false,
immo:false,
apsn:'Slide480',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"v16i","text":"Learners will be able to explain the segmenting principle in instructional design and its importance in improving learning outcomes.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":132,"style":"hlnke:true"},{"offset":0,"length":132,"style":"defaultTextShadow:none"},{"offset":0,"length":132,"style":"textShadow:none"},{"offset":0,"length":132,"style":"mobile-fontSize:18"},{"offset":0,"length":132,"style":"textShadowX:0px"},{"offset":0,"length":132,"style":"fontStretch:normal"},{"offset":0,"length":132,"style":"fontType:regular"},{"offset":0,"length":132,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":132,"style":"textShadowY:4px"},{"offset":0,"length":132,"style":"letterSpacing:3%"},{"offset":0,"length":132,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":132,"style":"textHighlightEnable:false"},{"offset":0,"length":132,"style":"textTransform:none"},{"offset":0,"length":132,"style":"color:#020C1C"},{"offset":0,"length":132,"style":"textShadowOpacity:none"},{"offset":0,"length":132,"style":"overridden:true"},{"offset":0,"length":132,"style":"textDecoration:none"},{"offset":0,"length":132,"style":"lineHeight:130%"},{"offset":0,"length":132,"style":"borderBottomStyle:none"},{"offset":0,"length":132,"style":"textShadowEnable:false"},{"offset":0,"length":132,"style":"hlnk:"},{"offset":0,"length":132,"style":"fontWeight:normal"},{"offset":0,"length":132,"style":"textShadowBlur:8px"},{"offset":0,"length":132,"style":"desktop-fontSize:24"},{"offset":0,"length":132,"style":"fontFamily:Arial"},{"offset":0,"length":132,"style":"backgroundColor:unset"},{"offset":0,"length":132,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":132,"style":"hlnkt:wp"},{"offset":0,"length":132,"style":"fontStyle:normal"},{"offset":0,"length":132,"style":"tablet-fontSize:20"},{"offset":0,"length":132,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":132,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":132,"style":"textOutlineEnable:false"},{"offset":0,"length":132,"style":"opacity:1"},{"offset":0,"length":132,"style":"defaultTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-2","listSize":"100%"}},{"key":"2rupb","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-2","listSize":"100%"}},{"key":"60e9s","text":"Learners will be able to demonstrate their understanding of the segmenting principle by answering three knowledge check questions, correctly identifying how segmenting improves learning, its benefits, and how to apply it in instructional design.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":245,"style":"textOutlineEnable:false"},{"offset":0,"length":245,"style":"opacity:1"},{"offset":0,"length":245,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":245,"style":"hlnke:true"},{"offset":0,"length":245,"style":"defaultTextShadow:none"},{"offset":0,"length":245,"style":"textShadow:none"},{"offset":0,"length":245,"style":"mobile-fontSize:18"},{"offset":0,"length":245,"style":"textShadowX:0px"},{"offset":0,"length":245,"style":"fontStretch:normal"},{"offset":0,"length":245,"style":"fontType:regular"},{"offset":0,"length":245,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":245,"style":"textShadowY:4px"},{"offset":0,"length":245,"style":"letterSpacing:3%"},{"offset":0,"length":245,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":245,"style":"textHighlightEnable:false"},{"offset":0,"length":245,"style":"textTransform:none"},{"offset":0,"length":245,"style":"color:#020C1C"},{"offset":0,"length":245,"style":"textShadowOpacity:none"},{"offset":0,"length":245,"style":"overridden:true"},{"offset":0,"length":245,"style":"textDecoration:none"},{"offset":0,"length":245,"style":"lineHeight:130%"},{"offset":0,"length":245,"style":"borderBottomStyle:none"},{"offset":0,"length":245,"style":"textShadowEnable:false"},{"offset":0,"length":245,"style":"hlnk:"},{"offset":0,"length":245,"style":"fontWeight:normal"},{"offset":0,"length":245,"style":"textShadowBlur:8px"},{"offset":0,"length":245,"style":"desktop-fontSize:24"},{"offset":0,"length":245,"style":"fontFamily:Arial"},{"offset":0,"length":245,"style":"backgroundColor:unset"},{"offset":0,"length":245,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":245,"style":"hlnkt:wp"},{"offset":0,"length":245,"style":"fontStyle:normal"},{"offset":0,"length":245,"style":"tablet-fontSize:20"},{"offset":0,"length":245,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":245,"style":"WebkitTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1385]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1385c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1385,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1385',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1395:{
name:'Button_7',
type:29,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si1395c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"500pj","text":"Let\'s Begin","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e762n","text":"Let\'s Begin","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","designOptionStyles":{"all":{"paddingTop":"32px"},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3bh10","text":"Let\'s Begin","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"q41s","text":"Let\'s Begin","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2nnjq","text":"Let\'s Begin","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si1367',
retainState:false,
immo:false,
apsn:'Slide480',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(1451);"]]},{"then":[["cp.goToSlide(1427,);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1395]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1395c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1395,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1395',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide480:{
lb:'Objectives',
id:480,
from:91,
to:180,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide480c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si1337',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/0498.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:498,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1451:{
ts:''
}
,
1427:{
ts:''
}

}

},
Slide480c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:480,
dn:'Slide480',
visible:'1'
},
si2023:{
name:'Character_Block_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si2023c',
tag:'character-block-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":688,"autoFit":true,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":40,"bottom":40},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"32px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column","gap":"24px"},"mobile_landscape":{"display":"flex","flexDirection":"row","gap":"32px"}},"appearanceProperties":{}}',
retainState:false,
immo:false,
apsn:'Slide1428',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2031',
t:1268
}
,{
n:'si2051',
t:1268
}
]
,
containerType:'character-block',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":688,"autoFit":true,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":40,"bottom":40},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"32px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column","gap":"24px"},"mobile_landscape":{"display":"flex","flexDirection":"row","gap":"32px"}},"appearanceProperties":{}}',
option:'DEFAULT_SINGLE_CHARACTER_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2023c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2023,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2023',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2031:{
name:'character-image_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si2031c',
tag:'character-container-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"width":"280px"},"tablet":{},"mobile":{"width":"150px","alignSelf":"center"}}}',
parentGroup:'si2023',
retainState:false,
immo:false,
apsn:'Slide1428',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2039',
t:15
}
]
,
containerType:'character-container-1',
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"width":"280px"},"tablet":{},"mobile":{"width":"150px","alignSelf":"center"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2023',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2031c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2031,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2031',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2039:{
name:'Melanie38',
type:15,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si2039c',
tag:'character-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2031',
retainState:false,
immo:false,
apsn:'Slide1428',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:731,
irh:2000,
w:731,
h:2000,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2039]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2039c:{
b:[0,0,731,2000],
fh:false,
fw:false,
uid:2039,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/02095.png',
dn:'si2039',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,732,2001],
vb:[-1,-1,732,2001]
},
si2051:{
name:'Character_Group_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si2051c',
tag:'character-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":true,"card":false},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c6)","size":3,"type":1},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"color":"var(--design-option-color3)","type":1,"enabled":true}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si2023',
retainState:false,
immo:false,
apsn:'Slide1428',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2059',
t:1250
}
,{
n:'si2069',
t:1250
}
,{
n:'si2079',
t:29
}
]
,
containerType:'character-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":true,"card":false},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c6)","size":3,"type":1},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"color":"var(--design-option-color3)","type":1,"enabled":true}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2023',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2051c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2051,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2051',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2059:{
name:'Text_24',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si2059c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2051',
retainState:false,
immo:false,
apsn:'Slide1428',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9i41m","text":"The Basics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"defaultTextShadow:none"},{"offset":0,"length":10,"style":"textShadow:none"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"fontType:regular"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textShadowY:4px"},{"offset":0,"length":10,"style":"lineHeight:115%"},{"offset":0,"length":10,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":10,"style":"letterSpacing:0%"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textTransform:none"},{"offset":0,"length":10,"style":"desktop-fontSize:60"},{"offset":0,"length":10,"style":"textShadowOpacity:none"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"textShadowBlur:8px"},{"offset":0,"length":10,"style":"color:#34623F"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"fontFamily:Krungthep"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"tablet-fontSize:22"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-subheading-3","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2059]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2059c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2059,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2059',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2069:{
name:'Text_25',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si2069c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2051',
retainState:false,
immo:false,
apsn:'Slide1428',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"v16i","text":"Segmenting Principle = \\"break[ing] a complex lesson into smaller parts [...] presented one at a time\\" (Clark & Mayer)","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":117,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":117,"style":"hlnke:true"},{"offset":0,"length":117,"style":"defaultTextShadow:none"},{"offset":0,"length":117,"style":"textShadow:none"},{"offset":0,"length":117,"style":"mobile-fontSize:18"},{"offset":0,"length":117,"style":"textShadowX:0px"},{"offset":0,"length":117,"style":"fontStretch:normal"},{"offset":0,"length":117,"style":"fontType:regular"},{"offset":0,"length":117,"style":"color:#333333"},{"offset":0,"length":117,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":117,"style":"textShadowY:4px"},{"offset":0,"length":117,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":117,"style":"letterSpacing:0%"},{"offset":0,"length":117,"style":"textHighlightEnable:false"},{"offset":0,"length":117,"style":"textTransform:none"},{"offset":0,"length":117,"style":"textShadowOpacity:none"},{"offset":0,"length":117,"style":"overridden:true"},{"offset":0,"length":117,"style":"textDecoration:none"},{"offset":0,"length":117,"style":"lineHeight:130%"},{"offset":0,"length":117,"style":"borderBottomStyle:none"},{"offset":0,"length":117,"style":"textShadowEnable:false"},{"offset":0,"length":117,"style":"hlnk:"},{"offset":0,"length":117,"style":"fontWeight:normal"},{"offset":0,"length":117,"style":"textShadowBlur:8px"},{"offset":0,"length":117,"style":"desktop-fontSize:24"},{"offset":0,"length":117,"style":"fontFamily:Arial"},{"offset":0,"length":117,"style":"backgroundColor:unset"},{"offset":0,"length":117,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":117,"style":"hlnkt:wp"},{"offset":0,"length":117,"style":"fontStyle:normal"},{"offset":0,"length":117,"style":"tablet-fontSize:20"},{"offset":0,"length":117,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":117,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":117,"style":"textOutlineEnable:false"},{"offset":0,"length":117,"style":"opacity:1"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"aov2l","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"u4b5","text":"Smaller, manageable segments improves learning","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":46,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":46,"style":"textOutlineEnable:false"},{"offset":0,"length":46,"style":"opacity:1"},{"offset":0,"length":46,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":46,"style":"hlnke:true"},{"offset":0,"length":46,"style":"defaultTextShadow:none"},{"offset":0,"length":46,"style":"textShadow:none"},{"offset":0,"length":46,"style":"mobile-fontSize:18"},{"offset":0,"length":46,"style":"textShadowX:0px"},{"offset":0,"length":46,"style":"fontStretch:normal"},{"offset":0,"length":46,"style":"fontType:regular"},{"offset":0,"length":46,"style":"color:#333333"},{"offset":0,"length":46,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":46,"style":"textShadowY:4px"},{"offset":0,"length":46,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":46,"style":"letterSpacing:0%"},{"offset":0,"length":46,"style":"textHighlightEnable:false"},{"offset":0,"length":46,"style":"textTransform:none"},{"offset":0,"length":46,"style":"textShadowOpacity:none"},{"offset":0,"length":46,"style":"overridden:true"},{"offset":0,"length":46,"style":"textDecoration:none"},{"offset":0,"length":46,"style":"lineHeight:130%"},{"offset":0,"length":46,"style":"borderBottomStyle:none"},{"offset":0,"length":46,"style":"textShadowEnable:false"},{"offset":0,"length":46,"style":"hlnk:"},{"offset":0,"length":46,"style":"fontWeight:normal"},{"offset":0,"length":46,"style":"textShadowBlur:8px"},{"offset":0,"length":46,"style":"desktop-fontSize:24"},{"offset":0,"length":46,"style":"fontFamily:Arial"},{"offset":0,"length":46,"style":"backgroundColor:unset"},{"offset":0,"length":46,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":46,"style":"hlnkt:wp"},{"offset":0,"length":46,"style":"fontStyle:normal"},{"offset":0,"length":46,"style":"tablet-fontSize:20"},{"offset":0,"length":46,"style":"defaultTextStrokeWidth:1px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"6g1di","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"e7okk","text":"Each segment focuses on a single concept, reducing cognitive overload and enhancing understanding","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":97,"style":"backgroundColor:unset"},{"offset":0,"length":97,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":97,"style":"hlnkt:wp"},{"offset":0,"length":97,"style":"fontStyle:normal"},{"offset":0,"length":97,"style":"tablet-fontSize:20"},{"offset":0,"length":97,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":97,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":97,"style":"textOutlineEnable:false"},{"offset":0,"length":97,"style":"opacity:1"},{"offset":0,"length":97,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":97,"style":"hlnke:true"},{"offset":0,"length":97,"style":"defaultTextShadow:none"},{"offset":0,"length":97,"style":"textShadow:none"},{"offset":0,"length":97,"style":"mobile-fontSize:18"},{"offset":0,"length":97,"style":"textShadowX:0px"},{"offset":0,"length":97,"style":"fontStretch:normal"},{"offset":0,"length":97,"style":"fontType:regular"},{"offset":0,"length":97,"style":"color:#333333"},{"offset":0,"length":97,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":97,"style":"textShadowY:4px"},{"offset":0,"length":97,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":97,"style":"letterSpacing:0%"},{"offset":0,"length":97,"style":"textHighlightEnable:false"},{"offset":0,"length":97,"style":"textTransform:none"},{"offset":0,"length":97,"style":"textShadowOpacity:none"},{"offset":0,"length":97,"style":"overridden:true"},{"offset":0,"length":97,"style":"textDecoration:none"},{"offset":0,"length":97,"style":"lineHeight:130%"},{"offset":0,"length":97,"style":"borderBottomStyle:none"},{"offset":0,"length":97,"style":"textShadowEnable:false"},{"offset":0,"length":97,"style":"hlnk:"},{"offset":0,"length":97,"style":"fontWeight:normal"},{"offset":0,"length":97,"style":"textShadowBlur:8px"},{"offset":0,"length":97,"style":"desktop-fontSize:24"},{"offset":0,"length":97,"style":"fontFamily:Arial"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2069]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2069c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2069,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2069',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2079:{
name:'Button_18',
type:29,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si2079c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"500pj","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e762n","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","designOptionStyles":{"all":{"paddingTop":"32px"},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3bh10","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"q41s","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2nnjq","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2051',
retainState:false,
immo:false,
apsn:'Slide1428',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(2121);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2079]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2079c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2079,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2079',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide1428:{
lb:'The Basics',
id:1428,
from:181,
to:270,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1428c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si2023',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/01453.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:1453,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2121:{
ts:''
}

}

},
Slide1428c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1428,
dn:'Slide1428',
visible:'1'
},
si2123:{
name:'Image_1',
type:1268,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2123c',
tag:'container-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":0,"right":0,"top":0,"bottom":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":0.8828}',
retainState:false,
immo:false,
apsn:'Slide2098',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2131',
t:1268
}
]
,
containerType:'image',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":0,"right":0,"top":0,"bottom":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":0.8828}',
option:'INTRODUCTION_SINGLE_IMAGE_OPTION_1',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2123c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2123,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2123',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1920,
h:1080,
id:1453,
tsp:50,
ip:'dr/01453.png'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2131:{
name:'Image_Group_1',
type:1268,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2131c',
tag:'container-image-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":true,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":0,"bottom":0,"left":0,"right":0},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridGap":"10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 1","marginLeft":"20px","marginBottom":"20px","alignItems":"flex-start"},"tablet":{},"mobile":{}}}}',
parentGroup:'si2123',
retainState:false,
immo:false,
apsn:'Slide2098',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2142',
t:15
}
,{
n:'si2154',
t:1268
}
,{
n:'si2182',
t:29
}
]
,
containerType:'image-single-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":true,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":0,"bottom":0,"left":0,"right":0},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridGap":"10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 1","marginLeft":"20px","marginBottom":"20px","alignItems":"flex-start"},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2123',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2131c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2131,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2131',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2142:{
name:'Screenshot_2024-02-19_at_8_40_48 PM',
type:15,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2142c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{"imageContainerStyles":{"minWidth":"100%","maxWidth":"100%","gridArea":"1 / 2 / span 2 / span 1"}},"tablet":{},"mobile":{}}}',
parentGroup:'si2131',
retainState:false,
immo:false,
apsn:'Slide2098',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#000000',
o:0
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1450,
irh:1042,
w:1450,
h:1042,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2142]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2142c:{
b:[0,0,1450,1042],
fh:false,
fw:false,
uid:2142,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/02232.png',
dn:'si2142',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1451,1043],
vb:[-1,-1,1451,1043]
},
si2154:{
name:'Image_Group_Text_1',
type:1268,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2154c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"10px","paddingRight":"10px","paddingTop":"10px","paddingBottom":"0px","justifyContent":"flex-end"},"tablet":{"marginLeft":"0px","paddingBottom":"20px"},"mobile":{"marginLeft":"0px","paddingBottom":"20px"}}}',
parentGroup:'si2131',
retainState:false,
immo:false,
apsn:'Slide2098',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2162',
t:1250
}
,{
n:'si2172',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"10px","paddingRight":"10px","paddingTop":"10px","paddingBottom":"0px","justifyContent":"flex-end"},"tablet":{"marginLeft":"0px","paddingBottom":"20px"},"mobile":{"marginLeft":"0px","paddingBottom":"20px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2131',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2154c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2154,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2154',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2162:{
name:'Text_26',
type:1250,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2162c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2154',
retainState:false,
immo:false,
apsn:'Slide2098',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"li1i","text":"       Psychological \\n       Reasons","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":36,"style":"fontWeight:normal"},{"offset":0,"length":36,"style":"textShadowBlur:8px"},{"offset":7,"length":29,"style":"color:#34623F"},{"offset":0,"length":36,"style":"mobile-fontSize:32"},{"offset":0,"length":36,"style":"textShadow:none"},{"offset":0,"length":36,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":36,"style":"hlnkt:wp"},{"offset":0,"length":36,"style":"fontStyle:normal"},{"offset":0,"length":36,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":36,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":36,"style":"textOutlineEnable:false"},{"offset":0,"length":36,"style":"fontFamily:Krungthep"},{"offset":0,"length":36,"style":"opacity:1"},{"offset":0,"length":36,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":36,"style":"hlnke:true"},{"offset":0,"length":36,"style":"defaultTextShadow:none"},{"offset":0,"length":36,"style":"backgroundColor:unset"},{"offset":0,"length":36,"style":"tablet-fontSize:48"},{"offset":0,"length":36,"style":"textShadowX:0px"},{"offset":0,"length":36,"style":"fontStretch:normal"},{"offset":0,"length":36,"style":"fontType:regular"},{"offset":0,"length":7,"style":"color:#333333"},{"offset":0,"length":36,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":36,"style":"textShadowY:4px"},{"offset":0,"length":36,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":36,"style":"lineHeight:135%"},{"offset":0,"length":36,"style":"letterSpacing:0%"},{"offset":0,"length":36,"style":"textHighlightEnable:false"},{"offset":0,"length":36,"style":"textTransform:none"},{"offset":0,"length":36,"style":"desktop-fontSize:60"},{"offset":0,"length":36,"style":"textShadowOpacity:none"},{"offset":0,"length":36,"style":"overridden:true"},{"offset":0,"length":36,"style":"textDecoration:none"},{"offset":0,"length":36,"style":"borderBottomStyle:none"},{"offset":0,"length":36,"style":"textShadowEnable:false"},{"offset":0,"length":36,"style":"hlnk:"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-8","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2162]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2162c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2162,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2162',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2172:{
name:'Text_27',
type:1250,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2172c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2154',
retainState:false,
immo:false,
apsn:'Slide2098',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"575ih","text":"\\t\\t\\t\\tUnfamiliar learners need time to digest the \\n                  information","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":78,"style":"fontWeight:normal"},{"offset":0,"length":78,"style":"textShadowBlur:8px"},{"offset":4,"length":74,"style":"desktop-fontSize:24"},{"offset":0,"length":78,"style":"defaultTextShadow:none"},{"offset":0,"length":78,"style":"fontFamily:Arial"},{"offset":0,"length":4,"style":"desktop-fontSize:18"},{"offset":0,"length":78,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":78,"style":"hlnkt:wp"},{"offset":0,"length":78,"style":"fontStyle:normal"},{"offset":0,"length":78,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":78,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":78,"style":"textOutlineEnable:false"},{"offset":0,"length":78,"style":"mobile-fontSize:14"},{"offset":0,"length":78,"style":"opacity:1"},{"offset":0,"length":78,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":78,"style":"hlnke:true"},{"offset":0,"length":78,"style":"backgroundColor:unset"},{"offset":0,"length":78,"style":"textShadow:none"},{"offset":0,"length":78,"style":"tablet-fontSize:16"},{"offset":0,"length":78,"style":"textShadowX:0px"},{"offset":0,"length":78,"style":"fontStretch:normal"},{"offset":0,"length":78,"style":"fontType:regular"},{"offset":0,"length":78,"style":"color:#333333"},{"offset":0,"length":78,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":78,"style":"textShadowY:4px"},{"offset":0,"length":78,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":78,"style":"lineHeight:125%"},{"offset":0,"length":78,"style":"letterSpacing:0%"},{"offset":0,"length":78,"style":"textHighlightEnable:false"},{"offset":0,"length":78,"style":"textTransform:none"},{"offset":0,"length":78,"style":"textShadowOpacity:none"},{"offset":0,"length":78,"style":"overridden:true"},{"offset":0,"length":78,"style":"textDecoration:none"},{"offset":0,"length":78,"style":"borderBottomStyle:none"},{"offset":0,"length":78,"style":"textShadowEnable:false"},{"offset":0,"length":78,"style":"hlnk:"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"d71fh","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"efris","text":"\\t\\t  \\t\\"Cognitive system becomes overloaded\\" \\n                   (Clark & Mayer)","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":78,"style":"borderBottomStyle:none"},{"offset":0,"length":78,"style":"textShadowEnable:false"},{"offset":0,"length":78,"style":"hlnk:"},{"offset":0,"length":78,"style":"fontWeight:normal"},{"offset":0,"length":78,"style":"textShadowBlur:8px"},{"offset":0,"length":78,"style":"desktop-fontSize:24"},{"offset":0,"length":78,"style":"fontFamily:Arial"},{"offset":0,"length":78,"style":"backgroundColor:unset"},{"offset":0,"length":78,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":78,"style":"hlnkt:wp"},{"offset":0,"length":78,"style":"fontStyle:normal"},{"offset":0,"length":78,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":78,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":78,"style":"textOutlineEnable:false"},{"offset":0,"length":78,"style":"mobile-fontSize:14"},{"offset":0,"length":78,"style":"opacity:1"},{"offset":0,"length":78,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":78,"style":"hlnke:true"},{"offset":0,"length":78,"style":"defaultTextShadow:none"},{"offset":0,"length":78,"style":"textShadow:none"},{"offset":0,"length":78,"style":"tablet-fontSize:16"},{"offset":0,"length":78,"style":"textShadowX:0px"},{"offset":0,"length":78,"style":"fontStretch:normal"},{"offset":0,"length":78,"style":"fontType:regular"},{"offset":0,"length":78,"style":"color:#333333"},{"offset":0,"length":78,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":78,"style":"textShadowY:4px"},{"offset":0,"length":78,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":78,"style":"lineHeight:125%"},{"offset":0,"length":78,"style":"letterSpacing:0%"},{"offset":0,"length":78,"style":"textHighlightEnable:false"},{"offset":0,"length":78,"style":"textTransform:none"},{"offset":0,"length":78,"style":"textShadowOpacity:none"},{"offset":0,"length":78,"style":"overridden:true"},{"offset":0,"length":78,"style":"textDecoration:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"6c3co","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"a0fjd","text":"\\t\\t\\tExample: A lesson about Excel formulas \\n \\t\\tbroken into small steps before advancing to \\n \\t\\tthe next steps","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":108,"style":"textShadowOpacity:none"},{"offset":0,"length":108,"style":"overridden:true"},{"offset":0,"length":108,"style":"textDecoration:none"},{"offset":0,"length":108,"style":"borderBottomStyle:none"},{"offset":0,"length":108,"style":"textShadowEnable:false"},{"offset":0,"length":108,"style":"hlnk:"},{"offset":0,"length":108,"style":"fontWeight:normal"},{"offset":0,"length":108,"style":"textShadowBlur:8px"},{"offset":0,"length":108,"style":"desktop-fontSize:24"},{"offset":0,"length":108,"style":"fontFamily:Arial"},{"offset":0,"length":108,"style":"backgroundColor:unset"},{"offset":0,"length":108,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":108,"style":"hlnkt:wp"},{"offset":0,"length":108,"style":"fontStyle:normal"},{"offset":0,"length":108,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":108,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":108,"style":"textOutlineEnable:false"},{"offset":0,"length":108,"style":"mobile-fontSize:14"},{"offset":0,"length":108,"style":"opacity:1"},{"offset":0,"length":108,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":108,"style":"hlnke:true"},{"offset":0,"length":108,"style":"defaultTextShadow:none"},{"offset":0,"length":108,"style":"textShadow:none"},{"offset":0,"length":108,"style":"tablet-fontSize:16"},{"offset":0,"length":108,"style":"textShadowX:0px"},{"offset":0,"length":108,"style":"fontStretch:normal"},{"offset":0,"length":108,"style":"fontType:regular"},{"offset":0,"length":108,"style":"color:#333333"},{"offset":0,"length":108,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":108,"style":"textShadowY:4px"},{"offset":0,"length":108,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":108,"style":"lineHeight:125%"},{"offset":0,"length":108,"style":"letterSpacing:0%"},{"offset":0,"length":108,"style":"textHighlightEnable:false"},{"offset":0,"length":108,"style":"textTransform:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2172]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2172c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2172,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2172',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2182:{
name:'Button_19',
type:29,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2182c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8ur2j","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"letterSpacing:12%"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"fontStretch:normal"},{"offset":0,"length":4,"style":"fontType:regular"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"color:#FFFFFF"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"lineHeight:125%"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textDecoration:none"},{"offset":0,"length":4,"style":"textTransform:uppercase"},{"offset":0,"length":4,"style":"borderBottomStyle:none"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"fontWeight:normal"},{"offset":0,"length":4,"style":"fontFamily:Arial"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"desktop-fontSize:16"},{"offset":0,"length":4,"style":"fontStyle:normal"},{"offset":0,"length":4,"style":"tablet-fontSize:16"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"mobile-fontSize:16"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false","textAlign":"right"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bmkor","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"lineHeight:125%"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textDecoration:none"},{"offset":0,"length":4,"style":"textTransform:uppercase"},{"offset":0,"length":4,"style":"borderBottomStyle:none"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"fontWeight:normal"},{"offset":0,"length":4,"style":"fontFamily:Arial"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"desktop-fontSize:16"},{"offset":0,"length":4,"style":"fontStyle:normal"},{"offset":0,"length":4,"style":"tablet-fontSize:16"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"mobile-fontSize:16"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"letterSpacing:12%"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"fontStretch:normal"},{"offset":0,"length":4,"style":"fontType:regular"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"color:#FFFFFF"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false","textAlign":"right"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","designOptionStyles":{},"iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8rf2m","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"fontStretch:normal"},{"offset":0,"length":4,"style":"fontType:regular"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"color:#FFFFFF"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"lineHeight:125%"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textDecoration:none"},{"offset":0,"length":4,"style":"textTransform:uppercase"},{"offset":0,"length":4,"style":"borderBottomStyle:none"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"fontWeight:normal"},{"offset":0,"length":4,"style":"fontFamily:Arial"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"desktop-fontSize:16"},{"offset":0,"length":4,"style":"fontStyle:normal"},{"offset":0,"length":4,"style":"tablet-fontSize:16"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"mobile-fontSize:16"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"letterSpacing:12%"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false","textAlign":"right"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d9edb","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"color:#FFFFFF"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"lineHeight:125%"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textDecoration:none"},{"offset":0,"length":4,"style":"textTransform:uppercase"},{"offset":0,"length":4,"style":"borderBottomStyle:none"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"fontWeight:normal"},{"offset":0,"length":4,"style":"fontFamily:Arial"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"desktop-fontSize:16"},{"offset":0,"length":4,"style":"fontStyle:normal"},{"offset":0,"length":4,"style":"tablet-fontSize:16"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"mobile-fontSize:16"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"letterSpacing:12%"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"fontStretch:normal"},{"offset":0,"length":4,"style":"fontType:regular"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false","textAlign":"right"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ahsjp","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"fontStretch:normal"},{"offset":0,"length":4,"style":"fontType:regular"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"color:#666666"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"lineHeight:125%"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textDecoration:none"},{"offset":0,"length":4,"style":"textTransform:uppercase"},{"offset":0,"length":4,"style":"borderBottomStyle:none"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"fontWeight:normal"},{"offset":0,"length":4,"style":"fontFamily:Arial"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"desktop-fontSize:16"},{"offset":0,"length":4,"style":"fontStyle:normal"},{"offset":0,"length":4,"style":"tablet-fontSize:16"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"mobile-fontSize:16"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"letterSpacing:12%"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false","textAlign":"right"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2131',
retainState:false,
immo:false,
apsn:'Slide2098',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(2642);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2182]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2182c:{
b:[2,-2,3,-1],
fh:false,
fw:false,
uid:2182,
iso:false,
css:{
360:{
l:'0.309%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.309%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.309%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.309%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.309%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.309%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2182',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[2,-2,3,-1],
vb:[2,-2,3,-1]
},
Slide2098:{
lb:'Psychological Reasons',
id:2098,
from:271,
to:360,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2098c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si2123',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/01453.png',
tiletype:0,
imageFocus:0,
extraImageProps:'{"bgImageOpacity":0}',
id:1453,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2642:{
ts:''
}

}

},
Slide2098c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2098,
dn:'Slide2098',
visible:'1'
},
si3389:{
name:'Slide_video_1',
type:1268,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3389c',
tag:'videoContainer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"left":10,"right":10,"top":20,"bottom":20},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"videoContainerMaxHeight":400,"appearanceProperties":{},"autoFit":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3397',
t:1268
}
]
,
containerType:'video',
widgetProps:'{"padding":{"left":10,"right":10,"top":20,"bottom":20},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"videoContainerMaxHeight":400,"appearanceProperties":{},"autoFit":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'DEFAULT_VIDEO_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3389c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3389,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3389',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1920,
h:1080,
id:498,
tsp:50,
ip:'dr/0498.png'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3397:{
name:'Video_Group_1',
type:1268,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3397c',
tag:'videoCard',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"video":true,"videoCaption":true,"videoBody":false,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"video":"CENTER","videoCaption":"CENTER","videoBody":"CENTER"},"canBeCard":true,"activeAspectRatioId":0,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"videoHeight":400,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"10px"},"tablet":{},"mobile":{}}}',
parentGroup:'si3389',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3416',
t:365
}
,{
n:'si3423',
t:1250
}
]
,
containerType:'video-card',
widgetProps:'{"visibilityInfo":{"video":true,"videoCaption":true,"videoBody":false,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"video":"CENTER","videoCaption":"CENTER","videoBody":"CENTER"},"canBeCard":true,"activeAspectRatioId":0,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"videoHeight":400,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"10px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3389',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3397c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3397,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3397',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3416:{
name:'Web_Video_2',
type:365,
from:361,
to:6630,
rp:0,
rpa:0,
mdi:'si3416c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:209,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3397',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:1,
vim:0,
trin:0,
trout:0,
isDD:false
},
si3416c:{
b:[-474,-236,1446,844],
fh:false,
fw:false,
uid:3416,
iso:false,
css:{
360:{
l:'-48.765%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-48.765%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'197.531%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-48.765%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-48.765%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'197.531%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-48.765%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-48.765%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'197.531%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3416',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'',
mp4:'https://www.youtube.com/watch?v=DyH3FIBTdYg',
vsf:0,
vst:209,
o:100,
vbwr:[-475,-237,1447,845],
vb:[-475,-237,1447,845]
},
si3423:{
name:'Text_37',
type:1250,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3423c',
tag:'videoCaption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3397',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4l5ul","text":"The Segmenting Principle","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"textTransform:none"},{"offset":0,"length":24,"style":"textShadowOpacity:none"},{"offset":0,"length":24,"style":"overridden:true"},{"offset":0,"length":24,"style":"textDecoration:none"},{"offset":0,"length":24,"style":"borderBottomStyle:none"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"fontWeight:normal"},{"offset":0,"length":24,"style":"textShadowBlur:8px"},{"offset":0,"length":24,"style":"color:#34623F"},{"offset":0,"length":24,"style":"mobile-fontSize:20"},{"offset":0,"length":24,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":24,"style":"fontStyle:normal"},{"offset":0,"length":24,"style":"tablet-fontSize:24"},{"offset":0,"length":24,"style":"desktop-fontSize:28"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":24,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":24,"style":"fontFamily:Krungthep"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"defaultTextShadow:none"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"textShadow:none"},{"offset":0,"length":24,"style":"textShadowX:0px"},{"offset":0,"length":24,"style":"fontStretch:normal"},{"offset":0,"length":24,"style":"fontType:regular"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"letterSpacing:5%"},{"offset":0,"length":24,"style":"textShadowY:4px"},{"offset":0,"length":24,"style":"lineHeight:115%"},{"offset":0,"length":24,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":24,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3423]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3423c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3423,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3423',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si3514:{
name:'Block_Button_1',
type:1268,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3514c',
tag:'container-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3522',
t:1268
}
]
,
containerType:'button',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'DEFAULT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3514c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3514,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3514',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#f8f7f4',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3522:{
name:'Block_Button_Group_1',
type:1268,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3522c',
tag:'container-button-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"padding":{"top":20,"bottom":20,"left":20,"right":20},"groupedItemsVisibility":{"slide-item-buttons":1},"visibilityInfo":{"slide-item-buttons":true,"card":false},"alignment":{"slide-item-buttons":"LEFT"},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{},"tablet":{},"mobile":{}}}}',
parentGroup:'si3514',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3530',
t:29
}
,{
n:'si3546',
t:29
}
,{
n:'si3562',
t:29
}
]
,
containerType:'button-card',
widgetProps:'{"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"padding":{"top":20,"bottom":20,"left":20,"right":20},"groupedItemsVisibility":{"slide-item-buttons":1},"visibilityInfo":{"slide-item-buttons":true,"card":false},"alignment":{"slide-item-buttons":"LEFT"},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3514',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3522c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3522,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3522',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3530:{
name:'Button_40',
type:29,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3530c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fes75","text":"NExt","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cdrjs","text":"NExt","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"306dq","text":"NExt","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cu5eb","text":"NExt","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2pvih","text":"NExt","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3522',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(3583);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3530]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3530c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3530,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3530',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3546:{
name:'Button_41',
type:29,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3546c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0546.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"etq8d","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2f0o2","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4ef89","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"10rqc","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5n0g6","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3522',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3546]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3546c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3546,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3546',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3562:{
name:'Button_42',
type:29,
from:361,
to:7050,
rp:0,
rpa:0,
mdi:'si3562c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:223,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0546.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5sk5m","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3tv36","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5obp0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"86bsr","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4462d","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3522',
retainState:false,
immo:false,
apsn:'Slide3371',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3562]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3562c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3562,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3562',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide3371:{
lb:'Video',
id:3371,
from:361,
to:7050,
iols:0,
i360qs:false,
sdu:223,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3371c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si3389',
t:1268
}
,{
n:'si3514',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
3583:{
ts:''
}

}

},
Slide3371c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3371,
dn:'Slide3371',
visible:'1'
},
si2562:{
name:'Character_Block_3',
type:1268,
from:7051,
to:7140,
rp:0,
rpa:0,
mdi:'si2562c',
tag:'character-block-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":360,"autoFit":true,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row-reverse","gap":"24px","padding":"8% 1% 8% 4%"},"tablet":{"display":"flex","flexDirection":"column","padding":"5%"},"mobile":{"display":"flex","flexDirection":"column","gap":"24px","padding":"5%"}},"appearanceProperties":{}}',
retainState:false,
immo:false,
apsn:'Slide2363',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2570',
t:1268
}
,{
n:'si2590',
t:1268
}
]
,
containerType:'character-block',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":360,"autoFit":true,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row-reverse","gap":"24px","padding":"8% 1% 8% 4%"},"tablet":{"display":"flex","flexDirection":"column","padding":"5%"},"mobile":{"display":"flex","flexDirection":"column","gap":"24px","padding":"5%"}},"appearanceProperties":{}}',
option:'FLIP_SINGLE_CHARACTER_OPTION_2',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2562c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2562,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2562',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2570:{
name:'character-image_3',
type:1268,
from:7051,
to:7140,
rp:0,
rpa:0,
mdi:'si2570c',
tag:'character-container-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"padding":{"top":10,"bottom":10,"left":2,"right":2},"visibilityInfo":{"character-image":true},"alignment":{},"canBeCard":false,"imageBehavior":"IG_FIT","isCharacterImageContainer":true,"designOptionStyles":{"all":{"flex":"none","alignSelf":"center","padding":"40px 20px 40px 20px","maxWidth":"50%"},"tablet":{},"mobile":{}},"imageHeight":350}',
parentGroup:'si2562',
retainState:false,
immo:false,
apsn:'Slide2363',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2578',
t:15
}
]
,
containerType:'character-container-1',
widgetProps:'{"shouldRender":true,"padding":{"top":10,"bottom":10,"left":2,"right":2},"visibilityInfo":{"character-image":true},"alignment":{},"canBeCard":false,"imageBehavior":"IG_FIT","isCharacterImageContainer":true,"designOptionStyles":{"all":{"flex":"none","alignSelf":"center","padding":"40px 20px 40px 20px","maxWidth":"50%"},"tablet":{},"mobile":{}},"imageHeight":350}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2562',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2570c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2570,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2570',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2578:{
name:'Melanie19',
type:15,
from:7051,
to:7140,
rp:0,
rpa:0,
mdi:'si2578c',
tag:'character-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{"transform":"scaleX(-1)"},"tablet":{},"mobile":{}}}',
parentGroup:'si2570',
retainState:false,
immo:false,
apsn:'Slide2363',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:true,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:907,
irh:2000,
w:907,
h:2000,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2578]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2578c:{
b:[0,0,907,2000],
fh:false,
fw:true,
uid:2578,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/02634.png',
dn:'si2578',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,908,2001],
vb:[-1,-1,908,2001]
},
si2590:{
name:'Character_Group_3',
type:1268,
from:7051,
to:7140,
rp:0,
rpa:0,
mdi:'si2590c',
tag:'character-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":true,"card":false},"padding":{"top":60,"bottom":60,"left":60,"right":60},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c9)","size":4,"type":1},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{"padding":"40px"},"mobile":{"marginTop":"0%","padding":"20px"}}}',
parentGroup:'si2562',
retainState:false,
immo:false,
apsn:'Slide2363',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2598',
t:1250
}
,{
n:'si2608',
t:1250
}
,{
n:'si2618',
t:29
}
]
,
containerType:'character-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":true,"card":false},"padding":{"top":60,"bottom":60,"left":60,"right":60},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c9)","size":4,"type":1},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{"padding":"40px"},"mobile":{"marginTop":"0%","padding":"20px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2562',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2590c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2590,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2590',
visible:1,
effectiveVi:1,
JSONEffectData:false,
gf:{
b:[0,0,0,0],
t:3,
x1:50,
y1:0,
x2:50,
y2:100,
s:0,
cs:[{
p:0,
c:'var(--c2)',
o:255
}
,{
p:100,
c:'var(--c3)',
o:255
}
]

}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2598:{
name:'Text_28',
type:1250,
from:7051,
to:7140,
rp:0,
rpa:0,
mdi:'si2598c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2590',
retainState:false,
immo:false,
apsn:'Slide2363',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9i41m","text":"\\tEvidence","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"fontStyle:normal"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":9,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":9,"style":"fontFamily:Krungthep"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"tablet-fontSize:32"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"defaultTextShadow:none"},{"offset":0,"length":9,"style":"mobile-fontSize:28"},{"offset":0,"length":9,"style":"textShadow:none"},{"offset":0,"length":9,"style":"textShadowX:0px"},{"offset":0,"length":9,"style":"fontStretch:normal"},{"offset":0,"length":9,"style":"fontType:regular"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textShadowY:4px"},{"offset":0,"length":9,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":9,"style":"letterSpacing:0%"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textTransform:none"},{"offset":0,"length":9,"style":"desktop-fontSize:60"},{"offset":0,"length":9,"style":"textShadowOpacity:none"},{"offset":0,"length":9,"style":"overridden:true"},{"offset":0,"length":9,"style":"lineHeight:120%"},{"offset":0,"length":9,"style":"textDecoration:none"},{"offset":0,"length":9,"style":"borderBottomStyle:none"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"fontWeight:normal"},{"offset":0,"length":9,"style":"textShadowBlur:8px"},{"offset":0,"length":9,"style":"color:#34623F"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-5","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2598]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2598c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2598,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2598',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2608:{
name:'Text_29',
type:1250,
from:7051,
to:7140,
rp:0,
rpa:0,
mdi:'si2608c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2590',
retainState:false,
immo:false,
apsn:'Slide2363',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"v16i","text":"Evidence supports segemented learning!","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":38,"style":"borderBottomStyle:none"},{"offset":0,"length":38,"style":"textShadowEnable:false"},{"offset":0,"length":38,"style":"hlnk:"},{"offset":0,"length":38,"style":"fontWeight:normal"},{"offset":0,"length":38,"style":"textShadowBlur:8px"},{"offset":0,"length":38,"style":"desktop-fontSize:24"},{"offset":0,"length":38,"style":"fontFamily:Arial"},{"offset":0,"length":38,"style":"backgroundColor:unset"},{"offset":0,"length":38,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"hlnkt:wp"},{"offset":0,"length":38,"style":"fontStyle:normal"},{"offset":0,"length":38,"style":"tablet-fontSize:20"},{"offset":0,"length":38,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"textOutlineEnable:false"},{"offset":0,"length":38,"style":"opacity:1"},{"offset":0,"length":38,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"hlnke:true"},{"offset":0,"length":38,"style":"defaultTextShadow:none"},{"offset":0,"length":38,"style":"textShadow:none"},{"offset":0,"length":38,"style":"mobile-fontSize:18"},{"offset":0,"length":38,"style":"textShadowX:0px"},{"offset":0,"length":38,"style":"fontStretch:normal"},{"offset":0,"length":38,"style":"fontType:regular"},{"offset":0,"length":38,"style":"color:#333333"},{"offset":0,"length":38,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":38,"style":"textShadowY:4px"},{"offset":0,"length":38,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":38,"style":"letterSpacing:0%"},{"offset":0,"length":38,"style":"textHighlightEnable:false"},{"offset":0,"length":38,"style":"textTransform:none"},{"offset":0,"length":38,"style":"textShadowOpacity:none"},{"offset":0,"length":38,"style":"overridden:true"},{"offset":0,"length":38,"style":"textDecoration:none"},{"offset":0,"length":38,"style":"lineHeight:130%"}],"entityRanges":[],"data":{"listDepth":"1","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"e775u","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"1","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"3t4c","text":"\\"They found that learners who received the segmented presentation performed better on transfer tests than the learners who received a continuous presentation, even though identical material was presented in both conditions.\\"","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":224,"style":"overridden:true"},{"offset":0,"length":224,"style":"textDecoration:none"},{"offset":0,"length":224,"style":"lineHeight:130%"},{"offset":0,"length":224,"style":"borderBottomStyle:none"},{"offset":0,"length":224,"style":"textShadowEnable:false"},{"offset":0,"length":224,"style":"hlnk:"},{"offset":0,"length":224,"style":"fontWeight:normal"},{"offset":0,"length":224,"style":"textShadowBlur:8px"},{"offset":0,"length":224,"style":"desktop-fontSize:24"},{"offset":0,"length":224,"style":"fontFamily:Arial"},{"offset":0,"length":224,"style":"backgroundColor:unset"},{"offset":0,"length":224,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":224,"style":"hlnkt:wp"},{"offset":0,"length":224,"style":"fontStyle:normal"},{"offset":0,"length":224,"style":"tablet-fontSize:20"},{"offset":0,"length":224,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":224,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":224,"style":"textOutlineEnable:false"},{"offset":0,"length":224,"style":"opacity:1"},{"offset":0,"length":224,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":224,"style":"hlnke:true"},{"offset":0,"length":224,"style":"defaultTextShadow:none"},{"offset":0,"length":224,"style":"textShadow:none"},{"offset":0,"length":224,"style":"mobile-fontSize:18"},{"offset":0,"length":224,"style":"textShadowX:0px"},{"offset":0,"length":224,"style":"fontStretch:normal"},{"offset":0,"length":224,"style":"fontType:regular"},{"offset":0,"length":224,"style":"color:#333333"},{"offset":0,"length":224,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":224,"style":"textShadowY:4px"},{"offset":0,"length":224,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":224,"style":"letterSpacing:0%"},{"offset":0,"length":224,"style":"textHighlightEnable:false"},{"offset":0,"length":224,"style":"textTransform:none"},{"offset":0,"length":224,"style":"textShadowOpacity:none"}],"entityRanges":[],"data":{"listDepth":"1","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"1j7g6","text":"\\t","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"1","overridden":"false","presetId":"text-body-1"}},{"key":"a5t68","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"1","overridden":"false","presetId":"text-body-1"}},{"key":"81f5l","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"1","overridden":"false","presetId":"text-body-1"}},{"key":"928tq","text":"\\tClark, Ruth C., and Richard E. Mayer. E-Learning and the Science of Instruction : Proven Guidelines for \\t\\t\\t \\n        Consumers and Designers of Multimedia Learning, Center for Creative Leadership, 2011. ProQuest \\n        Ebook Central, http://ebookcentral.proquest.com/lib/csumb/detail.action?docID=697625.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":307,"style":"textShadow:none"},{"offset":0,"length":307,"style":"mobile-fontSize:18"},{"offset":0,"length":307,"style":"textShadowX:0px"},{"offset":0,"length":307,"style":"fontStretch:normal"},{"offset":0,"length":307,"style":"fontType:regular"},{"offset":0,"length":307,"style":"color:#333333"},{"offset":0,"length":307,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":307,"style":"textShadowY:4px"},{"offset":0,"length":307,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":307,"style":"letterSpacing:0%"},{"offset":0,"length":307,"style":"textHighlightEnable:false"},{"offset":0,"length":307,"style":"textTransform:none"},{"offset":0,"length":307,"style":"textShadowOpacity:none"},{"offset":0,"length":307,"style":"overridden:true"},{"offset":0,"length":307,"style":"textDecoration:none"},{"offset":0,"length":307,"style":"lineHeight:130%"},{"offset":0,"length":307,"style":"fontFamily:Georgia"},{"offset":0,"length":307,"style":"borderBottomStyle:none"},{"offset":0,"length":1,"style":"desktop-fontSize:22"},{"offset":0,"length":307,"style":"textShadowEnable:false"},{"offset":0,"length":307,"style":"hlnk:"},{"offset":0,"length":307,"style":"fontWeight:normal"},{"offset":1,"length":306,"style":"desktop-fontSize:12"},{"offset":0,"length":307,"style":"backgroundColor:unset"},{"offset":0,"length":307,"style":"textShadowBlur:8px"},{"offset":0,"length":307,"style":"hlnkt:wp"},{"offset":0,"length":307,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":307,"style":"tablet-fontSize:20"},{"offset":0,"length":307,"style":"fontStyle:normal"},{"offset":0,"length":307,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":307,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":307,"style":"textOutlineEnable:false"},{"offset":0,"length":307,"style":"opacity:1"},{"offset":0,"length":307,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":307,"style":"hlnke:true"},{"offset":0,"length":307,"style":"defaultTextShadow:none"}],"entityRanges":[],"data":{"listDepth":"1","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"coo8s","text":"        Created from csumb on 2024-02-20 04:56:03.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":50,"style":"opacity:1"},{"offset":0,"length":50,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":50,"style":"hlnke:true"},{"offset":0,"length":50,"style":"defaultTextShadow:none"},{"offset":0,"length":50,"style":"textShadow:none"},{"offset":0,"length":50,"style":"mobile-fontSize:18"},{"offset":0,"length":50,"style":"textShadowX:0px"},{"offset":0,"length":50,"style":"fontStretch:normal"},{"offset":0,"length":50,"style":"fontType:regular"},{"offset":0,"length":50,"style":"color:#333333"},{"offset":0,"length":50,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":50,"style":"textShadowY:4px"},{"offset":0,"length":50,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":50,"style":"letterSpacing:0%"},{"offset":0,"length":50,"style":"textHighlightEnable:false"},{"offset":0,"length":50,"style":"textTransform:none"},{"offset":0,"length":50,"style":"textShadowOpacity:none"},{"offset":0,"length":50,"style":"overridden:true"},{"offset":0,"length":50,"style":"textDecoration:none"},{"offset":0,"length":50,"style":"lineHeight:130%"},{"offset":0,"length":50,"style":"fontFamily:Georgia"},{"offset":0,"length":50,"style":"borderBottomStyle:none"},{"offset":0,"length":50,"style":"textShadowEnable:false"},{"offset":0,"length":50,"style":"hlnk:"},{"offset":0,"length":50,"style":"fontWeight:normal"},{"offset":0,"length":50,"style":"desktop-fontSize:12"},{"offset":0,"length":50,"style":"textShadowBlur:8px"},{"offset":0,"length":50,"style":"backgroundColor:unset"},{"offset":0,"length":50,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":50,"style":"hlnkt:wp"},{"offset":0,"length":50,"style":"fontStyle:normal"},{"offset":0,"length":50,"style":"tablet-fontSize:20"},{"offset":0,"length":50,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":50,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":50,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listDepth":"1","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2608]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2608c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2608,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2608',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2618:{
name:'Button_22',
type:29,
from:7051,
to:7140,
rp:0,
rpa:0,
mdi:'si2618c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"500pj","text":"Check for understanding","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"textShadowColor:ffffff00"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"textShadowY:0px"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":23,"style":"textShadowBlur:0px"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e762n","text":"Check for understanding","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"textShadowColor:ffffff00"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"textShadowY:0px"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":23,"style":"textShadowBlur:0px"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","designOptionStyles":{"all":{"marginTop":"20px"},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3bh10","text":"Check for understanding","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"textShadowColor:ffffff00"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"textShadowY:0px"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":23,"style":"textShadowBlur:0px"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"overridden:false"},{"offset":0,"length":23,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"q41s","text":"Check for understanding","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"textShadowColor:ffffff00"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"textShadowY:0px"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":23,"style":"textShadowBlur:0px"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"overridden:false"},{"offset":0,"length":23,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2nnjq","text":"Check for understanding","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"textShadowColor:ffffff00"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"textShadowY:0px"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":23,"style":"textShadowBlur:0px"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2590',
retainState:false,
immo:false,
apsn:'Slide2363',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(2649);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2618]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2618c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2618,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2618',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide2363:{
lb:'Evidence',
id:2363,
from:7051,
to:7140,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2363c',
st:'Normal Slide',
sk:'Scenario',
slideTag:'scenario-slide1',
type:30,
accProps:{
}
,
si:[{
n:'si2562',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/01453.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:1453,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2649:{
ts:''
}

}

},
Slide2363c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2363,
dn:'Slide2363',
visible:'1'
},
si2708:{
name:'ResponsiveContainer_49',
type:1268,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2708c',
tag:'container-true-or-false',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2716',
t:1268
}
,{
n:'si2865',
t:612
}
,{
n:'si2910',
t:612
}
]
,
containerType:'true-or-false',
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2708c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2708,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2708',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2716:{
name:'ResponsiveContainer_50',
type:1268,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2716c',
tag:'container-true-or-false-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-progress-indicator":true,"slide-item-question-text":true,"slide-item-submit-button":true,"slide-item-clear-button":false,"slide-item-skip-button":false,"slide-item-back-button":false,"slide-item-view-answer-button":true,"slide-item-review-back-button":true,"slide-item-review-next-button":true,"slide-item-answer-checkbox":true,"card":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":2},"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"container-answer-area":{"all":{"display":"flex","flexDirection":"column","margin":"40px 6px 0px 6px","rowGap":"20px"},"tablet":{},"mobile":{}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"80px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2724',
t:1250
}
,{
n:'si2733',
t:1250
}
,{
n:'si2742',
t:10090
}
,{
n:'si2754',
t:10090
}
,{
n:'si2766',
t:29
}
,{
n:'si2826',
t:29
}
,{
n:'si2835',
t:29
}
,{
n:'si2850',
t:29
}
]
,
containerType:'true-or-false-card',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-progress-indicator":true,"slide-item-question-text":true,"slide-item-submit-button":true,"slide-item-clear-button":false,"slide-item-skip-button":false,"slide-item-back-button":false,"slide-item-view-answer-button":true,"slide-item-review-back-button":true,"slide-item-review-next-button":true,"slide-item-answer-checkbox":true,"card":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":2},"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"container-answer-area":{"all":{"display":"flex","flexDirection":"column","margin":"40px 6px 0px 6px","rowGap":"20px"},"tablet":{},"mobile":{}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"80px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2708',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2716c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2716,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2716',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2724:{
name:'Text_30',
type:1250,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2724c',
tag:'slide-item-progress-indicator',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"editable":false,"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{"marginBottom":"16px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4b46o","text":"Question @#{101} / @#{102}","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":26,"style":"hlnk:"},{"offset":0,"length":26,"style":"hlnkt:wp"},{"offset":0,"length":26,"style":"textOutlineEnable:false"},{"offset":0,"length":26,"style":"opacity:1"},{"offset":0,"length":26,"style":"hlnke:true"},{"offset":0,"length":26,"style":"backgroundColor:unset"},{"offset":0,"length":26,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":26,"style":"textHighlightEnable:false"},{"offset":0,"length":26,"style":"textShadowEnable:false"},{"offset":0,"length":26,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:14,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2724]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2724c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2724,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2724',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2733:{
name:'Text_31',
type:1250,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2733c',
tag:'slide-item-question-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ddp38","text":"The segmenting principle helps reduce cognitive overload by focusing on one concept at a time.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":94,"style":"opacity:1"},{"offset":0,"length":94,"style":"hlnke:true"},{"offset":0,"length":94,"style":"backgroundColor:unset"},{"offset":0,"length":94,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":94,"style":"textHighlightEnable:false"},{"offset":0,"length":94,"style":"textShadowEnable:false"},{"offset":0,"length":94,"style":"overridden:false"},{"offset":0,"length":94,"style":"hlnk:"},{"offset":0,"length":94,"style":"hlnkt:wp"},{"offset":0,"length":94,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-heading-6"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2733]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2733c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2733,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2733',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2742:{
name:'Checkbox_4',
type:10090,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2742c',
tag:'slide-item-answer-checkbox0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"currentState":"normal","selectedByDefault":false,"scaleValue":"medium","imagePath":"01534.png","imageSizeData":{"x":0,"y":0,"originalWidth":490.0,"originalHeight":370.0},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"5qvj7","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"d9dok","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"selected":{"opacity":100,"editorState":{"blocks":[{"key":"662n9","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"7566v","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"fqq4g","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"50%"}},"isImageActive":false,"isTextActive":true,"size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:true,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2742]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2742c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2742,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2742',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2754:{
name:'Checkbox_5',
type:10090,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2754c',
tag:'slide-item-answer-checkbox1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"currentState":"normal","selectedByDefault":false,"scaleValue":"medium","imagePath":"01534.png","imageSizeData":{"x":0,"y":0,"originalWidth":490.0,"originalHeight":370.0},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"eslf6","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"5uf4t","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"overridden:false"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"selected":{"opacity":100,"editorState":{"blocks":[{"key":"33lad","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"75fb9","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"92ell","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"overridden:false"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"50%"}},"isImageActive":false,"isTextActive":true,"size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:false,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2754]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2754c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2754,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2754',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2766:{
name:'Button_23',
type:29,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2766c',
tag:'slide-item-submit-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b12ji","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"42s","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"46cb7","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f17r4","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"90dgo","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2766]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2766c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2766,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2766',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2826:{
name:'Button_27',
type:29,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2826c',
tag:'slide-item-view-answer-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0546.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"17kcc","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"couut","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3ciet","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1s52v","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3bs0g","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOptionStyles":{"all":{"marginRight":"auto"},"tablet":{},"mobile":{"marginRight":"unset"}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:6,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2826]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2826c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2826,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2826',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2835:{
name:'Button_28',
type:29,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2835c',
tag:'slide-item-review-back-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8bhlv","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"eabkk","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"c4bv1","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6hakk","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f2aeq","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:5,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2835]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2835c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2835,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2835',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2850:{
name:'Button_29',
type:29,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2850c',
tag:'slide-item-review-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9kg04","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9tfcv","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"89ojl","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2qie8","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7tdrv","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si2716',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:4,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2850]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2850c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2850,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2850',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2878:{
name:'Caption_4',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2878c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"apgav","text":"That\'s correct! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"hlnk:"},{"offset":0,"length":55,"style":"hlnkt:wp"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"hlnke:true"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2865',
stl:[{
stn:'Normal',
stt:0,
stsi:[2878]
}
]
,
stis:0,
bstiid:2865,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2865,
isDD:false
},
si2878c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2878,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2878',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2889:{
name:'Caption_4',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2889c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ajh4s","text":"That\'s incorrect! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"hlnk:"},{"offset":0,"length":57,"style":"hlnkt:wp"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"hlnke:true"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"},{"offset":0,"length":57,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2865',
stl:[{
stn:'Normal',
stt:0,
stsi:[2889]
}
]
,
stis:0,
bstiid:2865,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2865,
isDD:false
},
si2889c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2889,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2889',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2900:{
name:'Caption_4',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2900c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"bud0p","text":"You must answer the question before continuing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":46,"style":"hlnk:"},{"offset":0,"length":46,"style":"hlnkt:wp"},{"offset":0,"length":46,"style":"textOutlineEnable:false"},{"offset":0,"length":46,"style":"opacity:1"},{"offset":0,"length":46,"style":"hlnke:true"},{"offset":0,"length":46,"style":"backgroundColor:unset"},{"offset":0,"length":46,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":46,"style":"textHighlightEnable:false"},{"offset":0,"length":46,"style":"textShadowEnable:false"},{"offset":0,"length":46,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2865',
stl:[{
stn:'Normal',
stt:0,
stsi:[2900]
}
]
,
stis:0,
bstiid:2865,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2865,
isDD:false
},
si2900c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2900,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2900',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2865:{
name:'Caption_4',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2865c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"6qrq0","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2876,
stt:0,
dsr:'Default_State',
stsi:[2865]
}
,{
stn:2877,
stt:101,
dsr:'Correct',
stsi:[2878]
}
,{
stn:2888,
stt:102,
dsr:'Incorrect',
stsi:[2889]
}
,{
stn:2899,
stt:104,
dsr:'Incomplete',
stsi:[2900]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2865','si2878','si2889','si2900'],
isDD:false
},
si2865c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2865,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2865',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2923:{
name:'Caption_5',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2923c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"8ofoq","text":"Your answer is correct","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"overridden:false"},{"offset":0,"length":22,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2910',
stl:[{
stn:'Normal',
stt:0,
stsi:[2923]
}
]
,
stis:0,
bstiid:2910,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2910,
isDD:false
},
si2923c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2923,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2923',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2934:{
name:'Caption_5',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2934c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"av9oi","text":"Your answer is incorrect","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2910',
stl:[{
stn:'Normal',
stt:0,
stsi:[2934]
}
]
,
stis:0,
bstiid:2910,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2910,
isDD:false
},
si2934c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2934,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2934',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2945:{
name:'Caption_5',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2945c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4eh4o","text":"You did not answer this question completely","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":43,"style":"hlnk:"},{"offset":0,"length":43,"style":"hlnkt:wp"},{"offset":0,"length":43,"style":"textOutlineEnable:false"},{"offset":0,"length":43,"style":"opacity:1"},{"offset":0,"length":43,"style":"hlnke:true"},{"offset":0,"length":43,"style":"backgroundColor:unset"},{"offset":0,"length":43,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":43,"style":"textHighlightEnable:false"},{"offset":0,"length":43,"style":"textShadowEnable:false"},{"offset":0,"length":43,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2910',
stl:[{
stn:'Normal',
stt:0,
stsi:[2945]
}
]
,
stis:0,
bstiid:2910,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2910,
isDD:false
},
si2945c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2945,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2945',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2910:{
name:'Caption_5',
type:612,
from:7141,
to:7230,
rp:0,
rpa:0,
mdi:'si2910c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2708',
retainState:false,
immo:false,
apsn:'Slide2663',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"32hka","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2921,
stt:0,
dsr:'Default_State',
stsi:[2910]
}
,{
stn:2922,
stt:101,
dsr:'Correct',
stsi:[2923]
}
,{
stn:2933,
stt:102,
dsr:'Incorrect',
stsi:[2934]
}
,{
stn:2944,
stt:104,
dsr:'Incomplete',
stsi:[2945]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2910','si2923','si2934','si2945'],
isDD:false
},
si2910c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2910,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2910',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2663:{
lb:'Question _1',
id:2663,
from:7141,
to:7230,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2663c',
st:'Question Slide',
sk:'True or false',
slideTag:'true-false-slide',
type:77,
accProps:{
}
,
si:[{
n:'si2708',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/0498.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:498,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
osa:'{"scripts":[{"then":[["cp.jumpToNextSlide(2698);"]]}]}',
ofa:'{"scripts":[{"then":[["cp.jumpToNextSlide(2707);"]]}]}',
bph:[]
,
bookmarks:[]
,
qs:'Slide2663q0',
qnq:0,
pa:7184,
iph:{
2698:{
ts:'',
tr:''
}
,
2707:{
ts:'',
tr:''
}

}

},
Slide2663c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2663,
dn:'Slide2663',
visible:'1'
},
Slide2663q0:{
noa:1,
qt:'',
it:true,
is:false,
ipq:false,
ikc:false,
sat:true,
qst:0,
ish:false,
ips:false,
qnq:0,
sn:'Slide2663',
oid:'Quiz_2024410194512',
iid:'2684',
sra:true,
w:1,
nw:0,
itp:'true-false',
qtp:'TrueFalse',
gn:'Slide2663_ag',
tl:0,
sfrc:false,
frc:'',
ifc:[],
ofct:false,
ao:['si2742c:0','si2754c:1'],
qtc:'',
JSONTT_4:[],
JSONTT_5:[],
oic:'',
sic:false,
osc:'',
osct:false,
qmas:1,
amfitb:-1,
csfitb:false,
quizNumberingEnabled:false,
quizNumberingType:26,
ail:['si2742','si2754'],
cal:['si2742']
},
si1500:{
name:'ResponsiveContainer_26',
type:1268,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1500c',
tag:'container-multiple-choice',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1508',
t:1268
}
,{
n:'si1662',
t:612
}
,{
n:'si1707',
t:612
}
]
,
containerType:'multiple-choice',
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1500c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1500,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1500',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1508:{
name:'ResponsiveContainer_27',
type:1268,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1508c',
tag:'container-multiple-choice-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-review-back-button":true,"slide-item-skip-button":false,"slide-item-submit-button":true,"slide-item-progress-indicator":true,"slide-item-clear-button":false,"card":false,"slide-item-answer-checkbox":true,"slide-item-review-next-button":true,"slide-item-question-text":true,"slide-item-view-answer-button":true,"slide-item-back-button":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":3},"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"container-answer-area":{"all":{"display":"flex","flexDirection":"column","margin":"40px 6px 0px 6px","rowGap":"20px"},"tablet":{},"mobile":{}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"80px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1516',
t:1250
}
,{
n:'si1525',
t:1250
}
,{
n:'si1536',
t:10090
}
,{
n:'si1548',
t:10090
}
,{
n:'si1560',
t:29
}
,{
n:'si1623',
t:29
}
,{
n:'si1632',
t:29
}
,{
n:'si1647',
t:29
}
,{
n:'si2651',
t:10090
}
]
,
containerType:'multiple-choice-card',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-review-back-button":true,"slide-item-skip-button":false,"slide-item-submit-button":true,"slide-item-progress-indicator":true,"slide-item-clear-button":false,"card":false,"slide-item-answer-checkbox":true,"slide-item-review-next-button":true,"slide-item-question-text":true,"slide-item-view-answer-button":true,"slide-item-back-button":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":3},"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"container-answer-area":{"all":{"display":"flex","flexDirection":"column","margin":"40px 6px 0px 6px","rowGap":"20px"},"tablet":{},"mobile":{}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"80px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1500',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1508c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1508,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1508',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1516:{
name:'Text_9',
type:1250,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1516c',
tag:'slide-item-progress-indicator',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"editable":false,"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{"marginBottom":"16px"},"tablet":{},"mobile":{}}}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"auv8q","text":"Question @#{101} / @#{102}","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":26,"style":"hlnkt:wp"},{"offset":0,"length":26,"style":"textOutlineEnable:false"},{"offset":0,"length":26,"style":"opacity:1"},{"offset":0,"length":26,"style":"hlnke:true"},{"offset":0,"length":26,"style":"backgroundColor:unset"},{"offset":0,"length":26,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":26,"style":"textHighlightEnable:false"},{"offset":0,"length":26,"style":"textShadowEnable:false"},{"offset":0,"length":26,"style":"overridden:false"},{"offset":0,"length":26,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-detail-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:14,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1516]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1516c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1516,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1516',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1525:{
name:'Text_10',
type:1250,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1525c',
tag:'slide-item-question-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7ru3j","text":"What are the benefits of using the segmenting principle in instructional design?","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":80,"style":"overridden:false"},{"offset":0,"length":80,"style":"hlnk:"},{"offset":0,"length":80,"style":"hlnkt:wp"},{"offset":0,"length":80,"style":"textOutlineEnable:false"},{"offset":0,"length":80,"style":"opacity:1"},{"offset":0,"length":80,"style":"hlnke:true"},{"offset":0,"length":80,"style":"backgroundColor:unset"},{"offset":0,"length":80,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":80,"style":"textHighlightEnable:false"},{"offset":0,"length":80,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-heading-6"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1525]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1525c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1525,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1525',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1536:{
name:'Checkbox_1',
type:10090,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1536c',
tag:'slide-item-answer-checkbox0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"01534.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"8o784","text":" It makes information harder to understand","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":42,"style":"overridden:false"},{"offset":0,"length":42,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":42,"style":"hlnkt:wp"},{"offset":0,"length":42,"style":"textOutlineEnable:false"},{"offset":0,"length":42,"style":"opacity:1"},{"offset":0,"length":42,"style":"textShadowColor:ffffff00"},{"offset":0,"length":42,"style":"hlnke:true"},{"offset":0,"length":42,"style":"backgroundColor:unset"},{"offset":0,"length":42,"style":"textShadowX:0px"},{"offset":0,"length":42,"style":"textShadowY:0px"},{"offset":0,"length":42,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":42,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":42,"style":"textShadowBlur:0px"},{"offset":0,"length":42,"style":"textHighlightEnable:false"},{"offset":0,"length":42,"style":"textShadowEnable:false"},{"offset":0,"length":42,"style":"hlnk:"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-uic-4"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"enlgh","text":" It makes information harder to understand","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":42,"style":"overridden:false"},{"offset":0,"length":42,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":42,"style":"hlnkt:wp"},{"offset":0,"length":42,"style":"textOutlineEnable:false"},{"offset":0,"length":42,"style":"opacity:1"},{"offset":0,"length":42,"style":"textShadowColor:ffffff00"},{"offset":0,"length":42,"style":"hlnke:true"},{"offset":0,"length":42,"style":"backgroundColor:unset"},{"offset":0,"length":42,"style":"textShadowX:0px"},{"offset":0,"length":42,"style":"textShadowY:0px"},{"offset":0,"length":42,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":42,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":42,"style":"textShadowBlur:0px"},{"offset":0,"length":42,"style":"textHighlightEnable:false"},{"offset":0,"length":42,"style":"textShadowEnable:false"},{"offset":0,"length":42,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"50%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"7v04t","text":" It makes information harder to understand","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":42,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":42,"style":"hlnkt:wp"},{"offset":0,"length":42,"style":"textOutlineEnable:false"},{"offset":0,"length":42,"style":"opacity:1"},{"offset":0,"length":42,"style":"textShadowColor:ffffff00"},{"offset":0,"length":42,"style":"hlnke:true"},{"offset":0,"length":42,"style":"backgroundColor:unset"},{"offset":0,"length":42,"style":"textShadowX:0px"},{"offset":0,"length":42,"style":"textShadowY:0px"},{"offset":0,"length":42,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":42,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":42,"style":"textShadowBlur:0px"},{"offset":0,"length":42,"style":"textHighlightEnable:false"},{"offset":0,"length":42,"style":"textShadowEnable:false"},{"offset":0,"length":42,"style":"hlnk:"},{"offset":0,"length":42,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","isImageActive":false,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"1odli","text":" It makes information harder to understand","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":42,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":42,"style":"hlnkt:wp"},{"offset":0,"length":42,"style":"textOutlineEnable:false"},{"offset":0,"length":42,"style":"opacity:1"},{"offset":0,"length":42,"style":"textShadowColor:ffffff00"},{"offset":0,"length":42,"style":"hlnke:true"},{"offset":0,"length":42,"style":"backgroundColor:unset"},{"offset":0,"length":42,"style":"textShadowX:0px"},{"offset":0,"length":42,"style":"textShadowY:0px"},{"offset":0,"length":42,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":42,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":42,"style":"textShadowBlur:0px"},{"offset":0,"length":42,"style":"textHighlightEnable:false"},{"offset":0,"length":42,"style":"textShadowEnable:false"},{"offset":0,"length":42,"style":"hlnk:"},{"offset":0,"length":42,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"2ta1f","text":" It makes information harder to understand","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":42,"style":"overridden:false"},{"offset":0,"length":42,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":42,"style":"hlnkt:wp"},{"offset":0,"length":42,"style":"textOutlineEnable:false"},{"offset":0,"length":42,"style":"opacity:1"},{"offset":0,"length":42,"style":"textShadowColor:ffffff00"},{"offset":0,"length":42,"style":"hlnke:true"},{"offset":0,"length":42,"style":"backgroundColor:unset"},{"offset":0,"length":42,"style":"textShadowX:0px"},{"offset":0,"length":42,"style":"textShadowY:0px"},{"offset":0,"length":42,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":42,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":42,"style":"textShadowBlur:0px"},{"offset":0,"length":42,"style":"textHighlightEnable:false"},{"offset":0,"length":42,"style":"textShadowEnable:false"},{"offset":0,"length":42,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"isTextActive":true}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:false,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1536]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1536c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1536,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1536',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1548:{
name:'Checkbox_2',
type:10090,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1548c',
tag:'slide-item-answer-checkbox1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"01534.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"dug30","text":"It facilitates better retention and understanding of complex topics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":67,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":67,"style":"hlnkt:wp"},{"offset":0,"length":67,"style":"textOutlineEnable:false"},{"offset":0,"length":67,"style":"opacity:1"},{"offset":0,"length":67,"style":"textShadowColor:ffffff00"},{"offset":0,"length":67,"style":"hlnke:true"},{"offset":0,"length":67,"style":"backgroundColor:unset"},{"offset":0,"length":67,"style":"textShadowX:0px"},{"offset":0,"length":67,"style":"textShadowY:0px"},{"offset":0,"length":67,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":67,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":67,"style":"textShadowBlur:0px"},{"offset":0,"length":67,"style":"textHighlightEnable:false"},{"offset":0,"length":67,"style":"textShadowEnable:false"},{"offset":0,"length":67,"style":"hlnk:"},{"offset":0,"length":67,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-uic-4"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"f54is","text":"It facilitates better retention and understanding of complex topics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":67,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":67,"style":"hlnkt:wp"},{"offset":0,"length":67,"style":"textOutlineEnable:false"},{"offset":0,"length":67,"style":"opacity:1"},{"offset":0,"length":67,"style":"textShadowColor:ffffff00"},{"offset":0,"length":67,"style":"hlnke:true"},{"offset":0,"length":67,"style":"backgroundColor:unset"},{"offset":0,"length":67,"style":"textShadowX:0px"},{"offset":0,"length":67,"style":"textShadowY:0px"},{"offset":0,"length":67,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":67,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":67,"style":"textShadowBlur:0px"},{"offset":0,"length":67,"style":"textHighlightEnable:false"},{"offset":0,"length":67,"style":"textShadowEnable:false"},{"offset":0,"length":67,"style":"hlnk:"},{"offset":0,"length":67,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"50%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"d9h06","text":"It facilitates better retention and understanding of complex topics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":67,"style":"overridden:false"},{"offset":0,"length":67,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":67,"style":"hlnkt:wp"},{"offset":0,"length":67,"style":"textOutlineEnable:false"},{"offset":0,"length":67,"style":"opacity:1"},{"offset":0,"length":67,"style":"textShadowColor:ffffff00"},{"offset":0,"length":67,"style":"hlnke:true"},{"offset":0,"length":67,"style":"backgroundColor:unset"},{"offset":0,"length":67,"style":"textShadowX:0px"},{"offset":0,"length":67,"style":"textShadowY:0px"},{"offset":0,"length":67,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":67,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":67,"style":"textShadowBlur:0px"},{"offset":0,"length":67,"style":"textHighlightEnable:false"},{"offset":0,"length":67,"style":"textShadowEnable:false"},{"offset":0,"length":67,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","isImageActive":false,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"uhuo","text":"It facilitates better retention and understanding of complex topics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":67,"style":"overridden:false"},{"offset":0,"length":67,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":67,"style":"hlnkt:wp"},{"offset":0,"length":67,"style":"textOutlineEnable:false"},{"offset":0,"length":67,"style":"opacity:1"},{"offset":0,"length":67,"style":"textShadowColor:ffffff00"},{"offset":0,"length":67,"style":"hlnke:true"},{"offset":0,"length":67,"style":"backgroundColor:unset"},{"offset":0,"length":67,"style":"textShadowX:0px"},{"offset":0,"length":67,"style":"textShadowY:0px"},{"offset":0,"length":67,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":67,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":67,"style":"textShadowBlur:0px"},{"offset":0,"length":67,"style":"textHighlightEnable:false"},{"offset":0,"length":67,"style":"textShadowEnable:false"},{"offset":0,"length":67,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"bi9bm","text":"It facilitates better retention and understanding of complex topics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":67,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":67,"style":"hlnkt:wp"},{"offset":0,"length":67,"style":"textOutlineEnable:false"},{"offset":0,"length":67,"style":"opacity:1"},{"offset":0,"length":67,"style":"textShadowColor:ffffff00"},{"offset":0,"length":67,"style":"hlnke:true"},{"offset":0,"length":67,"style":"backgroundColor:unset"},{"offset":0,"length":67,"style":"textShadowX:0px"},{"offset":0,"length":67,"style":"textShadowY:0px"},{"offset":0,"length":67,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":67,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":67,"style":"textShadowBlur:0px"},{"offset":0,"length":67,"style":"textHighlightEnable:false"},{"offset":0,"length":67,"style":"textShadowEnable:false"},{"offset":0,"length":67,"style":"hlnk:"},{"offset":0,"length":67,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"isTextActive":true}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:true,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1548]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1548c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1548,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1548',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1560:{
name:'Button_8',
type:29,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1560c',
tag:'slide-item-submit-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"djutd","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"eg0m4","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bg001","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3985g","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a6rk5","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1560]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1560c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1560,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1560',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1623:{
name:'Button_12',
type:29,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1623c',
tag:'slide-item-view-answer-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0546.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ancf8","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7opa","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5tkln","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2439u","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"861t1","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOptionStyles":{"all":{"marginRight":"auto"},"tablet":{},"mobile":{"marginRight":"unset"}}}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:6,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1623]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1623c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1623,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1623',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1632:{
name:'Button_13',
type:29,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1632c',
tag:'slide-item-review-back-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"doo9","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7a40b","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9076f","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"43cmr","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dvo1c","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:5,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1632]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1632c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1632,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1632',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1647:{
name:'Button_14',
type:29,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1647c',
tag:'slide-item-review-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dt3gi","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dmnm1","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3cmh6","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a58qa","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"c1ja8","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:4,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1647]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1647c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1647,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1647',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2651:{
name:'Checkbox_3',
type:10090,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si2651c',
tag:'slide-item-answer-checkbox2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"01534.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"8o784","text":"It reduces the need for learners to actively process information","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":64,"style":"overridden:false"},{"offset":0,"length":64,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":64,"style":"hlnkt:wp"},{"offset":0,"length":64,"style":"textOutlineEnable:false"},{"offset":0,"length":64,"style":"opacity:1"},{"offset":0,"length":64,"style":"textShadowColor:ffffff00"},{"offset":0,"length":64,"style":"hlnke:true"},{"offset":0,"length":64,"style":"backgroundColor:unset"},{"offset":0,"length":64,"style":"textShadowX:0px"},{"offset":0,"length":64,"style":"textShadowY:0px"},{"offset":0,"length":64,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":64,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":64,"style":"textShadowBlur:0px"},{"offset":0,"length":64,"style":"textHighlightEnable:false"},{"offset":0,"length":64,"style":"textShadowEnable:false"},{"offset":0,"length":64,"style":"hlnk:"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-uic-4"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"enlgh","text":"It reduces the need for learners to actively process information","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":64,"style":"overridden:false"},{"offset":0,"length":64,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":64,"style":"hlnkt:wp"},{"offset":0,"length":64,"style":"textOutlineEnable:false"},{"offset":0,"length":64,"style":"opacity:1"},{"offset":0,"length":64,"style":"textShadowColor:ffffff00"},{"offset":0,"length":64,"style":"hlnke:true"},{"offset":0,"length":64,"style":"backgroundColor:unset"},{"offset":0,"length":64,"style":"textShadowX:0px"},{"offset":0,"length":64,"style":"textShadowY:0px"},{"offset":0,"length":64,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":64,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":64,"style":"textShadowBlur:0px"},{"offset":0,"length":64,"style":"textHighlightEnable:false"},{"offset":0,"length":64,"style":"textShadowEnable:false"},{"offset":0,"length":64,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"50%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"7v04t","text":"It reduces the need for learners to actively process information","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":64,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":64,"style":"hlnkt:wp"},{"offset":0,"length":64,"style":"textOutlineEnable:false"},{"offset":0,"length":64,"style":"opacity:1"},{"offset":0,"length":64,"style":"textShadowColor:ffffff00"},{"offset":0,"length":64,"style":"hlnke:true"},{"offset":0,"length":64,"style":"backgroundColor:unset"},{"offset":0,"length":64,"style":"textShadowX:0px"},{"offset":0,"length":64,"style":"textShadowY:0px"},{"offset":0,"length":64,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":64,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":64,"style":"textShadowBlur:0px"},{"offset":0,"length":64,"style":"textHighlightEnable:false"},{"offset":0,"length":64,"style":"textShadowEnable:false"},{"offset":0,"length":64,"style":"hlnk:"},{"offset":0,"length":64,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","isImageActive":false,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"1odli","text":"It reduces the need for learners to actively process information","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":64,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":64,"style":"hlnkt:wp"},{"offset":0,"length":64,"style":"textOutlineEnable:false"},{"offset":0,"length":64,"style":"opacity:1"},{"offset":0,"length":64,"style":"textShadowColor:ffffff00"},{"offset":0,"length":64,"style":"hlnke:true"},{"offset":0,"length":64,"style":"backgroundColor:unset"},{"offset":0,"length":64,"style":"textShadowX:0px"},{"offset":0,"length":64,"style":"textShadowY:0px"},{"offset":0,"length":64,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":64,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":64,"style":"textShadowBlur:0px"},{"offset":0,"length":64,"style":"textHighlightEnable:false"},{"offset":0,"length":64,"style":"textShadowEnable:false"},{"offset":0,"length":64,"style":"hlnk:"},{"offset":0,"length":64,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"2ta1f","text":"It reduces the need for learners to actively process information","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":64,"style":"overridden:false"},{"offset":0,"length":64,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":64,"style":"hlnkt:wp"},{"offset":0,"length":64,"style":"textOutlineEnable:false"},{"offset":0,"length":64,"style":"opacity:1"},{"offset":0,"length":64,"style":"textShadowColor:ffffff00"},{"offset":0,"length":64,"style":"hlnke:true"},{"offset":0,"length":64,"style":"backgroundColor:unset"},{"offset":0,"length":64,"style":"textShadowX:0px"},{"offset":0,"length":64,"style":"textShadowY:0px"},{"offset":0,"length":64,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":64,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":64,"style":"textShadowBlur:0px"},{"offset":0,"length":64,"style":"textHighlightEnable:false"},{"offset":0,"length":64,"style":"textShadowEnable:false"},{"offset":0,"length":64,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"isTextActive":true}',
parentGroup:'si1508',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:false,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2651]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2651c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2651,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2651',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1675:{
name:'Caption_1',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1675c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"994bf","text":"That\'s correct! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"hlnk:"},{"offset":0,"length":55,"style":"hlnkt:wp"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"hlnke:true"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"},{"offset":0,"length":55,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1662',
stl:[{
stn:'Normal',
stt:0,
stsi:[1675]
}
]
,
stis:0,
bstiid:1662,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1662,
isDD:false
},
si1675c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1675,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1675',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1686:{
name:'Caption_1',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1686c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"2i9ia","text":"That\'s incorrect! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"hlnk:"},{"offset":0,"length":57,"style":"hlnkt:wp"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"hlnke:true"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1662',
stl:[{
stn:'Normal',
stt:0,
stsi:[1686]
}
]
,
stis:0,
bstiid:1662,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1662,
isDD:false
},
si1686c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1686,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1686',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1697:{
name:'Caption_1',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1697c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b3pmq","text":"You must answer the question before continuing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":46,"style":"hlnk:"},{"offset":0,"length":46,"style":"hlnkt:wp"},{"offset":0,"length":46,"style":"textOutlineEnable:false"},{"offset":0,"length":46,"style":"opacity:1"},{"offset":0,"length":46,"style":"hlnke:true"},{"offset":0,"length":46,"style":"backgroundColor:unset"},{"offset":0,"length":46,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":46,"style":"textHighlightEnable:false"},{"offset":0,"length":46,"style":"textShadowEnable:false"},{"offset":0,"length":46,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1662',
stl:[{
stn:'Normal',
stt:0,
stsi:[1697]
}
]
,
stis:0,
bstiid:1662,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1662,
isDD:false
},
si1697c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1697,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1697',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1662:{
name:'Caption_1',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1662c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"95b13","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1673,
stt:0,
dsr:'Default_State',
stsi:[1662]
}
,{
stn:1674,
stt:101,
dsr:'Correct',
stsi:[1675]
}
,{
stn:1685,
stt:102,
dsr:'Incorrect',
stsi:[1686]
}
,{
stn:1696,
stt:104,
dsr:'Incomplete',
stsi:[1697]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1662','si1675','si1686','si1697','si2002','si2013'],
isDD:false
},
si1662c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1662,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1662',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2002:{
name:'Caption_1',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si2002c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"aa0mu","text":"That\'s incorrect! Try again.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"hlnke:true"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_retry","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1662',
stl:[{
stn:'Normal',
stt:0,
stsi:[2002]
}
]
,
stis:0,
bstiid:1662,
sipst:105,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1662,
isDD:false
},
si2002c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2002,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2002',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si2013:{
name:'Caption_1',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si2013c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"79qaa","text":"Here is a hint to help you answer the question.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":47,"style":"hlnk:"},{"offset":0,"length":47,"style":"hlnkt:wp"},{"offset":0,"length":47,"style":"textOutlineEnable:false"},{"offset":0,"length":47,"style":"opacity:1"},{"offset":0,"length":47,"style":"hlnke:true"},{"offset":0,"length":47,"style":"backgroundColor:unset"},{"offset":0,"length":47,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":47,"style":"textHighlightEnable:false"},{"offset":0,"length":47,"style":"textShadowEnable:false"},{"offset":0,"length":47,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_hint","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1662',
stl:[{
stn:'Normal',
stt:0,
stsi:[2013]
}
]
,
stis:0,
bstiid:1662,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1662,
isDD:false
},
si2013c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2013,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2013',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1720:{
name:'Caption_2',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1720c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"90mr4","text":"Your answer is correct","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1707',
stl:[{
stn:'Normal',
stt:0,
stsi:[1720]
}
]
,
stis:0,
bstiid:1707,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1707,
isDD:false
},
si1720c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1720,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1720',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1731:{
name:'Caption_2',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1731c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"9tf9q","text":"Your answer is incorrect","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"overridden:false"},{"offset":0,"length":24,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1707',
stl:[{
stn:'Normal',
stt:0,
stsi:[1731]
}
]
,
stis:0,
bstiid:1707,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1707,
isDD:false
},
si1731c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1731,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1731',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1742:{
name:'Caption_2',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1742c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"7d3gc","text":"You did not answer this question completely","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":43,"style":"hlnk:"},{"offset":0,"length":43,"style":"hlnkt:wp"},{"offset":0,"length":43,"style":"textOutlineEnable:false"},{"offset":0,"length":43,"style":"opacity:1"},{"offset":0,"length":43,"style":"hlnke:true"},{"offset":0,"length":43,"style":"backgroundColor:unset"},{"offset":0,"length":43,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":43,"style":"textHighlightEnable:false"},{"offset":0,"length":43,"style":"textShadowEnable:false"},{"offset":0,"length":43,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1707',
stl:[{
stn:'Normal',
stt:0,
stsi:[1742]
}
]
,
stis:0,
bstiid:1707,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1707,
isDD:false
},
si1742c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1742,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1742',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1707:{
name:'Caption_2',
type:612,
from:7231,
to:7320,
rp:0,
rpa:0,
mdi:'si1707c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1500',
retainState:false,
immo:false,
apsn:'Slide1455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"6bv51","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1718,
stt:0,
dsr:'Default_State',
stsi:[1707]
}
,{
stn:1719,
stt:101,
dsr:'Correct',
stsi:[1720]
}
,{
stn:1730,
stt:102,
dsr:'Incorrect',
stsi:[1731]
}
,{
stn:1741,
stt:104,
dsr:'Incomplete',
stsi:[1742]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1707','si1720','si1731','si1742'],
isDD:false
},
si1707c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1707,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1707',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1455:{
lb:'Question _2',
id:1455,
from:7231,
to:7320,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1455c',
st:'Question Slide',
sk:'Multiple choice',
slideTag:'multiple-choice-slide',
type:77,
accProps:{
}
,
si:[{
n:'si1500',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/0498.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:498,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
osa:'{"scripts":[{"then":[["cp.jumpToNextSlide(1490);"]]}]}',
ofa:'{"scripts":[{"then":[["cp.jumpToNextSlide(1499);"]]}]}',
bph:[]
,
bookmarks:[]
,
qs:'Slide1455q1',
qnq:1,
pa:7274,
iph:{
1490:{
ts:'',
tr:''
}
,
1499:{
ts:'',
tr:''
}

}

},
Slide1455c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1455,
dn:'Slide1455',
visible:'1'
},
Slide1455q1:{
noa:1,
qt:'',
it:true,
is:false,
ipq:false,
ikc:false,
sat:true,
qst:0,
ish:false,
ips:false,
hma:false,
qnq:1,
sn:'Slide1455',
oid:'Quiz_2024410194512',
iid:'1476',
sra:true,
w:1,
nw:0,
itp:'choice',
qtp:'MCQ',
gn:'Slide1455_ag',
tl:0,
sfrc:false,
frc:'',
ifc:[],
ofct:false,
ao:['si1536c:0','si1548c:1','si2651c:2'],
qtc:'',
JSONTT_4:[],
JSONTT_5:[],
oic:'',
sic:false,
osc:'',
osct:false,
qmas:1,
amfitb:-1,
csfitb:false,
quizNumberingEnabled:false,
quizNumberingType:26,
ail:['si1536','si1548','si2651'],
cal:['si1548']
},
si3000:{
name:'ResponsiveContainer_51',
type:1268,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3000c',
tag:'container-multiple-choice',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3008',
t:1268
}
,{
n:'si3157',
t:612
}
,{
n:'si3202',
t:612
}
]
,
containerType:'multiple-choice',
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3000c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3000,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3000',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3008:{
name:'ResponsiveContainer_52',
type:1268,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3008c',
tag:'container-multiple-choice-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-review-back-button":true,"slide-item-skip-button":false,"slide-item-submit-button":true,"slide-item-progress-indicator":true,"slide-item-clear-button":false,"card":false,"slide-item-answer-checkbox":true,"slide-item-review-next-button":true,"slide-item-question-text":true,"slide-item-view-answer-button":true,"slide-item-back-button":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":3},"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"container-answer-area":{"all":{"display":"flex","flexDirection":"column","margin":"40px 6px 0px 6px","rowGap":"20px"},"tablet":{},"mobile":{}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"80px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3016',
t:1250
}
,{
n:'si3025',
t:1250
}
,{
n:'si3034',
t:10090
}
,{
n:'si3046',
t:10090
}
,{
n:'si3058',
t:29
}
,{
n:'si3118',
t:29
}
,{
n:'si3127',
t:29
}
,{
n:'si3142',
t:29
}
,{
n:'si3247',
t:10090
}
]
,
containerType:'multiple-choice-card',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-review-back-button":true,"slide-item-skip-button":false,"slide-item-submit-button":true,"slide-item-progress-indicator":true,"slide-item-clear-button":false,"card":false,"slide-item-answer-checkbox":true,"slide-item-review-next-button":true,"slide-item-question-text":true,"slide-item-view-answer-button":true,"slide-item-back-button":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":3},"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"container-answer-area":{"all":{"display":"flex","flexDirection":"column","margin":"40px 6px 0px 6px","rowGap":"20px"},"tablet":{},"mobile":{}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"80px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3000',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3008c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3008,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3008',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3016:{
name:'Text_32',
type:1250,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3016c',
tag:'slide-item-progress-indicator',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"editable":false,"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{"marginBottom":"16px"},"tablet":{},"mobile":{}}}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"auv8q","text":"Question @#{101} / @#{102}","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":26,"style":"hlnkt:wp"},{"offset":0,"length":26,"style":"textOutlineEnable:false"},{"offset":0,"length":26,"style":"opacity:1"},{"offset":0,"length":26,"style":"hlnke:true"},{"offset":0,"length":26,"style":"backgroundColor:unset"},{"offset":0,"length":26,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":26,"style":"textHighlightEnable:false"},{"offset":0,"length":26,"style":"textShadowEnable:false"},{"offset":0,"length":26,"style":"overridden:false"},{"offset":0,"length":26,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-detail-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:14,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3016]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3016c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3016,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3016',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3025:{
name:'Text_33',
type:1250,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3025c',
tag:'slide-item-question-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7ru3j","text":"How can you apply the segmenting principle when creating instructional materials?","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":81,"style":"textOutlineEnable:false"},{"offset":0,"length":81,"style":"opacity:1"},{"offset":0,"length":81,"style":"hlnke:true"},{"offset":0,"length":81,"style":"backgroundColor:unset"},{"offset":0,"length":81,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":81,"style":"textHighlightEnable:false"},{"offset":0,"length":81,"style":"textShadowEnable:false"},{"offset":0,"length":81,"style":"overridden:false"},{"offset":0,"length":81,"style":"hlnk:"},{"offset":0,"length":81,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-heading-6"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3025]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3025c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3025,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3025',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si3034:{
name:'Checkbox_6',
type:10090,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3034c',
tag:'slide-item-answer-checkbox0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"01534.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"8o784","text":"By presenting all information at once","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"textShadowColor:ffffff00"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"textShadowX:0px"},{"offset":0,"length":37,"style":"textShadowY:0px"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":37,"style":"textShadowBlur:0px"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-uic-4"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"enlgh","text":"By presenting all information at once","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"textShadowColor:ffffff00"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"textShadowX:0px"},{"offset":0,"length":37,"style":"textShadowY:0px"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":37,"style":"textShadowBlur:0px"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"50%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"7v04t","text":"By presenting all information at once","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"textShadowY:0px"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":37,"style":"textShadowBlur:0px"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"overridden:false"},{"offset":0,"length":37,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"textShadowColor:ffffff00"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","isImageActive":false,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"1odli","text":"By presenting all information at once","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"textShadowY:0px"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":37,"style":"textShadowBlur:0px"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"overridden:false"},{"offset":0,"length":37,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"textShadowColor:ffffff00"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"2ta1f","text":"By presenting all information at once","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"textShadowColor:ffffff00"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"textShadowX:0px"},{"offset":0,"length":37,"style":"textShadowY:0px"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":37,"style":"textShadowBlur:0px"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"isTextActive":true}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:false,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3034]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3034c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3034,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3034',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3046:{
name:'Checkbox_7',
type:10090,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3046c',
tag:'slide-item-answer-checkbox1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"01534.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"dug30","text":"By using only text-based information without any visuals","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"textShadowColor:ffffff00"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"textShadowX:0px"},{"offset":0,"length":56,"style":"textShadowY:0px"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":56,"style":"textShadowBlur:0px"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-uic-4"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"f54is","text":"By using only text-based information without any visuals","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"textShadowColor:ffffff00"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"textShadowX:0px"},{"offset":0,"length":56,"style":"textShadowY:0px"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":56,"style":"textShadowBlur:0px"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"50%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"d9h06","text":"By using only text-based information without any visuals","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"textShadowY:0px"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":56,"style":"textShadowBlur:0px"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"overridden:false"},{"offset":0,"length":56,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"textShadowColor:ffffff00"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","isImageActive":false,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"uhuo","text":"By using only text-based information without any visuals","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"textShadowY:0px"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":56,"style":"textShadowBlur:0px"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"overridden:false"},{"offset":0,"length":56,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"textShadowColor:ffffff00"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"bi9bm","text":"By using only text-based information without any visuals","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"textShadowColor:ffffff00"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"textShadowX:0px"},{"offset":0,"length":56,"style":"textShadowY:0px"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":56,"style":"textShadowBlur:0px"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"isTextActive":true}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:false,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3046]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3046c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3046,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3046',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3058:{
name:'Button_30',
type:29,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3058c',
tag:'slide-item-submit-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"djutd","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"eg0m4","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bg001","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3985g","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a6rk5","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3058]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3058c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3058,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3058',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3118:{
name:'Button_34',
type:29,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3118c',
tag:'slide-item-view-answer-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0546.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ancf8","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7opa","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5tkln","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2439u","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"861t1","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOptionStyles":{"all":{"marginRight":"auto"},"tablet":{},"mobile":{"marginRight":"unset"}}}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:6,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3118]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3118c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3118,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3118',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3127:{
name:'Button_35',
type:29,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3127c',
tag:'slide-item-review-back-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"doo9","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7a40b","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9076f","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"43cmr","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dvo1c","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:5,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3127]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3127c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3127,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3127',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3142:{
name:'Button_36',
type:29,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3142c',
tag:'slide-item-review-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dt3gi","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dmnm1","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3cmh6","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a58qa","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"c1ja8","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:4,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3142]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3142c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3142,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3142',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3247:{
name:'Checkbox_8',
type:10090,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3247c',
tag:'slide-item-answer-checkbox2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"01534.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"rowGap":16,"fontSize":18}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"8o784","text":"By breaking down content into smaller, manageable segments","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":58,"style":"textShadowY:0px"},{"offset":0,"length":58,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":58,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":58,"style":"textShadowBlur:0px"},{"offset":0,"length":58,"style":"textHighlightEnable:false"},{"offset":0,"length":58,"style":"textShadowEnable:false"},{"offset":0,"length":58,"style":"hlnk:"},{"offset":0,"length":58,"style":"overridden:false"},{"offset":0,"length":58,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":58,"style":"hlnkt:wp"},{"offset":0,"length":58,"style":"textOutlineEnable:false"},{"offset":0,"length":58,"style":"opacity:1"},{"offset":0,"length":58,"style":"textShadowColor:ffffff00"},{"offset":0,"length":58,"style":"hlnke:true"},{"offset":0,"length":58,"style":"backgroundColor:unset"},{"offset":0,"length":58,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-uic-4"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"enlgh","text":"By breaking down content into smaller, manageable segments","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":58,"style":"textShadowY:0px"},{"offset":0,"length":58,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":58,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":58,"style":"textShadowBlur:0px"},{"offset":0,"length":58,"style":"textHighlightEnable:false"},{"offset":0,"length":58,"style":"textShadowEnable:false"},{"offset":0,"length":58,"style":"hlnk:"},{"offset":0,"length":58,"style":"overridden:false"},{"offset":0,"length":58,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":58,"style":"hlnkt:wp"},{"offset":0,"length":58,"style":"textOutlineEnable:false"},{"offset":0,"length":58,"style":"opacity:1"},{"offset":0,"length":58,"style":"textShadowColor:ffffff00"},{"offset":0,"length":58,"style":"hlnke:true"},{"offset":0,"length":58,"style":"backgroundColor:unset"},{"offset":0,"length":58,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color0)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"50%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"7v04t","text":"By breaking down content into smaller, manageable segments","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":58,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":58,"style":"hlnkt:wp"},{"offset":0,"length":58,"style":"textOutlineEnable:false"},{"offset":0,"length":58,"style":"opacity:1"},{"offset":0,"length":58,"style":"textShadowColor:ffffff00"},{"offset":0,"length":58,"style":"hlnke:true"},{"offset":0,"length":58,"style":"backgroundColor:unset"},{"offset":0,"length":58,"style":"textShadowX:0px"},{"offset":0,"length":58,"style":"textShadowY:0px"},{"offset":0,"length":58,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":58,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":58,"style":"textShadowBlur:0px"},{"offset":0,"length":58,"style":"textHighlightEnable:false"},{"offset":0,"length":58,"style":"textShadowEnable:false"},{"offset":0,"length":58,"style":"hlnk:"},{"offset":0,"length":58,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"designOption":"DEFAULT_QUIZ_CHECKBOX_ITEM_OPTION","isImageActive":false,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"1odli","text":"By breaking down content into smaller, manageable segments","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":58,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":58,"style":"hlnkt:wp"},{"offset":0,"length":58,"style":"textOutlineEnable:false"},{"offset":0,"length":58,"style":"opacity:1"},{"offset":0,"length":58,"style":"textShadowColor:ffffff00"},{"offset":0,"length":58,"style":"hlnke:true"},{"offset":0,"length":58,"style":"backgroundColor:unset"},{"offset":0,"length":58,"style":"textShadowX:0px"},{"offset":0,"length":58,"style":"textShadowY:0px"},{"offset":0,"length":58,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":58,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":58,"style":"textShadowBlur:0px"},{"offset":0,"length":58,"style":"textHighlightEnable:false"},{"offset":0,"length":58,"style":"textShadowEnable:false"},{"offset":0,"length":58,"style":"hlnk:"},{"offset":0,"length":58,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"2ta1f","text":"By breaking down content into smaller, manageable segments","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":58,"style":"textShadowY:0px"},{"offset":0,"length":58,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":58,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":58,"style":"textShadowBlur:0px"},{"offset":0,"length":58,"style":"textHighlightEnable:false"},{"offset":0,"length":58,"style":"textShadowEnable:false"},{"offset":0,"length":58,"style":"hlnk:"},{"offset":0,"length":58,"style":"overridden:false"},{"offset":0,"length":58,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":58,"style":"hlnkt:wp"},{"offset":0,"length":58,"style":"textOutlineEnable:false"},{"offset":0,"length":58,"style":"opacity:1"},{"offset":0,"length":58,"style":"textShadowColor:ffffff00"},{"offset":0,"length":58,"style":"hlnke:true"},{"offset":0,"length":58,"style":"backgroundColor:unset"},{"offset":0,"length":58,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true}},"isTextActive":true}',
parentGroup:'si3008',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:true,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3247]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3247c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3247,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3247',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3170:{
name:'Caption_6',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3170c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"994bf","text":"That\'s correct! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"hlnk:"},{"offset":0,"length":55,"style":"hlnkt:wp"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"hlnke:true"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"},{"offset":0,"length":55,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3157',
stl:[{
stn:'Normal',
stt:0,
stsi:[3170]
}
]
,
stis:0,
bstiid:3157,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3157,
isDD:false
},
si3170c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3170,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3170',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3181:{
name:'Caption_6',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3181c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"2i9ia","text":"That\'s incorrect! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"hlnk:"},{"offset":0,"length":57,"style":"hlnkt:wp"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"hlnke:true"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3157',
stl:[{
stn:'Normal',
stt:0,
stsi:[3181]
}
]
,
stis:0,
bstiid:3157,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3157,
isDD:false
},
si3181c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3181,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3181',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3192:{
name:'Caption_6',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3192c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b3pmq","text":"You must answer the question before continuing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":46,"style":"hlnk:"},{"offset":0,"length":46,"style":"hlnkt:wp"},{"offset":0,"length":46,"style":"textOutlineEnable:false"},{"offset":0,"length":46,"style":"opacity:1"},{"offset":0,"length":46,"style":"hlnke:true"},{"offset":0,"length":46,"style":"backgroundColor:unset"},{"offset":0,"length":46,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":46,"style":"textHighlightEnable:false"},{"offset":0,"length":46,"style":"textShadowEnable:false"},{"offset":0,"length":46,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3157',
stl:[{
stn:'Normal',
stt:0,
stsi:[3192]
}
]
,
stis:0,
bstiid:3157,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3157,
isDD:false
},
si3192c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3192,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3192',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3157:{
name:'Caption_6',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3157c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"95b13","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3168,
stt:0,
dsr:'Default_State',
stsi:[3157]
}
,{
stn:3169,
stt:101,
dsr:'Correct',
stsi:[3170]
}
,{
stn:3180,
stt:102,
dsr:'Incorrect',
stsi:[3181]
}
,{
stn:3191,
stt:104,
dsr:'Incomplete',
stsi:[3192]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3157','si3170','si3181','si3192'],
isDD:false
},
si3157c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3157,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3157',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3215:{
name:'Caption_7',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3215c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"90mr4","text":"Your answer is correct","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3202',
stl:[{
stn:'Normal',
stt:0,
stsi:[3215]
}
]
,
stis:0,
bstiid:3202,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3202,
isDD:false
},
si3215c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3215,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3215',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3226:{
name:'Caption_7',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3226c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"9tf9q","text":"Your answer is incorrect","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"overridden:false"},{"offset":0,"length":24,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3202',
stl:[{
stn:'Normal',
stt:0,
stsi:[3226]
}
]
,
stis:0,
bstiid:3202,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3202,
isDD:false
},
si3226c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3226,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3226',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3237:{
name:'Caption_7',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3237c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"7d3gc","text":"You did not answer this question completely","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":43,"style":"hlnk:"},{"offset":0,"length":43,"style":"hlnkt:wp"},{"offset":0,"length":43,"style":"textOutlineEnable:false"},{"offset":0,"length":43,"style":"opacity:1"},{"offset":0,"length":43,"style":"hlnke:true"},{"offset":0,"length":43,"style":"backgroundColor:unset"},{"offset":0,"length":43,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":43,"style":"textHighlightEnable:false"},{"offset":0,"length":43,"style":"textShadowEnable:false"},{"offset":0,"length":43,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3202',
stl:[{
stn:'Normal',
stt:0,
stsi:[3237]
}
]
,
stis:0,
bstiid:3202,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3202,
isDD:false
},
si3237c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3237,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3237',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3202:{
name:'Caption_7',
type:612,
from:7321,
to:7410,
rp:0,
rpa:0,
mdi:'si3202c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3000',
retainState:false,
immo:false,
apsn:'Slide2955',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"6bv51","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3213,
stt:0,
dsr:'Default_State',
stsi:[3202]
}
,{
stn:3214,
stt:101,
dsr:'Correct',
stsi:[3215]
}
,{
stn:3225,
stt:102,
dsr:'Incorrect',
stsi:[3226]
}
,{
stn:3236,
stt:104,
dsr:'Incomplete',
stsi:[3237]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3202','si3215','si3226','si3237'],
isDD:false
},
si3202c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3202,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3202',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2955:{
lb:'Question _3',
id:2955,
from:7321,
to:7410,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2955c',
st:'Question Slide',
sk:'Multiple choice',
slideTag:'multiple-choice-slide',
type:77,
accProps:{
}
,
si:[{
n:'si3000',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/0498.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:498,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
osa:'{"scripts":[{"then":[["cp.jumpToNextSlide(2990);"]]}]}',
ofa:'{"scripts":[{"then":[["cp.jumpToNextSlide(2999);"]]}]}',
bph:[]
,
bookmarks:[]
,
qs:'Slide2955q2',
qnq:2,
pa:7364,
iph:{
2990:{
ts:'',
tr:''
}
,
2999:{
ts:'',
tr:''
}

}

},
Slide2955c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2955,
dn:'Slide2955',
visible:'1'
},
Slide2955q2:{
noa:1,
qt:'',
it:true,
is:false,
ipq:false,
ikc:false,
sat:true,
qst:0,
ish:false,
ips:false,
hma:false,
qnq:2,
sn:'Slide2955',
oid:'Quiz_2024410194512',
iid:'2976',
sra:true,
w:1,
nw:0,
itp:'choice',
qtp:'MCQ',
gn:'Slide2955_ag',
tl:0,
sfrc:false,
frc:'',
ifc:[],
ofct:false,
ao:['si3034c:0','si3046c:1','si3247c:2'],
qtc:'',
JSONTT_4:[],
JSONTT_5:[],
oic:'',
sic:false,
osc:'',
osct:false,
qmas:1,
amfitb:-1,
csfitb:false,
quizNumberingEnabled:false,
quizNumberingType:26,
ail:['si3034','si3046','si3247'],
cal:['si3247']
},
si1789:{
name:'Result_2',
type:1268,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1789c',
tag:'container-result',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"name":"ResultSlideWidget","isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1797',
t:1268
}
,{
n:'si1967',
t:612
}
]
,
containerType:'result',
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"name":"ResultSlideWidget","isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1789c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1789,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1789',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1797:{
name:'Result_Group_1',
type:1268,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1797c',
tag:'container-result-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1805',
t:1250
}
,{
n:'si1814',
t:1250
}
,{
n:'si1823',
t:1250
}
,{
n:'si1832',
t:1250
}
,{
n:'si1841',
t:1250
}
,{
n:'si1850',
t:1250
}
,{
n:'si1859',
t:1250
}
,{
n:'si1868',
t:1250
}
,{
n:'si1877',
t:1250
}
,{
n:'si1886',
t:1250
}
,{
n:'si1895',
t:1250
}
,{
n:'si1904',
t:1250
}
,{
n:'si1913',
t:1250
}
,{
n:'si1922',
t:29
}
,{
n:'si1937',
t:29
}
,{
n:'si1952',
t:29
}
]
,
containerType:'result-card',
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1789',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1797c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1797,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1797',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1805:{
name:'Text_11',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1805c',
tag:'slide-item-result-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"justifyContent":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3smmr","text":"Quiz Results","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":12,"style":"hlnk:"},{"offset":0,"length":12,"style":"hlnkt:wp"},{"offset":0,"length":12,"style":"textOutlineEnable:false"},{"offset":0,"length":12,"style":"opacity:1"},{"offset":0,"length":12,"style":"hlnke:true"},{"offset":0,"length":12,"style":"backgroundColor:unset"},{"offset":0,"length":12,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":12,"style":"textHighlightEnable:false"},{"offset":0,"length":12,"style":"textShadowEnable:false"},{"offset":0,"length":12,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1805]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1805c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1805,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1805',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1814:{
name:'Text_12',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1814c',
tag:'user-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6i4da","text":"You scored:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1814]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1814c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1814,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1814',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1823:{
name:'Text_13',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1823c',
tag:'user-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[373],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"be6nr","text":"$$Quiz.Score$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1823]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1823c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1823,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1823',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1832:{
name:'Text_14',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1832c',
tag:'max-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2p05j","text":"Maximum score:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1832]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1832c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1832,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1832',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1841:{
name:'Text_15',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1841c',
tag:'max-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[377],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4jqm7","text":"$$Quiz.MaxScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"overridden:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1841]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1841c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1841,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1841',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1850:{
name:'Text_16',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1850c',
tag:'correct-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3q438","text":"Correct responses:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1850]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1850c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1850,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1850',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1859:{
name:'Text_17',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1859c',
tag:'correct-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[376],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8e03d","text":"$$Quiz.CorrectAnswerCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1859]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1859c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1859,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1859',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1868:{
name:'Text_18',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1868c',
tag:'total-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"eqsgs","text":"Total questions:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"overridden:false"},{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"hlnkt:wp"},{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"hlnke:true"},{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1868]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1868c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1868,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1868',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1877:{
name:'Text_19',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1877c',
tag:'total-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[378],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c88b9","text":"$$Quiz.QuestionCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1877]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1877c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1877,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1877',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1886:{
name:'Text_20',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1886c',
tag:'accuracy-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b2kvv","text":"Accuracy:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1886]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1886c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1886,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1886',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1895:{
name:'Text_21',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1895c',
tag:'accuracy-variable',
v:0,
enabled:true,
defEn:true,
vu:[370],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6h1cu","text":"$$Quiz.PercentageScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"overridden:false"},{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1895]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1895c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1895,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1895',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1904:{
name:'Text_22',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1904c',
tag:'attempt-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"d4n5c","text":"Number of attempts:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"opacity:1"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1904]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1904c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1904,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1904',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1913:{
name:'Text_23',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1913c',
tag:'attempt-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[371],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cnc7s","text":"$$Quiz.AttemptCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":21,"style":"hlnk:"},{"offset":0,"length":21,"style":"hlnkt:wp"},{"offset":0,"length":21,"style":"textOutlineEnable:false"},{"offset":0,"length":21,"style":"opacity:1"},{"offset":0,"length":21,"style":"hlnke:true"},{"offset":0,"length":21,"style":"backgroundColor:unset"},{"offset":0,"length":21,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":21,"style":"textHighlightEnable:false"},{"offset":0,"length":21,"style":"textShadowEnable:false"},{"offset":0,"length":21,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1913]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1913c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1913,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1913',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1922:{
name:'Button_15',
type:29,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1922c',
tag:'slide-item-review-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2e38l","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"#34623FFF","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3qs72","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_1","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8qqdc","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"75ahb","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"79e1n","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:7,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1922]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1922c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1922,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1922',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1937:{
name:'Button_16',
type:29,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1937c',
tag:'slide-item-continue-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"c04v3","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7ffos","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"v8q9","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4c0tk","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3lksn","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:8,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1937]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1937c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1937,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1937',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1952:{
name:'Button_17',
type:29,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1952c',
tag:'slide-item-retake-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dshe","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8gsv7","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f3nbu","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"uhfe","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a4jvu","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:9,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1952]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1952c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1952,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1952',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1980:{
name:'Caption_3',
type:612,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1980c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"cmkcm","text":"Congratulations, you passed the quiz!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1967',
stl:[{
stn:'Normal',
stt:0,
stsi:[1980]
}
]
,
stis:0,
bstiid:1967,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1967,
isDD:false
},
si1980c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1980,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1980',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1991:{
name:'Caption_3',
type:612,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1991c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"9er3s","text":"Sorry, you failed the quiz.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"},{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1967',
stl:[{
stn:'Normal',
stt:0,
stsi:[1991]
}
]
,
stis:0,
bstiid:1967,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1967,
isDD:false
},
si1991c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1991,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1991',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1967:{
name:'Caption_3',
type:612,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1967c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"79mgt","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1978,
stt:0,
dsr:'Default_State',
stsi:[1967]
}
,{
stn:1979,
stt:101,
dsr:'Pass',
stsi:[1980]
}
,{
stn:1990,
stt:102,
dsr:'Fail',
stsi:[1991]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1967','si1980','si1991'],
isDD:false
},
si1967c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1967,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1967',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1797:{
name:'Result_Group_1',
type:1268,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1797c',
tag:'container-result-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1805',
t:1250
}
,{
n:'si1814',
t:1250
}
,{
n:'si1823',
t:1250
}
,{
n:'si1832',
t:1250
}
,{
n:'si1841',
t:1250
}
,{
n:'si1850',
t:1250
}
,{
n:'si1859',
t:1250
}
,{
n:'si1868',
t:1250
}
,{
n:'si1877',
t:1250
}
,{
n:'si1886',
t:1250
}
,{
n:'si1895',
t:1250
}
,{
n:'si1904',
t:1250
}
,{
n:'si1913',
t:1250
}
,{
n:'si1922',
t:29
}
,{
n:'si1937',
t:29
}
,{
n:'si1952',
t:29
}
]
,
containerType:'result-card',
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1789',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1797c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1797,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1797',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1805:{
name:'Text_11',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1805c',
tag:'slide-item-result-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"justifyContent":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3smmr","text":"Quiz Results","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":12,"style":"hlnk:"},{"offset":0,"length":12,"style":"hlnkt:wp"},{"offset":0,"length":12,"style":"textOutlineEnable:false"},{"offset":0,"length":12,"style":"opacity:1"},{"offset":0,"length":12,"style":"hlnke:true"},{"offset":0,"length":12,"style":"backgroundColor:unset"},{"offset":0,"length":12,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":12,"style":"textHighlightEnable:false"},{"offset":0,"length":12,"style":"textShadowEnable:false"},{"offset":0,"length":12,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1805]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1805c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1805,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1805',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1814:{
name:'Text_12',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1814c',
tag:'user-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6i4da","text":"You scored:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1814]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1814c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1814,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1814',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1823:{
name:'Text_13',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1823c',
tag:'user-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[373],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"be6nr","text":"$$Quiz.Score$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1823]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1823c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1823,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1823',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1832:{
name:'Text_14',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1832c',
tag:'max-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2p05j","text":"Maximum score:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1832]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1832c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1832,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1832',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1841:{
name:'Text_15',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1841c',
tag:'max-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[377],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4jqm7","text":"$$Quiz.MaxScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"overridden:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1841]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1841c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1841,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1841',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1850:{
name:'Text_16',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1850c',
tag:'correct-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3q438","text":"Correct responses:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1850]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1850c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1850,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1850',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1859:{
name:'Text_17',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1859c',
tag:'correct-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[376],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8e03d","text":"$$Quiz.CorrectAnswerCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1859]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1859c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1859,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1859',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1868:{
name:'Text_18',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1868c',
tag:'total-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"eqsgs","text":"Total questions:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"overridden:false"},{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"hlnkt:wp"},{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"hlnke:true"},{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1868]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1868c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1868,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1868',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1877:{
name:'Text_19',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1877c',
tag:'total-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[378],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c88b9","text":"$$Quiz.QuestionCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1877]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1877c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1877,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1877',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1886:{
name:'Text_20',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1886c',
tag:'accuracy-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b2kvv","text":"Accuracy:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1886]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1886c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1886,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1886',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1895:{
name:'Text_21',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1895c',
tag:'accuracy-variable',
v:0,
enabled:true,
defEn:true,
vu:[370],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6h1cu","text":"$$Quiz.PercentageScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"overridden:false"},{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1895]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1895c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1895,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1895',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1904:{
name:'Text_22',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1904c',
tag:'attempt-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"d4n5c","text":"Number of attempts:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"opacity:1"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1904]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1904c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1904,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1904',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1913:{
name:'Text_23',
type:1250,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1913c',
tag:'attempt-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[371],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cnc7s","text":"$$Quiz.AttemptCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":21,"style":"hlnk:"},{"offset":0,"length":21,"style":"hlnkt:wp"},{"offset":0,"length":21,"style":"textOutlineEnable:false"},{"offset":0,"length":21,"style":"opacity:1"},{"offset":0,"length":21,"style":"hlnke:true"},{"offset":0,"length":21,"style":"backgroundColor:unset"},{"offset":0,"length":21,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":21,"style":"textHighlightEnable:false"},{"offset":0,"length":21,"style":"textShadowEnable:false"},{"offset":0,"length":21,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1913]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1913c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1913,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1913',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1922:{
name:'Button_15',
type:29,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1922c',
tag:'slide-item-review-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2e38l","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"#34623FFF","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3qs72","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_1","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8qqdc","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"75ahb","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"79e1n","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"tablet-fontSize:16"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"mobile-fontSize:16"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"letterSpacing:12%"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"lineHeight:125%"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"textTransform:uppercase"},{"offset":0,"length":11,"style":"borderBottomStyle:none"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"color:#34623F"},{"offset":0,"length":11,"style":"fontFamily:Arial"},{"offset":0,"length":11,"style":"desktop-fontSize:16"},{"offset":0,"length":11,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:7,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1922]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1922c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1922,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1922',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1937:{
name:'Button_16',
type:29,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1937c',
tag:'slide-item-continue-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"c04v3","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7ffos","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","iconProps":{"srcPath":"01417.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"v8q9","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4c0tk","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#34623FFF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color7)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3lksn","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:8,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1937]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1937c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1937,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1937',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1952:{
name:'Button_17',
type:29,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1952c',
tag:'slide-item-retake-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01575.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dshe","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8gsv7","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f3nbu","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"uhfe","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a4jvu","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si1797',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:9,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1952]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1952c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1952,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1952',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1980:{
name:'Caption_3',
type:612,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1980c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"cmkcm","text":"Congratulations, you passed the quiz!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1967',
stl:[{
stn:'Normal',
stt:0,
stsi:[1980]
}
]
,
stis:0,
bstiid:1967,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1967,
isDD:false
},
si1980c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1980,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1980',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1991:{
name:'Caption_3',
type:612,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1991c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"9er3s","text":"Sorry, you failed the quiz.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"},{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1967',
stl:[{
stn:'Normal',
stt:0,
stsi:[1991]
}
]
,
stis:0,
bstiid:1967,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1967,
isDD:false
},
si1991c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1991,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1991',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1967:{
name:'Caption_3',
type:612,
from:7411,
to:7500,
rp:0,
rpa:0,
mdi:'si1967c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1789',
retainState:false,
immo:false,
apsn:'Slide1752',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"79mgt","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1978,
stt:0,
dsr:'Default_State',
stsi:[1967]
}
,{
stn:1979,
stt:101,
dsr:'Pass',
stsi:[1980]
}
,{
stn:1990,
stt:102,
dsr:'Fail',
stsi:[1991]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1967','si1980','si1991'],
isDD:false
},
si1967c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1967,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1967',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1752:{
lb:'Results',
id:1752,
from:7411,
to:7500,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1752c',
st:'Question Slide',
sk:'Quiz Result',
slideTag:'quiz-result-slide',
type:102,
accProps:{
}
,
si:[{
n:'si1789',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/01453.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:1453,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
osa:'{"scripts":[{"then":[["cp.jumpToNextSlide(1779);"]]}]}',
stsi:true,
ofa:'{"scripts":[{"then":[["cp.jumpToNextSlide(1788);"]]}]}',
stfi:true,
bph:[]
,
bookmarks:[]
,
qs:'',
pa:7439,
iph:{
1779:{
ts:'',
tr:''
}
,
1788:{
ts:'',
tr:''
}

}

},
Slide1752c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1752,
dn:'Slide1752',
visible:'1'
},
si3277:{
name:'Paragraph_2',
type:1268,
from:7501,
to:7590,
rp:0,
rpa:0,
mdi:'si3277c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":50,"bottom":50,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide3259',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3285',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"padding":{"top":50,"bottom":50,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'DEFAULT_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3277c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3277,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3277',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3285:{
name:'Paragraph_Group_2',
type:1268,
from:7501,
to:7590,
rp:0,
rpa:0,
mdi:'si3285c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si3277',
retainState:false,
immo:false,
apsn:'Slide3259',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3293',
t:1250
}
,{
n:'si3313',
t:1250
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3277',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3285c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3285,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3285',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3293:{
name:'Text_34',
type:1250,
from:7501,
to:7590,
rp:0,
rpa:0,
mdi:'si3293c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{},"meta":{"textHighlightEnable":true,"textOutlineEnable":true,"textShadowEnable":true}}}',
parentGroup:'si3285',
retainState:false,
immo:false,
apsn:'Slide3259',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9k0kt","text":"Sources","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":7,"style":"tablet-fontSize:72"},{"offset":0,"length":7,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":7,"style":"backgroundColor:unset"},{"offset":0,"length":7,"style":"fontStyle:normal"},{"offset":0,"length":7,"style":"hlnkt:wp"},{"offset":0,"length":7,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":7,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":7,"style":"fontFamily:Krungthep"},{"offset":0,"length":7,"style":"textOutlineEnable:false"},{"offset":0,"length":7,"style":"letterSpacing:-4%"},{"offset":0,"length":7,"style":"opacity:1"},{"offset":0,"length":7,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":7,"style":"hlnke:true"},{"offset":0,"length":7,"style":"defaultTextShadow:none"},{"offset":0,"length":7,"style":"textShadow:none"},{"offset":0,"length":7,"style":"textShadowX:0px"},{"offset":0,"length":7,"style":"fontStretch:normal"},{"offset":0,"length":7,"style":"fontType:regular"},{"offset":0,"length":7,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":7,"style":"textShadowY:4px"},{"offset":0,"length":7,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":7,"style":"desktop-fontSize:80"},{"offset":0,"length":7,"style":"textHighlightEnable:false"},{"offset":0,"length":7,"style":"textTransform:none"},{"offset":0,"length":7,"style":"lineHeight:110%"},{"offset":0,"length":7,"style":"textShadowOpacity:none"},{"offset":0,"length":7,"style":"overridden:true"},{"offset":0,"length":7,"style":"textDecoration:none"},{"offset":0,"length":7,"style":"borderBottomStyle:none"},{"offset":0,"length":7,"style":"mobile-fontSize:60"},{"offset":0,"length":7,"style":"textShadowEnable:false"},{"offset":0,"length":7,"style":"hlnk:"},{"offset":0,"length":7,"style":"fontWeight:normal"},{"offset":0,"length":7,"style":"textShadowBlur:8px"},{"offset":0,"length":7,"style":"color:#34623F"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3293]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3293c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3293,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3293',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si3313:{
name:'Text_36',
type:1250,
from:7501,
to:7590,
rp:0,
rpa:0,
mdi:'si3313c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3285',
retainState:false,
immo:false,
apsn:'Slide3259',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"afen4","text":"Clark, R. C., & Mayer, R. E. (2011). E-learning and the science of instruction : Proven guidelines for consumers and designers of multimedia learning. Center for Creative Leadership.Clark, R. C., & Mayer, R. E. (2011). E-learning and the science of instruction : Proven guidelines for consumers and designers of multimedia learning. Center for Creative Leadership.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":364,"style":"hlnk:"},{"offset":0,"length":364,"style":"hlnkt:wp"},{"offset":0,"length":364,"style":"textOutlineEnable:false"},{"offset":0,"length":364,"style":"opacity:1"},{"offset":0,"length":364,"style":"hlnke:true"},{"offset":0,"length":364,"style":"backgroundColor:unset"},{"offset":0,"length":364,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":364,"style":"textHighlightEnable:false"},{"offset":0,"length":364,"style":"textShadowEnable:false"},{"offset":0,"length":364,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-2"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3313]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3313c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3313,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3313',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
Slide3259:{
lb:'Sources',
id:3259,
from:7501,
to:7590,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3259c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si3277',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/0478.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:478,
w:1920,
h:1080,
tsp:50
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide3259c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3259,
dn:'Slide3259',
visible:'1'
},
quizzingData:{
resultSlideId:'Slide1752',
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:true,
firstSlideInQuiz:6,
lastSlideInQuiz:8,
quizScopeEndSlide:9,
maxScore:3,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:3,
numQuizAttemptsAllowed:1,
passingScore:3,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:3,
quizInfoTotalQuestionsPerProject:3,
quizInfoTotalQuizPoints:3,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:true,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'Quiz_2024410194512',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
quizReportingData:{
lWriteDebugInfo:false,
lmsType:2,
sendScoreAsPercent:true,
trackingLevel:0,
slideViewPercentage:100,
reportingOption:1,
slideViewsForSuccess:100,
slideViewsTypeForSuccess:0,
slideViewsForCompletion:100,
slideViewsTypeForCompletion:0,
quizCriteriaForCompletion:0,
quizCriteriaForSuccess:0,
completionCriteria:2,
successCriteria:2,
companyName:'',
departmentName:'',
courseName:'',
courseNode:'',
isTrackedFlag:true,
trackingUrlEncodeVersionAndSession:0,
commitDataOnEverySlide:false,
trackingSendResumeData:true,
cmiExitNormalAfterCompletion:false,
lmsInitializationString:'cp.movie.playbackController.SetLMSType();cp.movie.playbackController.SetSendScoreAsPercent();cp.movie.playbackController.SetTrackingLevel();cp.movie.playbackController.SetSlideViewPercentage();cp.movie.playbackController.SetReportingOption();cp.movie.playbackController.SetSlideViewsForSuccess();cp.movie.playbackController.SetSlideViewsForCompletion();cp.movie.playbackController.SetQuizCriteriaForCompletion();cp.movie.playbackController.SetQuizCriteriaForSuccess();cp.movie.playbackController.SetCompletionCriteria();cp.movie.playbackController.SetSuccessCriteria();cp.movie.playbackController.SetDirectory();cp.movie.playbackController.SetCourseNode();cp.movie.playbackController.SetIsTrackedFlag();cp.movie.playbackController.SetTrackingUrlEncodeVersionAndSession();cp.movie.playbackController.SetCommitDataOnEverySlide();cp.movie.playbackController.SetTrackingSendResumeData();cp.movie.playbackController.SetCmiExitNormalAfterCompletion();'
},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'The Segmenting Principle',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:3,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:3,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:3,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:3,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1366,
h:768,
iw:1366,
ih:768,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'lab3_multimedia.cpt'
},
projectThemeData:{
image_presets:'{\
  "theme_image_default": {\
    "meta": {\
      "name": "kCPImageStyleNormal",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_default--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_default--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Normal",\
        "mixBlendMode": "normal"\
      }\
    }\
  },\
\
  "theme_image_greyscale": {\
    "meta": {\
      "name": "kCPImageStyleGreyscale",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_greyscale--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Greyscale",\
        "mixBlendMode": "saturation",\
        "intensity": "var(--theme_image_greyscale--intensity)",\
        "filterColor": {\
          "fill": "#000000",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_lighten": {\
    "meta": {\
      "name": "kCPImageStyleLighten",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_lighten--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_lighten--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Lighten",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_lighten--intensity)",\
        "filterColor": {\
          "fill": "#FFFFFF",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_darken": {\
    "meta": {\
      "name": "kCPImageStyleDarken",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_darken--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_darken--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Darken",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_darken--intensity)",\
        "filterColor": {\
          "fill": "var(--black)",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_overlay": {\
    "meta": {\
      "name": "kCPImageStyleOverlay",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_overlay--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_overlay--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Overlay",\
        "mixBlendMode": "overlay",\
        "intensity": "var(--theme_image_overlay--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  },\
\
  "theme_image_colorize": {\
    "meta": {\
      "name": "kCPImageStyleColorize",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_colorize--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_colorize--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Colorize",\
        "mixBlendMode": "color",\
        "intensity": "var(--theme_image_colorize--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  }\
}\
',
meta:'{\
  "name": "kCPThemeLight",\
  "description": "kCPThemeLightDescription",\
  "version": 0.1,\
  "guid": "Default-Light-Theme",\
  "default_presets": {\
    "0": "cp_default_shape_solid_style",\
    "1": "text-body-1",\
    "2": "theme_image_default",\
    "3": "cp_default_slide_style",\
    "4": "cp_textinshape_body_1",\
    "5": "cp_default_line_shape_style",\
    "6": "cp_default_complex_shape_solid_style",\
    "7": "cp_button_style_1_textonly",\
    "8": "cp_checkbox_style_1_textonly",\
    "9": "cp_svg_style",\
    "10": "cp_dropDown_style_1",\
    "11": "cp_radiobutton_style_1_textonly",\
    "12": "cp_inputField_style_1",\
    "13": "cp_clickbox_style",\
    "14": "cp_responsive_container_style",\
    "15": "cp_default_shape_solid_style"\
  },\
  "color_palettes": [\
    {\
      "name": "Light Palette - 1",\
      "colors": [\
        "var(--color1)",\
        "var(--color2)",\
        "var(--color3)",\
        "var(--color4)",\
        "var(--color5)",\
        "var(--color6)",\
        "var(--color7)",\
        "var(--color5_light)",\
        "var(--color4_dark)"\
      ]\
    }\
  ],\
  "active_color_palette": 0\
}',
other_presets:'{\
  "cp_default_slide_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "type": 3,\
      "category": 0\
    },\
    "backgroundColor": "var(--palette-color1)",\
    "outlineColor": "var(--palette-color5)",\
    "outlineWidth": 1,\
    "outlineStyle": "solid",\
    "outlineCap": "butt",\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 0,\
            "y": 0\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_responsive_container_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 14,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": 1,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_correct": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--success)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incorrect": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--error)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incomplete": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--incomplete)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_hint": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--hint)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_retry": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--retry)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_timeout": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--timeout)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color1)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_radial_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}',
theme:'{\
  "--primary": "#F1EEE6",\
\
  "--color1": "#FFFFFF",\
  "--color2": "#F8F7F4",\
  "--color3": "#F1EEE6",\
  "--color4": "#D6D5D1",\
  "--color5": "#666666",\
  "--color6": "#333333",\
  "--color7": "#020C1C",\
  "--colorC7": "#F7F7F7",\
  "--disabledC12": "#989898",\
  "--color1_light": "#FFCD74",\
  "--color1_dark": "#C76D12",\
  "--color2_light": "#86FFFF",\
  "--color2_dark": "#00ACCC",\
  "--color3_light": "#9B5DFF",\
  "--color3_dark": "#0000CA",\
  "--color4_light": "#99FF99",\
  "--color4_dark": "#112FA7",\
  "--color5_light": "#163EE5",\
  "--color5_dark": "#00CB92",\
  "--color6_light": "#7697FF",\
  "--color6_dark": "#0040CB",\
  "--color7_light": "#FF8E64",\
  "--color7_dark": "#C5230B",\
\
  "--success": "#558564",\
  "--error": "#C83E4D",\
  "--hint": "#CB6F10",\
  "--incomplete":"#E8BD2B",\
  "--timeout": "#C74545",\
  "--retry": "#CB6F10",\
  "--white": "#ffffff",\
  "--black": "#000000",\
\
  "--greyscale1": "#FFFFFF",\
  "--greyscale2": "#F1EEE61F",\
  "--greyscale3": "#B3B3B3",\
  "--greyscale4": "#4B4B4B",\
  "--greyscale5": "#333333",\
  "--disabled": "#818181",\
\
  "--palette-color0": "var(--color1)",\
  "--palette-color1": "var(--color2)",\
  "--palette-color2": "var(--color3)",\
  "--palette-color3": "var(--color4)",\
  "--palette-color4": "var(--color5)",\
  "--palette-color5": "var(--color6)",\
  "--palette-color6": "var(--color7)",\
  "--palette-color7": "var(--color5_light)",\
  "--palette-color8": "var(--color4_dark)",\
\
  "--design-option-color1": "255, 255, 255",\
  "--design-option-color2": "248, 247, 244",\
  "--design-option-color3": "241, 238, 230",\
  "--design-option-color4": "214, 213, 209",\
  "--design-option-color5": "102, 102, 102",\
  "--design-option-color6": "51, 51, 51",\
  "--design-option-color7": "2, 12, 28",\
  "--design-option-color5_light": "22, 62, 229",\
  "--design-option-color4_dark": "17, 47, 167",\
\
  "--c1": "var(--design-option-color1)",\
  "--c2": "var(--design-option-color2)",\
  "--c3": "var(--design-option-color3)",\
  "--c4": "var(--design-option-color4)",\
  "--c5": "var(--design-option-color5)",\
  "--c6": "var(--design-option-color6)",\
  "--c7": "var(--design-option-color7)",\
  "--c8": "var(--design-option-color5_light)",\
  "--c9": "var(--design-option-color4_dark)",\
  \
  "--widget-container--fillcolor": "var(--palette-color1)",\
\
  "--font1": "Georgia",\
  "--font2": "Arial",\
  "--text-style-unset": "none",\
\
  "--text-heading-1--fontSize--desktop": "120px",\
  "--text-heading-1--fontSize--tablet": "100px",\
  "--text-heading-1--fontSize--mobile": "80px",\
  "--text-heading-1--fontFamily": "var(--font1)",\
  "--text-heading-1--fontWeight": "normal",\
  "--text-heading-1--fontType": "regular",\
  "--text-heading-1--fontStyle": "normal",\
  "--text-heading-1--fontStretch": "normal",\
  "--text-heading-1--lineHeight": "1.07",\
  "--text-heading-1--marginLeft": "0px",\
  "--text-heading-1--color": "var(--palette-color6)",\
  "--text-heading-1--borderBottomStyle": "none",\
  "--text-heading-1--textDecoration": "none",\
  "--text-heading-1--letterSpacing": "-0.01",\
  "--text-heading-1--textTransform": "none",\
  "--text-heading-1--stroke": "var(--palette-color2)",\
  "--text-heading-1--textAlign": "left",\
  "--text-heading-1--justifyContent": "flex-start",\
  "--text-heading-1--marginTop": "auto",\
  "--text-heading-1--marginBottom": "0",\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-2--fontSize--desktop": "80px",\
  "--text-heading-2--fontSize--tablet": "72px",\
  "--text-heading-2--fontSize--mobile": "60px",\
  "--text-heading-2--fontFamily": "var(--font1)",\
  "--text-heading-2--fontWeight": "normal",\
  "--text-heading-2--fontType": "regular",\
  "--text-heading-2--fontStyle": "normal",\
  "--text-heading-2--fontStretch": "normal",\
  "--text-heading-2--lineHeight": "1.1",\
  "--text-heading-2--marginLeft": "0px",\
  "--text-heading-2--color": "var(--palette-color6)",\
  "--text-heading-2--borderBottomStyle": "none",\
  "--text-heading-2--textDecoration": "none",\
  "--text-heading-2--letterSpacing": "-0.04",\
  "--text-heading-2--textTransform": "none",\
  "--text-heading-2--stroke": "var(--palette-color2)",\
  "--text-heading-2--textAlign": "left",\
  "--text-heading-2--justifyContent": "flex-start",\
  "--text-heading-2--marginTop": "auto",\
  "--text-heading-2--marginBottom": "0",\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-3--fontSize--desktop": "60px",\
  "--text-heading-3--fontSize--tablet": "52px",\
  "--text-heading-3--fontSize--mobile": "44px",\
  "--text-heading-3--fontFamily": "var(--font1)",\
  "--text-heading-3--fontWeight": "normal",\
  "--text-heading-3--fontType": "regular",\
  "--text-heading-3--fontStyle": "normal",\
  "--text-heading-3--fontStretch": "normal",\
  "--text-heading-3--lineHeight": "1.1",\
  "--text-heading-3--marginLeft": "0px",\
  "--text-heading-3--color": "var(--palette-color6)",\
  "--text-heading-3--borderBottomStyle": "none",\
  "--text-heading-3--textDecoration": "none",\
  "--text-heading-3--letterSpacing": "0.03",\
  "--text-heading-3--textTransform": "none",\
  "--text-heading-3--stroke": "var(--palette-color2)",\
  "--text-heading-3--textAlign": "left",\
  "--text-heading-3--justifyContent": "flex-start",\
  "--text-heading-3--marginTop": "auto",\
  "--text-heading-3--marginBottom": "0",\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-4--fontSize--desktop": "52px",\
  "--text-heading-4--fontSize--tablet": "40px",\
  "--text-heading-4--fontSize--mobile": "32px",\
  "--text-heading-4--fontFamily": "var(--font1)",\
  "--text-heading-4--fontWeight": "normal",\
  "--text-heading-4--fontType": "regular",\
  "--text-heading-4--fontStyle": "normal",\
  "--text-heading-4--fontStretch": "normal",\
  "--text-heading-4--lineHeight": "1.15",\
  "--text-heading-4--marginLeft": "0px",\
  "--text-heading-4--color": "var(--palette-color6)",\
  "--text-heading-4--borderBottomStyle": "none",\
  "--text-heading-4--textDecoration": "none",\
  "--text-heading-4--letterSpacing": "0.10",\
  "--text-heading-4--textTransform": "uppercase",\
  "--text-heading-4--stroke": "var(--palette-color2)",\
  "--text-heading-4--textAlign": "left",\
  "--text-heading-4--justifyContent": "flex-start",\
  "--text-heading-4--marginTop": "auto",\
  "--text-heading-4--marginBottom": "0",\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-5--fontSize--desktop": "40px",\
  "--text-heading-5--fontSize--tablet": "32px",\
  "--text-heading-5--fontSize--mobile": "28px",\
  "--text-heading-5--fontFamily": "var(--font1)",\
  "--text-heading-5--fontWeight": "normal",\
  "--text-heading-5--fontType": "regular",\
  "--text-heading-5--fontStyle": "normal",\
  "--text-heading-5--fontStretch": "normal",\
  "--text-heading-5--lineHeight": "1.2",\
  "--text-heading-5--marginLeft": "0px",\
  "--text-heading-5--color": "var(--palette-color6)",\
  "--text-heading-5--borderBottomStyle": "none",\
  "--text-heading-5--textDecoration": "none",\
  "--text-heading-5--letterSpacing": "0",\
  "--text-heading-5--textTransform": "none",\
  "--text-heading-5--stroke": "var(--palette-color2)",\
  "--text-heading-5--textAlign": "left",\
  "--text-heading-5--justifyContent": "flex-start",\
  "--text-heading-5--marginTop": "auto",\
  "--text-heading-5--marginBottom": "0",\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-6--fontSize--desktop": "36px",\
  "--text-heading-6--fontSize--tablet": "28px",\
  "--text-heading-6--fontSize--mobile": "24px",\
  "--text-heading-6--fontFamily": "var(--font2)",\
  "--text-heading-6--fontWeight": "normal",\
  "--text-heading-6--fontType": "regular",\
  "--text-heading-6--fontStyle": "normal",\
  "--text-heading-6--fontStretch": "normal",\
  "--text-heading-6--lineHeight": "1.2",\
  "--text-heading-6--marginLeft": "0px",\
  "--text-heading-6--color": "var(--palette-color6)",\
  "--text-heading-6--borderBottomStyle": "none",\
  "--text-heading-6--textDecoration": "none",\
  "--text-heading-6--letterSpacing": "0",\
  "--text-heading-6--textTransform": "none",\
  "--text-heading-6--stroke": "var(--palette-color2)",\
  "--text-heading-6--textAlign": "left",\
  "--text-heading-6--justifyContent": "flex-start",\
  "--text-heading-6--marginTop": "auto",\
  "--text-heading-6--marginBottom": "0",\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-7--fontSize--desktop": "20px",\
  "--text-heading-7--fontSize--tablet": "20px",\
  "--text-heading-7--fontSize--mobile": "20px",\
  "--text-heading-7--fontFamily": "var(--font1)",\
  "--text-heading-7--fontWeight": "normal",\
  "--text-heading-7--fontType": "regular",\
  "--text-heading-7--fontStyle": "normal",\
  "--text-heading-7--fontStretch": "normal",\
  "--text-heading-7--lineHeight": "1.35",\
  "--text-heading-7--marginLeft": "0px",\
  "--text-heading-7--color": "var(--palette-color5)",\
  "--text-heading-7--borderBottomStyle": "none",\
  "--text-heading-7--textDecoration": "none",\
  "--text-heading-7--letterSpacing": "0",\
  "--text-heading-7--textTransform": "none",\
  "--text-heading-7--stroke": "var(--palette-color2)",\
  "--text-heading-7--textAlign": "left",\
  "--text-heading-7--justifyContent": "flex-start",\
  "--text-heading-7--marginTop": "auto",\
  "--text-heading-7--marginBottom": "0",\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-8--fontSize--desktop": "72px",\
  "--text-heading-8--fontSize--tablet": "48px",\
  "--text-heading-8--fontSize--mobile": "32px",\
  "--text-heading-8--fontFamily": "var(--font1)",\
  "--text-heading-8--fontWeight": "normal",\
  "--text-heading-8--fontType": "regular",\
  "--text-heading-8--fontStyle": "normal",\
  "--text-heading-8--fontStretch": "normal",\
  "--text-heading-8--lineHeight": "1.35",\
  "--text-heading-8--marginLeft": "0px",\
  "--text-heading-8--color": "var(--palette-color5)",\
  "--text-heading-8--borderBottomStyle": "none",\
  "--text-heading-8--textDecoration": "none",\
  "--text-heading-8--letterSpacing": "0",\
  "--text-heading-8--textTransform": "none",\
  "--text-heading-8--stroke": "var(--palette-color2)",\
  "--text-heading-8--textAlign": "center",\
  "--text-heading-8--justifyContent": "flex-start",\
  "--text-heading-8--marginTop": "auto",\
  "--text-heading-8--marginBottom": "0",\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-9--fontSize--desktop": "32px",\
  "--text-heading-9--fontSize--tablet": "32px",\
  "--text-heading-9--fontSize--mobile": "32px",\
  "--text-heading-9--fontFamily": "var(--font1)",\
  "--text-heading-9--fontWeight": "normal",\
  "--text-heading-9--fontType": "regular",\
  "--text-heading-9--fontStyle": "normal",\
  "--text-heading-9--fontStretch": "normal",\
  "--text-heading-9--lineHeight": "1.35",\
  "--text-heading-9--marginLeft": "0px",\
  "--text-heading-9--color": "var(--palette-color5)",\
  "--text-heading-9--borderBottomStyle": "none",\
  "--text-heading-9--textDecoration": "none",\
  "--text-heading-9--letterSpacing": "0",\
  "--text-heading-9--textTransform": "none",\
  "--text-heading-9--stroke": "var(--palette-color2)",\
  "--text-heading-9--textAlign": "center",\
  "--text-heading-9--justifyContent": "flex-start",\
  "--text-heading-9--marginTop": "auto",\
  "--text-heading-9--marginBottom": "0",\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\
\
  "--text-body-1--fontSize--desktop": "22px",\
  "--text-body-1--fontSize--tablet": "20px",\
  "--text-body-1--fontSize--mobile": "18px",\
  "--text-body-1--fontFamily": "var(--font1)",\
  "--text-body-1--fontWeight": "normal",\
  "--text-body-1--fontType": "regular",\
  "--text-body-1--fontStyle": "normal",\
  "--text-body-1--fontStretch": "normal",\
  "--text-body-1--lineHeight": "1.3",\
  "--text-body-1--marginLeft": "0px",\
  "--text-body-1--color": "var(--palette-color5)",\
  "--text-body-1--borderBottomStyle": "none",\
  "--text-body-1--textDecoration": "none",\
  "--text-body-1--letterSpacing": "0",\
  "--text-body-1--textTransform": "none",\
  "--text-body-1--stroke": "var(--palette-color2)",\
  "--text-body-1--textAlign": "left",\
  "--text-body-1--justifyContent": "flex-start",\
  "--text-body-1--marginTop": "auto",\
  "--text-body-1--marginBottom": "0",\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-1--textShadow": "var(--text-style-unset)",\
\
  "--text-body-2--fontSize--desktop": "22px",\
  "--text-body-2--fontSize--tablet": "20px",\
  "--text-body-2--fontSize--mobile": "18px",\
  "--text-body-2--fontFamily": "var(--font2)",\
  "--text-body-2--fontWeight": "normal",\
  "--text-body-2--fontType": "regular",\
  "--text-body-2--fontStyle": "normal",\
  "--text-body-2--fontStretch": "normal",\
  "--text-body-2--lineHeight": "1.3",\
  "--text-body-2--marginLeft": "0px",\
  "--text-body-2--color": "var(--palette-color4)",\
  "--text-body-2--borderBottomStyle": "none",\
  "--text-body-2--textDecoration": "none",\
  "--text-body-2--letterSpacing": "0.03",\
  "--text-body-2--textTransform": "none",\
  "--text-body-2--Stroke": "var(--palette-color2)",\
  "--text-body-2--textAlign": "left",\
  "--text-body-2--justifyContent": "flex-start",\
  "--text-body-2--marginTop": "auto",\
  "--text-body-2--marginBottom": "0",\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-2--textShadow": "var(--text-style-unset)",\
\
  "--text-body-3--fontSize--desktop": "18px",\
  "--text-body-3--fontSize--tablet": "16px",\
  "--text-body-3--fontSize--mobile": "16px",\
  "--text-body-3--fontFamily": "var(--font1)",\
  "--text-body-3--fontWeight": "normal",\
  "--text-body-3--fontType": "regular",\
  "--text-body-3--fontStyle": "normal",\
  "--text-body-3--fontStretch": "normal",\
  "--text-body-3--lineHeight": "1.35",\
  "--text-body-3--marginLeft": "0px",\
  "--text-body-3--color": "var(--palette-color4)",\
  "--text-body-3--borderBottomStyle": "none",\
  "--text-body-3--textDecoration": "none",\
  "--text-body-3--letterSpacing": "0",\
  "--text-body-3--textTransform": "none",\
  "--text-body-3--Stroke": "var(--palette-color2)",\
  "--text-body-3--textAlign": "left",\
  "--text-body-3--justifyContent": "flex-start",\
  "--text-body-3--marginTop": "auto",\
  "--text-body-3--marginBottom": "0",\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-3--textShadow": "var(--text-style-unset)",\
\
  "--text-body-4--fontSize--desktop": "18px",\
  "--text-body-4--fontSize--tablet": "16px",\
  "--text-body-4--fontSize--mobile": "16px",\
  "--text-body-4--fontFamily": "var(--font2)",\
  "--text-body-4--fontWeight": "normal",\
  "--text-body-4--fontType": "regular",\
  "--text-body-4--fontStyle": "normal",\
  "--text-body-4--fontStretch": "normal",\
  "--text-body-4--lineHeight": "1.35",\
  "--text-body-4--marginLeft": "0px",\
  "--text-body-4--color": "var(--palette-color4)",\
  "--text-body-4--borderBottomStyle": "none",\
  "--text-body-4--textDecoration": "none",\
  "--text-body-4--letterSpacing": "0",\
  "--text-body-4--textTransform": "none",\
  "--text-body-4--Stroke": "var(--palette-color2)",\
  "--text-body-4--textAlign": "left",\
  "--text-body-4--justifyContent": "flex-start",\
  "--text-body-4--marginTop": "auto",\
  "--text-body-4--marginBottom": "0",\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-4--textShadow": "var(--text-style-unset)",\
\
  "--text-body-5--fontSize--desktop": "18px",\
  "--text-body-5--fontSize--tablet": "16px",\
  "--text-body-5--fontSize--mobile": "16px",\
  "--text-body-5--fontFamily": "var(--font1)",\
  "--text-body-5--fontWeight": "normal",\
  "--text-body-5--fontType": "italic",\
  "--text-body-5--fontStyle": "normal",\
  "--text-body-5--fontStretch": "normal",\
  "--text-body-5--lineHeight": "1.35",\
  "--text-body-5--marginLeft": "0px",\
  "--text-body-5--color": "var(--palette-color4)",\
  "--text-body-5--borderBottomStyle": "none",\
  "--text-body-5--textDecoration": "none",\
  "--text-body-5--letterSpacing": "0",\
  "--text-body-5--textTransform": "none",\
  "--text-body-5--Stroke": "var(--palette-color2)",\
  "--text-body-5--textAlign": "center",\
  "--text-body-5--justifyContent": "flex-start",\
  "--text-body-5--marginTop": "auto",\
  "--text-body-5--marginBottom": "0",\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-5--textShadow": "var(--text-style-unset)",\
\
  "--text-body-6--fontSize--desktop": "16px",\
  "--text-body-6--fontSize--tablet": "14px",\
  "--text-body-6--fontSize--mobile": "14px",\
  "--text-body-6--fontFamily": "var(--font2)",\
  "--text-body-6--fontWeight": "normal",\
  "--text-body-6--fontType": "regular",\
  "--text-body-6--fontStyle": "normal",\
  "--text-body-6--fontStretch": "normal",\
  "--text-body-6--lineHeight": "1.35",\
  "--text-body-6--marginLeft": "0px",\
  "--text-body-6--color": "var(--palette-color4)",\
  "--text-body-6--borderBottomStyle": "none",\
  "--text-body-6--textDecoration": "none",\
  "--text-body-6--letterSpacing": "0",\
  "--text-body-6--textTransform": "none",\
  "--text-body-6--Stroke": "var(--palette-color2)",\
  "--text-body-6--textAlign": "left",\
  "--text-body-6--justifyContent": "flex-start",\
  "--text-body-6--marginTop": "auto",\
  "--text-body-6--marginBottom": "0",\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-6--textShadow": "var(--text-style-unset)",\
\
  "--text-component-1--fontSize--desktop": "22px",\
  "--text-component-1--fontSize--tablet": "20px",\
  "--text-component-1--fontSize--mobile": "20px",\
  "--text-component-1--fontFamily": "var(--font1)",\
  "--text-component-1--fontWeight": "normal",\
  "--text-component-1--fontType": "regular",\
  "--text-component-1--fontStyle": "normal",\
  "--text-component-1--fontStretch": "normal",\
  "--text-component-1--lineHeight": "1.35",\
  "--text-component-1--marginLeft": "0px",\
  "--text-component-1--color": "var(--color6)",\
  "--text-component-1--borderBottomStyle": "none",\
  "--text-component-1--textDecoration": "none",\
  "--text-component-1--letterSpacing": "0",\
  "--text-component-1--textTransform": "none",\
  "--text-component-1--stroke": "var(--palette-color2)",\
  "--text-component-1--textAlign": "left",\
  "--text-component-1--justifyContent": "flex-start",\
  "--text-component-1--marginTop": "auto",\
  "--text-component-1--marginBottom": "0",\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-1--textShadow": "var(--text-style-unset)",\
\
  "--text-component-2--fontSize--desktop": "24px",\
  "--text-component-2--fontSize--tablet": "20px",\
  "--text-component-2--fontSize--mobile": "20px",\
  "--text-component-2--fontFamily": "var(--font1)",\
  "--text-component-2--fontWeight": "normal",\
  "--text-component-2--fontType": "regular",\
  "--text-component-2--fontStyle": "normal",\
  "--text-component-2--fontStretch": "normal",\
  "--text-component-2--lineHeight": "1.35",\
  "--text-component-2--marginLeft": "0px",\
  "--text-component-2--color": "var(--palette-color1)",\
  "--text-component-2--borderBottomStyle": "none",\
  "--text-component-2--textDecoration": "none",\
  "--text-component-2--letterSpacing": "0.16",\
  "--text-component-2--textTransform": "none",\
  "--text-component-2--stroke": "var(--palette-color2)",\
  "--text-component-2--textAlign": "left",\
  "--text-component-2--justifyContent": "flex-start",\
  "--text-component-2--marginTop": "auto",\
  "--text-component-2--marginBottom": "0",\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-2--textShadow": "var(--text-style-unset)",\
\
  "--text-component-3--fontSize--desktop": "14px",\
  "--text-component-3--fontSize--tablet": "14px",\
  "--text-component-3--fontSize--mobile": "14px",\
  "--text-component-3--fontFamily": "var(--font1)",\
  "--text-component-3--fontWeight": "normal",\
  "--text-component-3--fontType": "regular",\
  "--text-component-3--fontStyle": "normal",\
  "--text-component-3--fontStretch": "normal",\
  "--text-component-3--lineHeight": "1.35",\
  "--text-component-3--marginLeft": "0px",\
  "--text-component-3--color": "var(--palette-color6)",\
  "--text-component-3--borderBottomStyle": "none",\
  "--text-component-3--textDecoration": "none",\
  "--text-component-3--letterSpacing": "0.2",\
  "--text-component-3--textTransform": "uppercase",\
  "--text-component-3--stroke": "var(--palette-color2)",\
  "--text-component-3--textAlign": "center",\
  "--text-component-3--justifyContent": "flex-start",\
  "--text-component-3--marginTop": "auto",\
  "--text-component-3--marginBottom": "0",\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-3--textShadow": "var(--text-style-unset)",\
\
  "--text-component-4--fontSize--desktop": "22px",\
  "--text-component-4--fontSize--tablet": "20px",\
  "--text-component-4--fontSize--mobile": "20px",\
  "--text-component-4--fontFamily": "var(--font1)",\
  "--text-component-4--fontWeight": "normal",\
  "--text-component-4--fontType": "regular",\
  "--text-component-4--fontStyle": "normal",\
  "--text-component-4--fontStretch": "normal",\
  "--text-component-4--lineHeight": "1.35",\
  "--text-component-4--marginLeft": "0px",\
  "--text-component-4--color": "var(--color6)",\
  "--text-component-4--borderBottomStyle": "none",\
  "--text-component-4--textDecoration": "none",\
  "--text-component-4--letterSpacing": "0.02",\
  "--text-component-4--textTransform": "none",\
  "--text-component-4--stroke": "var(--palette-color2)",\
  "--text-component-4--textAlign": "left",\
  "--text-component-4--justifyContent": "flex-start",\
  "--text-component-4--marginTop": "auto",\
  "--text-component-4--marginBottom": "0",\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-1--fontSize--desktop": "36px",\
  "--text-subheading-1--fontSize--tablet": "32px",\
  "--text-subheading-1--fontSize--mobile": "28px",\
  "--text-subheading-1--fontFamily": "var(--font2)",\
  "--text-subheading-1--fontWeight": "normal",\
  "--text-subheading-1--fontType": "regular",\
  "--text-subheading-1--fontStyle": "normal",\
  "--text-subheading-1--fontStretch": "normal",\
  "--text-subheading-1--lineHeight": "1.1",\
  "--text-subheading-1--marginLeft": "0px",\
  "--text-subheading-1--color": "var(--palette-color6)",\
  "--text-subheading-1--borderBottomStyle": "none",\
  "--text-subheading-1--textDecoration": "none",\
  "--text-subheading-1--letterSpacing": "0.05",\
  "--text-subheading-1--textTransform": "uppercase",\
  "--text-subheading-1--stroke": "var(--palette-color2)",\
  "--text-subheading-1--textAlign": "left",\
  "--text-subheading-1--justifyContent": "flex-start",\
  "--text-subheading-1--marginTop": "auto",\
  "--text-subheading-1--marginBottom": "0",\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-2--fontSize--desktop": "28px",\
  "--text-subheading-2--fontSize--tablet": "24px",\
  "--text-subheading-2--fontSize--mobile": "20px",\
  "--text-subheading-2--fontFamily": "var(--font2)",\
  "--text-subheading-2--fontWeight": "normal",\
  "--text-subheading-2--fontType": "bold",\
  "--text-subheading-2--fontStyle": "normal",\
  "--text-subheading-2--fontStretch": "normal",\
  "--text-subheading-2--lineHeight": "1.15",\
  "--text-subheading-2--marginLeft": "0px",\
  "--text-subheading-2--color": "var(--palette-color6)",\
  "--text-subheading-2--borderBottomStyle": "none",\
  "--text-subheading-2--textDecoration": "none",\
  "--text-subheading-2--letterSpacing": "0.05",\
  "--text-subheading-2--textTransform": "none",\
  "--text-subheading-2--stroke": "var(--palette-color2)",\
  "--text-subheading-2--textAlign": "left",\
  "--text-subheading-2--justifyContent": "flex-start",\
  "--text-subheading-2--marginTop": "auto",\
  "--text-subheading-2--marginBottom": "0",\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-3--fontSize--desktop": "26px",\
  "--text-subheading-3--fontSize--tablet": "22px",\
  "--text-subheading-3--fontSize--mobile": "18px",\
  "--text-subheading-3--fontFamily": "var(--font2)",\
  "--text-subheading-3--fontWeight": "normal",\
  "--text-subheading-3--fontType": "regular",\
  "--text-subheading-3--fontStyle": "normal",\
  "--text-subheading-3--fontStretch": "normal",\
  "--text-subheading-3--lineHeight": "1.15",\
  "--text-subheading-3--marginLeft": "0px",\
  "--text-subheading-3--color": "var(--palette-color6)",\
  "--text-subheading-3--borderBottomStyle": "none",\
  "--text-subheading-3--textDecoration": "none",\
  "--text-subheading-3--letterSpacing": "0",\
  "--text-subheading-3--textTransform": "none",\
  "--text-subheading-3--stroke": "var(--palette-color2)",\
  "--text-subheading-3--textAlign": "center",\
  "--text-subheading-3--justifyContent": "flex-start",\
  "--text-subheading-3--marginTop": "auto",\
  "--text-subheading-3--marginBottom": "0",\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-4--fontSize--desktop": "24px",\
  "--text-subheading-4--fontSize--tablet": "20px",\
  "--text-subheading-4--fontSize--mobile": "16px",\
  "--text-subheading-4--fontFamily": "var(--font2)",\
  "--text-subheading-4--fontWeight": "normal",\
  "--text-subheading-4--fontType": "bold",\
  "--text-subheading-4--fontStyle": "normal",\
  "--text-subheading-4--fontStretch": "normal",\
  "--text-subheading-4--lineHeight": "1.15",\
  "--text-subheading-4--marginLeft": "0px",\
  "--text-subheading-4--color": "var(--palette-color0)",\
  "--text-subheading-4--borderBottomStyle": "none",\
  "--text-subheading-4--textDecoration": "none",\
  "--text-subheading-4--letterSpacing": "0.05",\
  "--text-subheading-4--textTransform": "none",\
  "--text-subheading-4--stroke": "var(--palette-color2)",\
  "--text-subheading-4--textAlign": "left",\
  "--text-subheading-4--justifyContent": "flex-start",\
  "--text-subheading-4--marginTop": "auto",\
  "--text-subheading-4--marginBottom": "0",\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-5--fontSize--desktop": "24px",\
  "--text-subheading-5--fontSize--tablet": "20px",\
  "--text-subheading-5--fontSize--mobile": "16px",\
  "--text-subheading-5--fontFamily": "var(--font1)",\
  "--text-subheading-5--fontWeight": "normal",\
  "--text-subheading-5--fontType": "bold",\
  "--text-subheading-5--fontStyle": "normal",\
  "--text-subheading-5--fontStretch": "normal",\
  "--text-subheading-5--lineHeight": "1.15",\
  "--text-subheading-5--marginLeft": "0px",\
  "--text-subheading-5--color": "var(--palette-color5)",\
  "--text-subheading-5--borderBottomStyle": "none",\
  "--text-subheading-5--textDecoration": "none",\
  "--text-subheading-5--letterSpacing": "-0.05",\
  "--text-subheading-5--textTransform": "none",\
  "--text-subheading-5--stroke": "var(--palette-color2)",\
  "--text-subheading-5--textAlign": "left",\
  "--text-subheading-5--justifyContent": "flex-start",\
  "--text-subheading-5--marginTop": "auto",\
  "--text-subheading-5--marginBottom": "0",\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-6--fontSize--desktop": "18px",\
  "--text-subheading-6--fontSize--tablet": "16px",\
  "--text-subheading-6--fontSize--mobile": "14px",\
  "--text-subheading-6--fontFamily": "var(--font2)",\
  "--text-subheading-6--fontWeight": "normal",\
  "--text-subheading-6--fontType": "bold",\
  "--text-subheading-6--fontStyle": "normal",\
  "--text-subheading-6--fontStretch": "normal",\
  "--text-subheading-6--lineHeight": "1.25",\
  "--text-subheading-6--marginLeft": "0px",\
  "--text-subheading-6--color": "var(--palette-color5)",\
  "--text-subheading-6--borderBottomStyle": "none",\
  "--text-subheading-6--textDecoration": "none",\
  "--text-subheading-6--letterSpacing": "0",\
  "--text-subheading-6--textTransform": "none",\
  "--text-subheading-6--stroke": "var(--palette-color2)",\
  "--text-subheading-6--textAlign": "left",\
  "--text-subheading-6--justifyContent": "flex-start",\
  "--text-subheading-6--marginTop": "auto",\
  "--text-subheading-6--marginBottom": "0",\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-1--fontSize--desktop": "20px",\
  "--text-detail-1--fontSize--tablet": "18px",\
  "--text-detail-1--fontSize--mobile": "16px",\
  "--text-detail-1--fontFamily": "var(--font2)",\
  "--text-detail-1--fontWeight": "normal",\
  "--text-detail-1--fontType": "regular",\
  "--text-detail-1--fontStyle": "normal",\
  "--text-detail-1--fontStretch": "normal",\
  "--text-detail-1--lineHeight": "1.2",\
  "--text-detail-1--marginLeft": "0px",\
  "--text-detail-1--color": "var(--palette-color6)",\
  "--text-detail-1--borderBottomStyle": "none",\
  "--text-detail-1--textDecoration": "none",\
  "--text-detail-1--letterSpacing": "0",\
  "--text-detail-1--textTransform": "uppercase",\
  "--text-detail-1--stroke": "var(--palette-color5)",\
  "--text-detail-1--textAlign": "left",\
  "--text-detail-1--justifyContent": "flex-start",\
  "--text-detail-1--marginTop": "auto",\
  "--text-detail-1--marginBottom": "0",\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-2--fontSize--desktop": "16px",\
  "--text-detail-2--fontSize--tablet": "14px",\
  "--text-detail-2--fontSize--mobile": "12px",\
  "--text-detail-2--fontFamily": "var(--font2)",\
  "--text-detail-2--fontWeight": "normal",\
  "--text-detail-2--fontType": "bold",\
  "--text-detail-2--fontStyle": "normal",\
  "--text-detail-2--fontStretch": "normal",\
  "--text-detail-2--lineHeight": "1.3",\
  "--text-detail-2--marginLeft": "0px",\
  "--text-detail-2--color": "var(--palette-color6)",\
  "--text-detail-2--borderBottomStyle": "none",\
  "--text-detail-2--textDecoration": "none",\
  "--text-detail-2--letterSpacing": "0",\
  "--text-detail-2--textTransform": "uppercase",\
  "--text-detail-2--stroke": "var(--palette-color2)",\
  "--text-detail-2--textAlign": "left",\
  "--text-detail-2--justifyContent": "flex-start",\
  "--text-detail-2--marginTop": "auto",\
  "--text-detail-2--marginBottom": "0",\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-3--fontSize--desktop": "16px",\
  "--text-detail-3--fontSize--tablet": "14px",\
  "--text-detail-3--fontSize--mobile": "12px",\
  "--text-detail-3--fontFamily": "var(--font2)",\
  "--text-detail-3--fontWeight": "normal",\
  "--text-detail-3--fontType": "regular",\
  "--text-detail-3--fontStyle": "normal",\
  "--text-detail-3--fontStretch": "normal",\
  "--text-detail-3--lineHeight": "1.35",\
  "--text-detail-3--marginLeft": "0px",\
  "--text-detail-3--color": "var(--palette-color4)",\
  "--text-detail-3--borderBottomStyle": "none",\
  "--text-detail-3--textDecoration": "none",\
  "--text-detail-3--letterSpacing": "0.2",\
  "--text-detail-3--textTransform": "uppercase",\
  "--text-detail-3--stroke": "var(--palette-color2)",\
  "--text-detail-3--textAlign": "left",\
  "--text-detail-3--justifyContent": "flex-start",\
  "--text-detail-3--marginTop": "auto",\
  "--text-detail-3--marginBottom": "0",\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-4--fontSize--desktop": "22px",\
  "--text-detail-4--fontSize--tablet": "20px",\
  "--text-detail-4--fontSize--mobile": "20px",\
  "--text-detail-4--fontFamily": "var(--font1)",\
  "--text-detail-4--fontWeight": "normal",\
  "--text-detail-4--fontType": "regular",\
  "--text-detail-4--fontStyle": "normal",\
  "--text-detail-4--fontStretch": "normal",\
  "--text-detail-4--lineHeight": "1.35",\
  "--text-detail-4--marginLeft": "0px",\
  "--text-detail-4--color": "var(--palette-color5)",\
  "--text-detail-4--borderBottomStyle": "none",\
  "--text-detail-4--textDecoration": "none",\
  "--text-detail-4--letterSpacing": "0",\
  "--text-detail-4--textTransform": "none",\
  "--text-detail-4--stroke": "var(--palette-color2)",\
  "--text-detail-4--textAlign": "center",\
  "--text-detail-4--justifyContent": "flex-start",\
  "--text-detail-4--marginTop": "auto",\
  "--text-detail-4--marginBottom": "0",\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-1--fontSize--desktop": "36px",\
  "--text-variable-1--fontSize--tablet": "32px",\
  "--text-variable-1--fontSize--mobile": "30px",\
  "--text-variable-1--fontFamily": "var(--font2)",\
  "--text-variable-1--fontWeight": "normal",\
  "--text-variable-1--fontType": "bold",\
  "--text-variable-1--fontStyle": "normal",\
  "--text-variable-1--fontStretch": "normal",\
  "--text-variable-1--lineHeight": "1.2",\
  "--text-variable-1--marginLeft": "0px",\
  "--text-variable-1--color": "var(--palette-color7)",\
  "--text-variable-1--borderBottomStyle": "none",\
  "--text-variable-1--textDecoration": "none",\
  "--text-variable-1--letterSpacing": "0.02",\
  "--text-variable-1--textTransform": "none",\
  "--text-variable-1--stroke": "var(--palette-color2)",\
  "--text-variable-1--textAlign": "left",\
  "--text-variable-1--justifyContent": "flex-start",\
  "--text-variable-1--marginTop": "auto",\
  "--text-variable-1--marginBottom": "0",\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-2--fontSize--desktop": "24px",\
  "--text-variable-2--fontSize--tablet": "22px",\
  "--text-variable-2--fontSize--mobile": "20px",\
  "--text-variable-2--fontFamily": "var(--font2)",\
  "--text-variable-2--fontWeight": "normal",\
  "--text-variable-2--fontType": "bold",\
  "--text-variable-2--fontStyle": "normal",\
  "--text-variable-2--fontStretch": "normal",\
  "--text-variable-2--lineHeight": "1.15",\
  "--text-variable-2--marginLeft": "0px",\
  "--text-variable-2--color": "var(--palette-color6)",\
  "--text-variable-2--borderBottomStyle": "none",\
  "--text-variable-2--textDecoration": "none",\
  "--text-variable-2--letterSpacing": "0",\
  "--text-variable-2--textTransform": "none",\
  "--text-variable-2--stroke": "var(--palette-color2)",\
  "--text-variable-2--textAlign": "left",\
  "--text-variable-2--justifyContent": "flex-start",\
  "--text-variable-2--marginTop": "auto",\
  "--text-variable-2--marginBottom": "0",\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-3--fontSize--desktop": "20px",\
  "--text-variable-3--fontSize--tablet": "18px",\
  "--text-variable-3--fontSize--mobile": "16px",\
  "--text-variable-3--fontFamily": "var(--font1)",\
  "--text-variable-3--fontWeight": "normal",\
  "--text-variable-3--fontType": "bold",\
  "--text-variable-3--fontStyle": "normal",\
  "--text-variable-3--fontStretch": "normal",\
  "--text-variable-3--lineHeight": "1.2",\
  "--text-variable-3--marginLeft": "0px",\
  "--text-variable-3--color": "var(--palette-color6)",\
  "--text-variable-3--borderBottomStyle": "none",\
  "--text-variable-3--textDecoration": "none",\
  "--text-variable-3--letterSpacing": "0",\
  "--text-variable-3--textTransform": "none",\
  "--text-variable-3--stroke": "var(--palette-color2)",\
  "--text-variable-3--textAlign": "left",\
  "--text-variable-3--justifyContent": "flex-start",\
  "--text-variable-3--marginTop": "auto",\
  "--text-variable-3--marginBottom": "0",\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-4--fontSize--desktop": "16px",\
  "--text-variable-4--fontSize--tablet": "14px",\
  "--text-variable-4--fontSize--mobile": "12px",\
  "--text-variable-4--fontFamily": "var(--font2)",\
  "--text-variable-4--fontWeight": "normal",\
  "--text-variable-4--fontType": "bold",\
  "--text-variable-4--fontStyle": "normal",\
  "--text-variable-4--fontStretch": "normal",\
  "--text-variable-4--lineHeight": "1.3",\
  "--text-variable-4--marginLeft": "0px",\
  "--text-variable-4--color": "var(--palette-color6)",\
  "--text-variable-4--borderBottomStyle": "none",\
  "--text-variable-4--textDecoration": "none",\
  "--text-variable-4--letterSpacing": "0.02",\
  "--text-variable-4--textTransform": "none",\
  "--text-variable-4--stroke": "var(--palette-color2)",\
  "--text-variable-4--textAlign": "left",\
  "--text-variable-4--justifyContent": "flex-start",\
  "--text-variable-4--marginTop": "auto",\
  "--text-variable-4--marginBottom": "0",\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\
\
  "--text-question-1--fontSize--desktop": "48px",\
  "--text-question-1--fontSize--tablet": "20px",\
  "--text-question-1--fontSize--mobile": "20px",\
  "--text-question-1--fontFamily": "var(--font1)",\
  "--text-question-1--fontWeight": "normal",\
  "--text-question-1--fontType": "regular",\
  "--text-question-1--fontStyle": "normal",\
  "--text-question-1--fontStretch": "normal",\
  "--text-question-1--lineHeight": "1.35",\
  "--text-question-1--marginLeft": "0px",\
  "--text-question-1--color": "var(--palette-color5)",\
  "--text-question-1--borderBottomStyle": "none",\
  "--text-question-1--textDecoration": "none",\
  "--text-question-1--letterSpacing": "0",\
  "--text-question-1--textTransform": "none",\
  "--text-question-1--stroke": "var(--palette-color2)",\
  "--text-question-1--textAlign": "left",\
  "--text-question-1--justifyContent": "flex-start",\
  "--text-question-1--marginTop": "auto",\
  "--text-question-1--marginBottom": "0",\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-1--textShadow": "var(--text-style-unset)",\
\
  "--text-question-2--fontSize--desktop": "24px",\
  "--text-question-2--fontSize--tablet": "20px",\
  "--text-question-2--fontSize--mobile": "20px",\
  "--text-question-2--fontFamily": "var(--font1)",\
  "--text-question-2--fontWeight": "normal",\
  "--text-question-2--fontType": "bold",\
  "--text-question-2--fontStyle": "normal",\
  "--text-question-2--fontStretch": "normal",\
  "--text-question-2--lineHeight": "1.35",\
  "--text-question-2--marginLeft": "0px",\
  "--text-question-2--color": "var(--palette-color5)",\
  "--text-question-2--borderBottomStyle": "none",\
  "--text-question-2--textDecoration": "none",\
  "--text-question-2--letterSpacing": "0",\
  "--text-question-2--textTransform": "none",\
  "--text-question-2--stroke": "var(--palette-color2)",\
  "--text-question-2--textAlign": "left",\
  "--text-question-2--justifyContent": "flex-start",\
  "--text-question-2--marginTop": "auto",\
  "--text-question-2--marginBottom": "0",\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-1--fontSize--desktop": "16px",\
  "--text-button-1--fontSize--tablet": "16px",\
  "--text-button-1--fontSize--mobile": "16px",\
  "--text-button-1--fontFamily": "var(--font2)",\
  "--text-button-1--fontWeight": "normal",\
  "--text-button-1--fontType": "regular",\
  "--text-button-1--fontStyle": "normal",\
  "--text-button-1--fontStretch": "normal",\
  "--text-button-1--lineHeight": "1.25",\
  "--text-button-1--marginLeft": "0px",\
  "--text-button-1--color": "var(--palette-color7)",\
  "--text-button-1--borderBottomStyle": "none",\
  "--text-button-1--textDecoration": "none",\
  "--text-button-1--letterSpacing": "0.12",\
  "--text-button-1--textTransform": "uppercase",\
  "--text-button-1--stroke": "var(--palette-color2)",\
  "--text-button-1--textAlign": "center",\
  "--text-button-1--justifyContent": "flex-start",\
  "--text-button-1--marginTop": "auto",\
  "--text-button-1--marginBottom": "0",\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-1--textShadow": "var(--text-style-unset)",\
\
  "--text-button-2--fontSize--desktop": "16px",\
  "--text-button-2--fontSize--tablet": "16px",\
  "--text-button-2--fontSize--mobile": "16px",\
  "--text-button-2--fontFamily": "var(--font2)",\
  "--text-button-2--fontWeight": "normal",\
  "--text-button-2--fontType": "regular",\
  "--text-button-2--fontStyle": "normal",\
  "--text-button-2--fontStretch": "normal",\
  "--text-button-2--lineHeight": "1.25",\
  "--text-button-2--marginLeft": "0px",\
  "--text-button-2--color": "var(--palette-color0)",\
  "--text-button-2--borderBottomStyle": "none",\
  "--text-button-2--textDecoration": "none",\
  "--text-button-2--letterSpacing": "0.12",\
  "--text-button-2--textTransform": "uppercase",\
  "--text-button-2--stroke": "var(--palette-color2)",\
  "--text-button-2--textAlign": "center",\
  "--text-button-2--justifyContent": "flex-start",\
  "--text-button-2--marginTop": "auto",\
  "--text-button-2--marginBottom": "0",\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-3--fontSize--desktop": "16px",\
  "--text-button-3--fontSize--tablet": "16px",\
  "--text-button-3--fontSize--mobile": "16px",\
  "--text-button-3--fontFamily": "var(--font2)",\
  "--text-button-3--fontWeight": "normal",\
  "--text-button-3--fontType": "regular",\
  "--text-button-3--fontStyle": "normal",\
  "--text-button-3--fontStretch": "normal",\
  "--text-button-3--lineHeight": "1.25",\
  "--text-button-3--marginLeft": "0px",\
  "--text-button-3--color": "var(--palette-color5)",\
  "--text-button-3--borderBottomStyle": "none",\
  "--text-button-3--textDecoration": "none",\
  "--text-button-3--letterSpacing": "0.12",\
  "--text-button-3--textTransform": "uppercase",\
  "--text-button-3--stroke": "var(--palette-color2)",\
  "--text-button-3--textAlign": "center",\
  "--text-button-3--justifyContent": "flex-start",\
  "--text-button-3--marginTop": "auto",\
  "--text-button-3--marginBottom": "0",\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-3--textShadow": "var(--text-style-unset)",\
\
  "--text-button-4--fontSize--desktop": "16px",\
  "--text-button-4--fontSize--tablet": "16px",\
  "--text-button-4--fontSize--mobile": "16px",\
  "--text-button-4--fontFamily": "var(--font2)",\
  "--text-button-4--fontWeight": "normal",\
  "--text-button-4--fontType": "regular",\
  "--text-button-4--fontStyle": "normal",\
  "--text-button-4--fontStretch": "normal",\
  "--text-button-4--lineHeight": "1.25",\
  "--text-button-4--marginLeft": "0px",\
  "--text-button-4--color": "var(--palette-color4)",\
  "--text-button-4--borderBottomStyle": "none",\
  "--text-button-4--textDecoration": "none",\
  "--text-button-4--letterSpacing": "0.12",\
  "--text-button-4--textTransform": "uppercase",\
  "--text-button-4--stroke": "var(--palette-color2)",\
  "--text-button-4--textAlign": "center",\
  "--text-button-4--justifyContent": "flex-start",\
  "--text-button-4--marginTop": "auto",\
  "--text-button-4--marginBottom": "0",\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-1--fontSize--desktop": "18px",\
  "--text-uic-1--fontSize--tablet": "18px",\
  "--text-uic-1--fontSize--mobile": "18px",\
  "--text-uic-1--fontFamily": "var(--font1)",\
  "--text-uic-1--fontWeight": "normal",\
  "--text-uic-1--fontType": "italic",\
  "--text-uic-1--fontStyle": "normal",\
  "--text-uic-1--fontStretch": "normal",\
  "--text-uic-1--lineHeight": "1.35",\
  "--text-uic-1--marginLeft": "0px",\
  "--text-uic-1--color": "var(--palette-color4)",\
  "--text-uic-1--borderBottomStyle": "none",\
  "--text-uic-1--textDecoration": "none",\
  "--text-uic-1--letterSpacing": "0",\
  "--text-uic-1--textTransform": "none",\
  "--text-uic-1--stroke": "var(--palette-color2)",\
  "--text-uic-1--textAlign": "left",\
  "--text-uic-1--justifyContent": "flex-start",\
  "--text-uic-1--marginTop": "auto",\
  "--text-uic-1--marginBottom": "0",\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-2--fontSize--desktop": "18px",\
  "--text-uic-2--fontSize--tablet": "18px",\
  "--text-uic-2--fontSize--mobile": "18px",\
  "--text-uic-2--fontFamily": "var(--font1)",\
  "--text-uic-2--fontWeight": "normal",\
  "--text-uic-2--fontType": "italic",\
  "--text-uic-2--fontStyle": "normal",\
  "--text-uic-2--fontStretch": "normal",\
  "--text-uic-2--lineHeight": "1.35",\
  "--text-uic-2--marginLeft": "0px",\
  "--text-uic-2--color": "var(--palette-color1)",\
  "--text-uic-2--borderBottomStyle": "none",\
  "--text-uic-2--textDecoration": "none",\
  "--text-uic-2--letterSpacing": "0",\
  "--text-uic-2--textTransform": "none",\
  "--text-uic-2--stroke": "var(--palette-color2)",\
  "--text-uic-2--textAlign": "left",\
  "--text-uic-2--justifyContent": "flex-start",\
  "--text-uic-2--marginTop": "auto",\
  "--text-uic-2--marginBottom": "0",\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-3--fontSize--desktop": "22px",\
  "--text-uic-3--fontSize--tablet": "22px",\
  "--text-uic-3--fontSize--mobile": "22px",\
  "--text-uic-3--fontFamily": "var(--font1)",\
  "--text-uic-3--fontWeight": "normal",\
  "--text-uic-3--fontType": "regular",\
  "--text-uic-3--fontStyle": "normal",\
  "--text-uic-3--fontStretch": "normal",\
  "--text-uic-3--lineHeight": "1.25",\
  "--text-uic-3--marginLeft": "0px",\
  "--text-uic-3--color": "var(--palette-color5)",\
  "--text-uic-3--borderBottomStyle": "none",\
  "--text-uic-3--textDecoration": "none",\
  "--text-uic-3--letterSpacing": "0",\
  "--text-uic-3--textTransform": "none",\
  "--text-uic-3--stroke": "var(--palette-color2)",\
  "--text-uic-3--textAlign": "left",\
  "--text-uic-3--justifyContent": "flex-start",\
  "--text-uic-3--marginTop": "auto",\
  "--text-uic-3--marginBottom": "0",\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-4--fontSize--desktop": "22px",\
  "--text-uic-4--fontSize--tablet": "22px",\
  "--text-uic-4--fontSize--mobile": "22px",\
  "--text-uic-4--fontFamily": "var(--font1)",\
  "--text-uic-4--fontWeight": "normal",\
  "--text-uic-4--fontType": "regular",\
  "--text-uic-4--fontStyle": "normal",\
  "--text-uic-4--fontStretch": "normal",\
  "--text-uic-4--lineHeight": "1.25",\
  "--text-uic-4--marginLeft": "0px",\
  "--text-uic-4--color": "var(--palette-color4)",\
  "--text-uic-4--borderBottomStyle": "none",\
  "--text-uic-4--textDecoration": "none",\
  "--text-uic-4--letterSpacing": "0",\
  "--text-uic-4--textTransform": "none",\
  "--text-uic-4--stroke": "var(--palette-color2)",\
  "--text-uic-4--textAlign": "left",\
  "--text-uic-4--justifyContent": "flex-start",\
  "--text-uic-4--marginTop": "auto",\
  "--text-uic-4--marginBottom": "0",\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-5--fontSize--desktop": "22px",\
  "--text-uic-5--fontSize--tablet": "22px",\
  "--text-uic-5--fontSize--mobile": "22px",\
  "--text-uic-5--fontFamily": "var(--font1)",\
  "--text-uic-5--fontWeight": "normal",\
  "--text-uic-5--fontType": "regular",\
  "--text-uic-5--fontStyle": "normal",\
  "--text-uic-5--fontStretch": "normal",\
  "--text-uic-5--lineHeight": "1.25",\
  "--text-uic-5--marginLeft": "0px",\
  "--text-uic-5--color": "var(--palette-color3)",\
  "--text-uic-5--borderBottomStyle": "none",\
  "--text-uic-5--textDecoration": "none",\
  "--text-uic-5--letterSpacing": "0",\
  "--text-uic-5--textTransform": "none",\
  "--text-uic-5--stroke": "var(--palette-color2)",\
  "--text-uic-5--textAlign": "left",\
  "--text-uic-5--justifyContent": "flex-start",\
  "--text-uic-5--marginTop": "auto",\
  "--text-uic-5--marginBottom": "0",\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-6--fontSize--desktop": "16px",\
  "--text-uic-6--fontSize--tablet": "16px",\
  "--text-uic-6--fontSize--mobile": "16px",\
  "--text-uic-6--fontFamily": "var(--font2)",\
  "--text-uic-6--fontWeight": "normal",\
  "--text-uic-6--fontType": "bold",\
  "--text-uic-6--fontStyle": "normal",\
  "--text-uic-6--fontStretch": "normal",\
  "--text-uic-6--lineHeight": "1.5",\
  "--text-uic-6--marginLeft": "0px",\
  "--text-uic-6--color": "var(--palette-color7)",\
  "--text-uic-6--borderBottomStyle": "none",\
  "--text-uic-6--textDecoration": "none",\
  "--text-uic-6--letterSpacing": "0.12",\
  "--text-uic-6--textTransform": "none",\
  "--text-uic-6--stroke": "var(--palette-color2)",\
  "--text-uic-6--textAlign": "left",\
  "--text-uic-6--justifyContent": "flex-start",\
  "--text-uic-6--marginTop": "auto",\
  "--text-uic-6--marginBottom": "0",\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\
\
  "--text-closedcaptions--fontSize--desktop": "24px",\
  "--text-closedcaptions--fontSize--tablet": "24px",\
  "--text-closedcaptions--fontSize--mobile": "24px",\
  "--text-closedcaptions--fontFamily": "var(--font1)",\
  "--text-closedcaptions--fontWeight": "normal",\
  "--text-closedcaptions--fontType": "regular",\
  "--text-closedcaptions--fontStyle": "normal",\
  "--text-closedcaptions--fontStretch": "normal",\
  "--text-closedcaptions--lineHeight": "1.35",\
  "--text-closedcaptions--marginLeft": "0px",\
  "--text-closedcaptions--color": "var(--white)",\
  "--text-closedcaptions--borderBottomStyle": "none",\
  "--text-closedcaptions--textDecoration": "none",\
  "--text-closedcaptions--letterSpacing": "0",\
  "--text-closedcaptions--textTransform": "none",\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\
  "--text-closedcaptions--textAlign": "center",\
  "--text-closedcaptions--justifyContent": "flex-start",\
  "--text-closedcaptions--marginTop": "auto",\
  "--text-closedcaptions--marginBottom": "0",\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\
\
  "--text-caption--fontSize--desktop": "24px",\
  "--text-caption--fontSize--tablet": "24px",\
  "--text-caption--fontSize--mobile": "24px",\
  "--text-caption--fontFamily": "var(--font1)",\
  "--text-caption--fontWeight": "normal",\
  "--text-caption--fontType": "regular",\
  "--text-caption--fontStyle": "normal",\
  "--text-caption--fontStretch": "normal",\
  "--text-caption--lineHeight": "1.35",\
  "--text-caption--marginLeft": "0px",\
  "--text-caption--color": "var(--palette-color6)",\
  "--text-caption--borderBottomStyle": "none",\
  "--text-caption--textDecoration": "none",\
  "--text-caption--letterSpacing": "0",\
  "--text-caption--textTransform": "none",\
  "--text-caption--stroke": "var(--palette-color2)",\
  "--text-caption--textAlign": "center",\
  "--text-caption--justifyContent": "flex-start",\
  "--text-caption--marginTop": "auto",\
  "--text-caption--marginBottom": "0",\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_correct--fontSize--desktop": "24px",\
  "--text-caption_correct--fontSize--tablet": "24px",\
  "--text-caption_correct--fontSize--mobile": "24px",\
  "--text-caption_correct--fontFamily": "var(--font1)",\
  "--text-caption_correct--fontWeight": "normal",\
  "--text-caption_correct--fontType": "regular",\
  "--text-caption_correct--fontStyle": "normal",\
  "--text-caption_correct--fontStretch": "normal",\
  "--text-caption_correct--lineHeight": "1.35",\
  "--text-caption_correct--marginLeft": "0px",\
  "--text-caption_correct--color": "var(--palette-color6)",\
  "--text-caption_correct--borderBottomStyle": "none",\
  "--text-caption_correct--textDecoration": "none",\
  "--text-caption_correct--letterSpacing": "0",\
  "--text-caption_correct--textTransform": "none",\
  "--text-caption_correct--stroke": "var(--palette-color2)",\
  "--text-caption_correct--textAlign": "center",\
  "--text-caption_correct--justifyContent": "flex-start",\
  "--text-caption_correct--marginTop": "auto",\
  "--text-caption_correct--marginBottom": "0",\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incorrect--fontSize--desktop": "24px",\
  "--text-caption_incorrect--fontSize--tablet": "24px",\
  "--text-caption_incorrect--fontSize--mobile": "24px",\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\
  "--text-caption_incorrect--fontWeight": "normal",\
  "--text-caption_incorrect--fontType": "regular",\
  "--text-caption_incorrect--fontStyle": "normal",\
  "--text-caption_incorrect--fontStretch": "normal",\
  "--text-caption_incorrect--lineHeight": "1.35",\
  "--text-caption_incorrect--marginLeft": "0px",\
  "--text-caption_incorrect--color": "var(--palette-color6)",\
  "--text-caption_incorrect--borderBottomStyle": "none",\
  "--text-caption_incorrect--textDecoration": "none",\
  "--text-caption_incorrect--letterSpacing": "0",\
  "--text-caption_incorrect--textTransform": "none",\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\
  "--text-caption_incorrect--textAlign": "center",\
  "--text-caption_incorrect--justifyContent": "flex-start",\
  "--text-caption_incorrect--marginTop": "auto",\
  "--text-caption_incorrect--marginBottom": "0",\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incomplete--fontSize--desktop": "24px",\
  "--text-caption_incomplete--fontSize--tablet": "24px",\
  "--text-caption_incomplete--fontSize--mobile": "24px",\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\
  "--text-caption_incomplete--fontWeight": "normal",\
  "--text-caption_incomplete--fontType": "regular",\
  "--text-caption_incomplete--fontStyle": "normal",\
  "--text-caption_incomplete--fontStretch": "normal",\
  "--text-caption_incomplete--lineHeight": "1.35",\
  "--text-caption_incomplete--marginLeft": "0px",\
  "--text-caption_incomplete--color": "var(--palette-color6)",\
  "--text-caption_incomplete--borderBottomStyle": "none",\
  "--text-caption_incomplete--textDecoration": "none",\
  "--text-caption_incomplete--letterSpacing": "0",\
  "--text-caption_incomplete--textTransform": "none",\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\
  "--text-caption_incomplete--textAlign": "center",\
  "--text-caption_incomplete--justifyContent": "flex-start",\
  "--text-caption_incomplete--marginTop": "auto",\
  "--text-caption_incomplete--marginBottom": "0",\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_hint--fontSize--desktop": "24px",\
  "--text-caption_hint--fontSize--tablet": "24px",\
  "--text-caption_hint--fontSize--mobile": "24px",\
  "--text-caption_hint--fontFamily": "var(--font1)",\
  "--text-caption_hint--fontWeight": "normal",\
  "--text-caption_hint--fontType": "regular",\
  "--text-caption_hint--fontStyle": "normal",\
  "--text-caption_hint--fontStretch": "normal",\
  "--text-caption_hint--lineHeight": "1.35",\
  "--text-caption_hint--marginLeft": "0px",\
  "--text-caption_hint--color": "var(--palette-color6)",\
  "--text-caption_hint--borderBottomStyle": "none",\
  "--text-caption_hint--textDecoration": "none",\
  "--text-caption_hint--letterSpacing": "0",\
  "--text-caption_hint--textTransform": "none",\
  "--text-caption_hint--stroke": "var(--palette-color2)",\
  "--text-caption_hint--textAlign": "center",\
  "--text-caption_hint--justifyContent": "flex-start",\
  "--text-caption_hint--marginTop": "auto",\
  "--text-caption_hint--marginBottom": "0",\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_retry--fontSize--desktop": "24px",\
  "--text-caption_retry--fontSize--tablet": "24px",\
  "--text-caption_retry--fontSize--mobile": "24px",\
  "--text-caption_retry--fontFamily": "var(--font1)",\
  "--text-caption_retry--fontWeight": "normal",\
  "--text-caption_retry--fontType": "regular",\
  "--text-caption_retry--fontStyle": "normal",\
  "--text-caption_retry--fontStretch": "normal",\
  "--text-caption_retry--lineHeight": "1.35",\
  "--text-caption_retry--marginLeft": "0px",\
  "--text-caption_retry--color": "var(--palette-color6)",\
  "--text-caption_retry--borderBottomStyle": "none",\
  "--text-caption_retry--textDecoration": "none",\
  "--text-caption_retry--letterSpacing": "0",\
  "--text-caption_retry--textTransform": "none",\
  "--text-caption_retry--stroke": "var(--palette-color2)",\
  "--text-caption_retry--textAlign": "center",\
  "--text-caption_retry--justifyContent": "flex-start",\
  "--text-caption_retry--marginTop": "auto",\
  "--text-caption_retry--marginBottom": "0",\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_timeout--fontSize--desktop": "24px",\
  "--text-caption_timeout--fontSize--tablet": "24px",\
  "--text-caption_timeout--fontSize--mobile": "24px",\
  "--text-caption_timeout--fontFamily": "var(--font1)",\
  "--text-caption_timeout--fontWeight": "normal",\
  "--text-caption_timeout--fontType": "regular",\
  "--text-caption_timeout--fontStyle": "normal",\
  "--text-caption_timeout--fontStretch": "normal",\
  "--text-caption_timeout--lineHeight": "1.35",\
  "--text-caption_timeout--marginLeft": "0px",\
  "--text-caption_timeout--color": "var(--palette-color6)",\
  "--text-caption_timeout--borderBottomStyle": "none",\
  "--text-caption_timeout--textDecoration": "none",\
  "--text-caption_timeout--letterSpacing": "0",\
  "--text-caption_timeout--textTransform": "none",\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\
  "--text-caption_timeout--textAlign": "center",\
  "--text-caption_timeout--justifyContent": "flex-start",\
  "--text-caption_timeout--marginTop": "auto",\
  "--text-caption_timeout--marginBottom": "0",\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_1--fontSize--desktop": "18px",\
  "--text-caption_1--fontSize--tablet": "18px",\
  "--text-caption_1--fontSize--mobile": "16px",\
  "--text-caption_1--fontFamily": "var(--font2)",\
  "--text-caption_1--fontWeight": "normal",\
  "--text-caption_1--fontType": "regular",\
  "--text-caption_1--fontStyle": "normal",\
  "--text-caption_1--fontStretch": "normal",\
  "--text-caption_1--lineHeight": "1.2",\
  "--text-caption_1--marginLeft": "0px",\
  "--text-caption_1--color": "#FFFFFF",\
  "--text-caption_1--borderBottomStyle": "none",\
  "--text-caption_1--textDecoration": "none",\
  "--text-caption_1--letterSpacing": "0",\
  "--text-caption_1--textTransform": "none",\
  "--text-caption_1--stroke": "#00000000",\
  "--text-caption_1--textAlign": "left",\
  "--text-caption_1--justifyContent": "flex-start",\
  "--text-caption_1--marginTop": "auto",\
  "--text-caption_1--marginBottom": "0",\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_2--fontSize--desktop": "20px",\
  "--text-caption_2--fontSize--tablet": "20px",\
  "--text-caption_2--fontSize--mobile": "18px",\
  "--text-caption_2--fontFamily": "var(--font2)",\
  "--text-caption_2--fontWeight": "normal",\
  "--text-caption_2--fontType": "bold",\
  "--text-caption_2--fontStyle": "normal",\
  "--text-caption_2--fontStretch": "normal",\
  "--text-caption_2--lineHeight": "1.2",\
  "--text-caption_2--marginLeft": "0px",\
  "--text-caption_2--color": "#FFFFFF",\
  "--text-caption_2--borderBottomStyle": "none",\
  "--text-caption_2--textDecoration": "none",\
  "--text-caption_2--letterSpacing": "0",\
  "--text-caption_2--textTransform": "none",\
  "--text-caption_2--stroke": "#00000000",\
  "--text-caption_2--textAlign": "left",\
  "--text-caption_2--justifyContent": "flex-start",\
  "--text-caption_2--marginTop": "auto",\
  "--text-caption_2--marginBottom": "0",\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_3--fontSize--desktop": "24px",\
  "--text-caption_3--fontSize--tablet": "24px",\
  "--text-caption_3--fontSize--mobile": "22px",\
  "--text-caption_3--fontFamily": "var(--font1)",\
  "--text-caption_3--fontWeight": "normal",\
  "--text-caption_3--fontType": "italic",\
  "--text-caption_3--fontStyle": "normal",\
  "--text-caption_3--fontStretch": "normal",\
  "--text-caption_3--lineHeight": "1.2",\
  "--text-caption_3--marginLeft": "0px",\
  "--text-caption_3--color": "#FFFFFF",\
  "--text-caption_3--borderBottomStyle": "none",\
  "--text-caption_3--textDecoration": "none",\
  "--text-caption_3--letterSpacing": "0",\
  "--text-caption_3--textTransform": "none",\
  "--text-caption_3--stroke": "#00000000",\
  "--text-caption_3--textAlign": "left",\
  "--text-caption_3--justifyContent": "flex-start",\
  "--text-caption_3--marginTop": "auto",\
  "--text-caption_3--marginBottom": "0",\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_4--fontSize--desktop": "22px",\
  "--text-caption_4--fontSize--tablet": "22px",\
  "--text-caption_4--fontSize--mobile": "20px",\
  "--text-caption_4--fontFamily": "var(--font2)",\
  "--text-caption_4--fontWeight": "normal",\
  "--text-caption_4--fontType": "italic",\
  "--text-caption_4--fontStyle": "normal",\
  "--text-caption_4--fontStretch": "normal",\
  "--text-caption_4--lineHeight": "1.3",\
  "--text-caption_4--marginLeft": "0px",\
  "--text-caption_4--color": "#666666",\
  "--text-caption_4--borderBottomStyle": "none",\
  "--text-caption_4--textDecoration": "none",\
  "--text-caption_4--letterSpacing": "0",\
  "--text-caption_4--textTransform": "none",\
  "--text-caption_4--stroke": "#00000000",\
  "--text-caption_4--textAlign": "left",\
  "--text-caption_4--justifyContent": "flex-start",\
  "--text-caption_4--marginTop": "auto",\
  "--text-caption_4--marginBottom": "0",\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\
\
  "--text-comment-box--fontSize--desktop": "20px",\
  "--text-comment-box--fontSize--tablet": "20px",\
  "--text-comment-box--fontSize--mobile": "20px",\
  "--text-comment-box--fontFamily": "var(--font1)",\
  "--text-comment-box--fontWeight": "normal",\
  "--text-comment-box--fontType": "regular",\
  "--text-comment-box--fontStyle": "normal",\
  "--text-comment-box--fontStretch": "normal",\
  "--text-comment-box--lineHeight": "1.35",\
  "--text-comment-box--marginLeft": "0px",\
  "--text-comment-box--color": "var(--palette-color6)",\
  "--text-comment-box--borderBottomStyle": "none",\
  "--text-comment-box--textDecoration": "none",\
  "--text-comment-box--letterSpacing": "0",\
  "--text-comment-box--textTransform": "none",\
  "--text-comment-box--stroke": "var(--palette-color2)",\
  "--text-comment-box--textAlign": "center",\
  "--text-comment-box--justifyContent": "flex-start",\
  "--text-comment-box--marginTop": "auto",\
  "--text-comment-box--marginBottom": "0",\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\
\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\
\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_greyscale--intensity": 100,\
\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_lighten--intensity": 80,\
\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_darken--intensity": 80,\
\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_overlay--intensity": 80,\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\
\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_colorize--intensity": 80,\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\
\
\
  "--button-normal--primaryColor": "var(--palette-color7)",\
  "--button-normal--borderColor": "var(--palette-color7)",\
  "--button-normal--shadowColor": "var(--greyscale3)",\
  "--text-button-normal--color": "var(--palette-color0)",\
  "--text-button-normal--fontFamily": "var(--font2)",\
  "--text-button-normal--fontType": "regular",\
  "--text-button-normal--fontSize--desktop": "16px",\
  "--text-button-normal--fontSize--tablet": "16px",\
  "--text-button-normal--fontSize--mobile": "16px",\
\
  "--button-selected--primaryColor": "var(--palette-color5)",\
  "--button-selected--borderColor": "var(--palette-color5)",\
  "--button-selected--shadowColor": "var(--greyscale3)",\
  "--text-button-selected--color": "var(--palette-color0)",\
  "--text-button-selected--fontFamily": "var(--font2)",\
  "--text-button-selected--fontType": "regular",\
  "--text-button-selected--fontSize--desktop": "16px",\
  "--text-button-selected--fontSize--tablet": "16px",\
  "--text-button-selected--fontSize--mobile": "16px",\
\
  "--button-disabled--primaryColor": "var(--palette-color3)",\
  "--button-disabled--borderColor": "var(--palette-color3)",\
  "--button-disabled--shadowColor": "var(--greyscale3)",\
  "--text-button-disabled--color": "var(--palette-color4)",\
  "--text-button-disabled--fontFamily": "var(--font2)",\
  "--text-button-disabled--fontType": "regular",\
  "--text-button-disabled--fontSize--desktop": "16px",\
  "--text-button-disabled--fontSize--tablet": "16px",\
  "--text-button-disabled--fontSize--mobile": "16px",\
\
  "--button-hover--primaryColor": "#112FA7",\
  "--button-hover--borderColor": "#112FA7",\
  "--button-hover--shadowColor": "var(--greyscale3)",\
  "--text-button-hover--color": "var(--palette-color0)",\
  "--text-button-hover--fontFamily": "var(--font2)",\
  "--text-button-hover--fontType": "regular",\
  "--text-button-hover--fontSize--desktop": "16px",\
  "--text-button-hover--fontSize--tablet": "16px",\
  "--text-button-hover--fontSize--mobile": "16px",\
\
  "--button-visited--primaryColor": "#112FA780",\
  "--button-visited--borderColor": "#112FA780",\
  "--button-visited--shadowColor": "var(--greyscale3)",\
  "--text-button-visited--color": "var(--palette-color0)",\
  "--text-button-visited--fontFamily": "var(--font2)",\
  "--text-button-visited--fontType": "regular",\
  "--text-button-visited--fontSize--desktop": "16px",\
  "--text-button-visited--fontSize--tablet": "16px",\
  "--text-button-visited--fontSize--mobile": "16px",\
\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-normal--color": "var(--palette-color4)",\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\
  "--text-checkbox-normal--fontType": "regular",\
  "--text-checkbox-normal--fontSize--desktop": "22px",\
  "--text-checkbox-normal--fontSize--tablet": "20px",\
  "--text-checkbox-normal--fontSize--mobile": "20px",\
\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-selected--color": "var(--palette-color4)",\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\
  "--text-checkbox-selected--fontType": "regular",\
  "--text-checkbox-selected--fontSize--desktop": "22px",\
  "--text-checkbox-selected--fontSize--tablet": "20px",\
  "--text-checkbox-selected--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-checked--fontType": "regular",\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\
\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-hover--color": "var(--palette-color5)",\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\
  "--text-checkbox-hover--fontType": "regular",\
  "--text-checkbox-hover--fontSize--desktop": "22px",\
  "--text-checkbox-hover--fontSize--tablet": "20px",\
  "--text-checkbox-hover--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \
  "--inputfield-normal--borderColor": "var(--palette-color3)",\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-normal--color": "var(--palette-color4)",\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\
  "--text-inputfield-normal--fontType": "regular",\
  "--text-inputfield-normal--fontSize--desktop": "18px",\
  "--text-inputfield-normal--fontSize--tablet": "20px",\
  "--text-inputfield-normal--fontSize--mobile": "20px",\
\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\
  "--inputfield-active--borderColor": "var(--palette-color7)",\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\
  "--text-inputfield-active--color": "var(--palette-color4)",\
  "--text-inputfield-active--fontFamily": "var(--font1)",\
  "--text-inputfield-active--fontType": "regular",\
  "--text-inputfield-active--fontSize--desktop": "18px",\
  "--text-inputfield-active--fontSize--tablet": "20px",\
  "--text-inputfield-active--fontSize--mobile": "20px",\
\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\
  "--text-inputfield-disabled--fontType": "regular",\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\
\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\
  "--text-inputfield-focusLost--fontType": "regular",\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\
\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\
  "--inputfield-error--borderColor": "var(--error)",\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-error--color": "var(--palette-color4)",\
  "--text-inputfield-error--fontFamily": "var(--font1)",\
  "--text-inputfield-error--fontType": "regular",\
  "--text-inputfield-error--fontSize--desktop": "18px",\
  "--text-inputfield-error--fontSize--tablet": "20px",\
  "--text-inputfield-error--fontSize--mobile": "20px",\
\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-normal--color": "var(--palette-color4)",\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\
  "--text-dropdown-normal--fontType": "italic",\
  "--text-dropdown-normal--fontSize--desktop": "18px",\
  "--text-dropdown-normal--fontSize--tablet": "18px",\
  "--text-dropdown-normal--fontSize--mobile": "18px",\
\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-selected--color": "var(--palette-color4)",\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\
  "--text-dropdown-selected--fontType": "italic",\
  "--text-dropdown-selected--fontSize--desktop": "18px",\
  "--text-dropdown-selected--fontSize--tablet": "18px",\
  "--text-dropdown-selected--fontSize--mobile": "18px",\
\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\
  "--text-dropdown-disabled--fontType": "italic",\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\
\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-hover--color": "var(--palette-color4)",\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\
  "--text-dropdown-hover--fontType": "italic",\
  "--text-dropdown-hover--fontSize--desktop": "18px",\
  "--text-dropdown-hover--fontSize--tablet": "18px",\
  "--text-dropdown-hover--fontSize--mobile": "18px",\
\
  "--radio-normal--primaryColor": "var(--palette-color0)",\
  "--radio-normal--borderColor": "var(--palette-color3)",\
  "--radio-normal--shadowColor": "var(--greyscale3)",\
  "--text-radio-normal--color": "var(--palette-color4)",\
  "--text-radio-normal--fontFamily": "var(--font1)",\
  "--text-radio-normal--fontType": "regular",\
  "--text-radio-normal--fontSize--desktop": "22px",\
  "--text-radio-normal--fontSize--tablet": "20px",\
  "--text-radio-normal--fontSize--mobile": "20px",\
\
  "--radio-selected--primaryColor": "var(--palette-color0)",\
  "--radio-selected--borderColor": "var(--palette-color4)",\
  "--radio-selected--shadowColor": "var(--greyscale3)",\
  "--text-radio-selected--color": "var(--palette-color4)",\
  "--text-radio-selected--fontFamily": "var(--font1)",\
  "--text-radio-selected--fontType": "regular",\
  "--text-radio-selected--fontSize--desktop": "22px",\
  "--text-radio-selected--fontSize--tablet": "20px",\
  "--text-radio-selected--fontSize--mobile": "20px",\
\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-checked--fontType": "regular",\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\
\
  "--radio-hover--primaryColor": "var(--palette-color0)",\
  "--radio-hover--borderColor": "var(--palette-color3)",\
  "--radio-hover--shadowColor": "var(--greyscale3)",\
  "--text-radio-hover--color": "var(--palette-color5)",\
  "--text-radio-hover--fontFamily": "var(--font1)",\
  "--text-radio-hover--fontType": "regular",\
  "--text-radio-hover--fontSize--desktop": "22px",\
  "--text-radio-hover--fontSize--tablet": "20px",\
  "--text-radio-hover--fontSize--mobile": "20px",\
\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-unchecked--fontType": "regular",\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--video_preset-color": "#666666",\
  "--video_preset-borderColor": "#666666",\
  \
  "--clickbox-preset-fill-color": "#3F80E4",\
\
  "--drag-object-default-state-fill-color": "255, 255, 255",\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drag-object-default-state-border-color": "214, 213, 209",\
  "--drag-object-hover-state-border-color": "214, 213, 209",\
  "--drag-object-transition-state-border-color": "214, 213, 209",\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\
\
  "--drop-object-default-state-fill-color": "255, 255, 255",\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drop-object-default-state-border-color": "42, 49, 62",\
  "--drop-object-hover-state-border-color": "230, 132, 80",\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\
}',
uic_presets:'{\
  "cp_button_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 1,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "--button-selected--shadowColor",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-visited--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style": {\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "#707070",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_hover": {\
    "fill": "#9ec4f3",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--black)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_selected": {\
    "fill": "var(--palette-color5)",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_visited": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_disabled": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_active": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-active--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-active--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-active--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_focusLost": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-focusLost--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-focusLost--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-focusLost--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_error": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-error--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-error--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-error--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 14,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.78\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "video_preset_style": {\
    "fillEnable": 0,\
    "strokeEnable": 0,\
    "shadowEnable": 0,\
    "fill": "var(--video_preset-color)",\
    "fillOpacity": 1,\
    "stroke": "var(--video_preset-border)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_comment_box_shape_1_solid_style": {\
    "fill": "#F2B807",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clickbox_shape_solid_style": {\
    "fill": "var(--clickbox-preset-fill-color)",\
    "fillOpacity": 0.6,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "2, 3",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#333333",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#000000",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#D6D5D1",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clicktoreveal_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#ffffff",\
    "fillOpacity": 1,\
    "stroke": "#ffffff",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 3,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color7)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color8)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_blue": {\
    "fill": "#ADD8E6",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:0,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
vestr:1,
vim:0,
slides:'Slide388,Slide480,Slide1428,Slide2098,Slide3371,Slide2363,Slide2663,Slide1455,Slide2955,Slide1752,Slide3259',
questionSlides:'Slide2663,Slide1455,Slide2955',
slideVideos:['si3416'],
questions:'Slide1455q1,Slide2663q0,Slide2955q2',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Welcome Title","type":"slide","parentId":null,"id":"Slide388","isVisible":true,"slideVisited":false,"originalId":388,"labelShouldBeInSync":true},{"label":"Objectives","type":"slide","parentId":null,"id":"Slide480","isVisible":true,"slideVisited":false,"originalId":480,"labelShouldBeInSync":true},{"label":"The Basics","type":"slide","parentId":null,"id":"Slide1428","isVisible":true,"slideVisited":false,"originalId":1428,"labelShouldBeInSync":true},{"label":"Psychological Reasons","type":"slide","parentId":null,"id":"Slide2098","isVisible":true,"slideVisited":false,"originalId":2098,"labelShouldBeInSync":true},{"label":"Video","type":"slide","parentId":null,"id":"Slide3371","isVisible":true,"slideVisited":false,"originalId":3371,"labelShouldBeInSync":true},{"label":"Evidence","type":"slide","parentId":null,"id":"Slide2363","isVisible":true,"slideVisited":false,"originalId":2363,"labelShouldBeInSync":true},{"label":"Question _1","type":"slide","parentId":null,"id":"Slide2663","isVisible":true,"slideVisited":false,"originalId":2663,"labelShouldBeInSync":true},{"label":"Question _2","type":"slide","parentId":null,"id":"Slide1455","isVisible":true,"slideVisited":false,"originalId":1455,"labelShouldBeInSync":true},{"label":"Question _3","type":"slide","parentId":null,"id":"Slide2955","isVisible":true,"slideVisited":false,"originalId":2955,"labelShouldBeInSync":true},{"label":"Results","type":"slide","parentId":null,"id":"Slide1752","isVisible":true,"slideVisited":false,"originalId":1752,"labelShouldBeInSync":true},{"label":"Sources","type":"slide","parentId":null,"id":"Slide3259","isVisible":true,"slideVisited":false,"originalId":3259,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":true,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:388,
text:[]
}
,{
link:480,
text:[]
}
,{
link:1428,
text:[]
}
,{
link:2098,
text:[]
}
,{
link:3371,
text:[]
}
,{
link:2363,
text:[]
}
,{
link:2663,
text:[]
}
,{
link:1455,
text:[]
}
,{
link:2955,
text:[]
}
,{
link:3259,
text:[]
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/Answer_checkbox_correct.png',
'assets/htmlimages/Answer_checkbox_hover.png',
'assets/htmlimages/Answer_checkbox_incorrect.png',
'assets/htmlimages/Answer_checkbox_normal.png',
'assets/htmlimages/Answer_checkbox_select.png',
'assets/htmlimages/Answer_radio_correct.png',
'assets/htmlimages/Answer_radio_hover.png',
'assets/htmlimages/Answer_radio_incorrect.png',
'assets/htmlimages/Answer_radio_normal.png',
'assets/htmlimages/Answer_radio_select.png',
'assets/htmlimages/Graph.jpg',
'assets/htmlimages/HotspotDisplayImage.png',
'assets/htmlimages/HotspotDisplayText.png',
'assets/htmlimages/HotspotQuestionOverlays.png',
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/VR_move_left.png',
'assets/htmlimages/VR_move_right.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/checkboxchecked.png',
'assets/htmlimages/checkboxunchecked.png',
'assets/htmlimages/correct_answer_normal.png',
'assets/htmlimages/correct_answer_small.png',
'assets/htmlimages/correct_question_normal.png',
'assets/htmlimages/correct_question_small.png',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/incorrect_answer_normal.png',
'assets/htmlimages/incorrect_answer_small.png',
'assets/htmlimages/incorrect_question_normal.png',
'assets/htmlimages/incorrect_question_small.png',
'assets/htmlimages/partial_correct_question_normal.png',
'assets/htmlimages/partial_correct_question_small.png',
'assets/htmlimages/placeholder.png',
'assets/htmlimages/radioButton_disabled.png',
'assets/htmlimages/radioButton_normal.png',
'assets/htmlimages/radioButton_selected.png',
'assets/htmlimages/radioButton_selectedDisabled.png',
'assets/htmlimages/radiochecked.png',
'assets/htmlimages/radiounchecked.png',
'assets/htmlimages/skip_answer_normal.png',
'assets/htmlimages/skip_answer_small.png',
'assets/htmlimages/skip_question_normal.png',
'assets/htmlimages/skip_question_small.png'
];
cp.model.data.images=[{
ip:'dr/01411.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01417.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01453.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01534.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01575.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02095.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02232.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02634.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0478.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0498.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0546.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
'https://www.youtube.com/watch?v=DyH3FIBTdYg'
];
cp.model.tocVideos=[
];
cp.model.audios=[
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',3,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',3,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',3,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',3,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',11,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',3,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
