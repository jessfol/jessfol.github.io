if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
Slide1292:{
lb:'Blank 1',
id:1292,
from:1,
to:429,
iols:0,
i360qs:false,
sdu:14.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1292c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
imgf:{
ip:'dr/02082.png',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:2082,
w:2676,
h:1490,
tsp:50
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1292c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1292,
dn:'Slide1292',
visible:'1'
},
si486:{
name:'Simulation_1',
type:1268,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si486c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si478',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si486c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:486,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si486',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si478:{
name:'Simulation_non_responsive_1',
type:1268,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si478c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":2,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si486',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si497',
t:1269
}
,{
n:'si517',
t:612
}
,{
n:'si1266',
t:12
}
,{
n:'si1282',
t:612
}
,{
n:'si1540',
t:612
}
,{
n:'si1520',
t:1269
}
,{
n:'si1630',
t:612
}
,{
n:'si1600',
t:2433
}
,{
n:'si1785',
t:612
}
,{
n:'si1765',
t:1269
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":2,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si486',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si478c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:478,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si478',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:494,
tsp:50,
ip:'dr/0494.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si497:{
name:'Click_box_1',
type:1269,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si497c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":46,"left":1263,"width":34,"height":34},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(570);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:5.29,
lcapid:'si517',
si:[{
n:'si507',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[497]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si497c:{
b:[1263,46,1297,80],
fh:false,
fw:false,
uid:497,
iso:false,
css:{
360:{
l:'129.938%',
t:'7.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'129.938%',
lhID:-1,
lvEID:0,
lvV:'7.566%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'129.938%',
t:'7.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'129.938%',
lhID:-1,
lvEID:0,
lvV:'7.566%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'129.938%',
t:'7.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'129.938%',
lhID:-1,
lvEID:0,
lvV:'7.566%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si497',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1263,46,1297,80],
vb:[1263,46,1297,80]
},
si507:{
name:'Shape_1',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si507c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[507]
}
]
,
stis:0,
bstiid:497,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si497',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si507c:{
b:[0,0,34,34],
fh:false,
fw:false,
uid:507,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si507',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,36],
vb:[-2,-2,36,36]
},
si517:{
name:'Rectangle_1',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si517c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":106,"left":948,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:528,
stt:0,
dsr:'Default_State',
stsi:[517]
}
,{
stn:540,
stt:102,
dsr:'Failure',
stsi:[541]
}
,{
stn:551,
stt:103,
dsr:'Hint',
stsi:[552]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si517','si530','si541','si552'],
isDD:false
},
si517c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:517,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si517',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si530:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si530c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":106,"left":948,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si517',
stl:[{
stn:'Normal',
stt:0,
stsi:[530]
}
]
,
stis:0,
bstiid:517,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:517,
isDD:false
},
si530c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:530,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si530',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si541:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si541c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":106,"left":948,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si517',
stl:[{
stn:'Normal',
stt:0,
stsi:[541]
}
]
,
stis:0,
bstiid:517,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:517,
isDD:false
},
si541c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:541,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si541',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si552:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si552c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":106,"left":948,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si517',
stl:[{
stn:'Normal',
stt:0,
stsi:[552]
}
]
,
stis:0,
bstiid:517,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:517,
isDD:false
},
si552c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:552,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si552',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1266:{
name:'Mouse_1',
type:12,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1266c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":true,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":1},"mousePathPoints":{"mouseStartPointX":0,"mouseStartPointY":0,"mouseEndPointX":1287.337154522613,"mouseEndPointY":67.06260469011724}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1266Ad',
trin:0,
trout:0,
isDD:false
},
si1266c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1266,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1266',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si1266Ad:{
src:'ar/Mouse.mp3',
from:430,
to:435,
del:5.118,
msa:1,
du:0.182
},
si1282:{
name:'Instructions_1',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1282c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"fiv7","text":"Click on the profile icon","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":25,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":25,"style":"hlnkt:wp"},{"offset":0,"length":25,"style":"textOutlineEnable:false"},{"offset":0,"length":25,"style":"opacity:1"},{"offset":0,"length":25,"style":"textShadowColor:ffffff00"},{"offset":0,"length":25,"style":"hlnke:true"},{"offset":0,"length":25,"style":"backgroundColor:unset"},{"offset":0,"length":25,"style":"textShadowX:0px"},{"offset":0,"length":25,"style":"textShadowY:0px"},{"offset":0,"length":25,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":25,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":25,"style":"textShadowBlur:0px"},{"offset":0,"length":25,"style":"textHighlightEnable:false"},{"offset":0,"length":25,"style":"textShadowEnable:false"},{"offset":0,"length":25,"style":"hlnk:"},{"offset":0,"length":25,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":["fillColor",60004],"appearenceProperties":{"fill":{"color":"#66C4D9FF"},"shadow":{},"stroke":{}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":921.9488588777219,"top":4.243142797319962,"width":320},"shouldRender":true}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1282]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1282c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1282,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1282',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si1540:{
name:'Rectangle_5',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1540c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1551,
stt:0,
dsr:'Default_State',
stsi:[1540]
}
,{
stn:1563,
stt:102,
dsr:'Failure',
stsi:[1564]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1540','si1553','si1564','si1575'],
isDD:false
},
si1540c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1540,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1540',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1553:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1553c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1540',
stl:[{
stn:'Normal',
stt:0,
stsi:[1553]
}
]
,
stis:0,
bstiid:1540,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1540,
isDD:false
},
si1553c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1553,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1553',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1564:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1564c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1540',
stl:[{
stn:'Normal',
stt:0,
stsi:[1564]
}
]
,
stis:0,
bstiid:1540,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1540,
isDD:false
},
si1564c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1564,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1564',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1575:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1575c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1540',
stl:[{
stn:'Normal',
stt:0,
stsi:[1575]
}
]
,
stis:0,
bstiid:1540,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1540,
isDD:false
},
si1575c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1575,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1575',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1520:{
name:'Highlight_box_1',
type:1269,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1520c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1030,"top":24,"width":128,"height":32},"shouldRender":true}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si1530',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1520]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1520c:{
b:[1030,24,1158,56],
fh:false,
fw:false,
uid:1520,
iso:false,
css:{
360:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1520',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1030,24,1158,56],
vb:[1030,24,1158,56]
},
si1530:{
name:'Shape_5',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1530c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1530]
}
]
,
stis:0,
bstiid:1520,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1520',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1530c:{
b:[0,0,128,32],
fh:false,
fw:false,
uid:1530,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1530',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,130,34],
vb:[-2,-2,130,34]
},
si1630:{
name:'Rectangle_6',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1630c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1641,
stt:0,
dsr:'Default_State',
stsi:[1630]
}
,{
stn:1653,
stt:102,
dsr:'Failure',
stsi:[1654]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1630','si1643','si1654','si1665'],
isDD:false
},
si1630c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1630,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1630',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1643:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1643c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1630',
stl:[{
stn:'Normal',
stt:0,
stsi:[1643]
}
]
,
stis:0,
bstiid:1630,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1630,
isDD:false
},
si1643c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1643,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1643',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1654:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1654c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1630',
stl:[{
stn:'Normal',
stt:0,
stsi:[1654]
}
]
,
stis:0,
bstiid:1630,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1630,
isDD:false
},
si1654c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1654,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1654',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1665:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1665c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1630',
stl:[{
stn:'Normal',
stt:0,
stsi:[1665]
}
]
,
stis:0,
bstiid:1630,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1630,
isDD:false
},
si1665c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1665,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1665',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1600:{
name:'InputField_1',
type:2433,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1600c',
tag:'slide-item-inputfield',
v:0,
enabled:true,
defEn:true,
vu:[1628,1629],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:12,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"active":true,"disabled":false,"focusLost":true,"error":true},"scaleValue":"medium","isTextActive":true,"currentState":"normal","inputFieldProps":{"answersList":[],"enableCaseSensitive":true,"enableMultipleLine":false,"selectedInputFieldType":0},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"5aplf","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-inputfield-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"active":{"opacity":100,"editorState":{"blocks":[{"key":"ci2bo","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-inputfield-active","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_active","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"opacity":100,"editorState":{"blocks":[{"key":"63kdn","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-inputfield-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"focusLost":{"opacity":100,"editorState":{"blocks":[{"key":"5f43f","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-inputfield-focusLost","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_focusLost","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"error":{"opacity":100,"editorState":{"blocks":[{"key":"4l50o","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-inputfield-error","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_error","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"sizeNPos":{"left":20,"top":678,"width":165},"designOption":"DEFAULT_INPUTFIELD_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"8"}},"size":{"small":{"desktop":{"textFontSize":16,"paddingSelectContainer":"9px 20px 6px 14px"},"tablet":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"},"mobile":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"}},"medium":{"desktop":{"textFontSize":20,"paddingSelectContainer":"11px 20px 8px 14px"},"tablet":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"},"mobile":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"}},"large":{"desktop":{"textFontSize":24,"paddingSelectContainer":"13px 20px 10px 14px"},"tablet":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"},"mobile":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"}}},"inputfieldHeight":"0px"}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ifml:0,
ifcs:0,
ifst:0,
sz:1,
ifal:[''],
si:[]
,
te:true,
ie:false,
lcapid:'si1630',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1600]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1600c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1600,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1600',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1785:{
name:'Rectangle_7',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1785c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1796,
stt:0,
dsr:'Default_State',
stsi:[1785]
}
,{
stn:1808,
stt:102,
dsr:'Failure',
stsi:[1809]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1785','si1798','si1809','si1820'],
isDD:false
},
si1785c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1785,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1785',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1798:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1798c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1785',
stl:[{
stn:'Normal',
stt:0,
stsi:[1798]
}
]
,
stis:0,
bstiid:1785,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1785,
isDD:false
},
si1798c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1798,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1798',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1809:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1809c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":363.5762667504187,"left":898.0164363484085,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Click on the profile icon in the top right corner","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":49,"style":"color:#020C1C"},{"offset":0,"length":49,"style":"textShadowOpacity:none"},{"offset":0,"length":49,"style":"overridden:true"},{"offset":0,"length":49,"style":"textDecoration:none"},{"offset":0,"length":49,"style":"fontFamily:Georgia"},{"offset":0,"length":49,"style":"borderBottomStyle:none"},{"offset":0,"length":49,"style":"textShadowEnable:false"},{"offset":0,"length":49,"style":"fontWeight:normal"},{"offset":0,"length":49,"style":"textShadowBlur:8px"},{"offset":0,"length":49,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":49,"style":"fontStyle:normal"},{"offset":0,"length":49,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":49,"style":"tablet-fontSize:24"},{"offset":0,"length":49,"style":"desktop-fontSize:18"},{"offset":0,"length":49,"style":"mobile-fontSize:24"},{"offset":0,"length":49,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":49,"style":"textOutlineEnable:false"},{"offset":0,"length":49,"style":"opacity:1"},{"offset":0,"length":49,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":49,"style":"defaultTextShadow:none"},{"offset":0,"length":49,"style":"backgroundColor:unset"},{"offset":0,"length":49,"style":"textShadow:none"},{"offset":0,"length":49,"style":"textShadowX:0px"},{"offset":0,"length":49,"style":"fontStretch:normal"},{"offset":0,"length":49,"style":"fontType:regular"},{"offset":0,"length":49,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":49,"style":"textShadowY:4px"},{"offset":0,"length":49,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":49,"style":"lineHeight:135%"},{"offset":0,"length":49,"style":"letterSpacing:0%"},{"offset":0,"length":49,"style":"textHighlightEnable:false"},{"offset":0,"length":49,"style":"textTransform:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-caption_incorrect","listSize":"100%"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1785',
stl:[{
stn:'Normal',
stt:0,
stsi:[1809]
}
]
,
stis:0,
bstiid:1785,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1785,
isDD:false
},
si1809c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1809,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.278%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.167%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1809',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0 0 L 1 0 L 1 1 L 0 1 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,3,3],
vb:[-2,-2,3,3]
},
si1820:{
name:'',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1820c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1785',
stl:[{
stn:'Normal',
stt:0,
stsi:[1820]
}
]
,
stis:0,
bstiid:1785,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1785,
isDD:false
},
si1820c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1820,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1820',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1765:{
name:'Click_box_5',
type:1269,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1765c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1245.5487332495813,"top":33.81417504187607,"width":64,"height":64},"shouldRender":true,"attempts":1024}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1838);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si1785',
si:[{
n:'si1775',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1765]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1765c:{
b:[1250,24,1314,88],
fh:false,
fw:false,
uid:1765,
iso:false,
css:{
360:{
l:'128.601%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'128.601%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'128.601%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'128.601%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'128.601%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'128.601%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1765',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1250,24,1314,88],
vb:[1250,24,1314,88]
},
si1775:{
name:'Shape_6',
type:612,
from:430,
to:588,
rp:0,
rpa:0,
mdi:'si1775c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1775]
}
]
,
stis:0,
bstiid:1765,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1765',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1775c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:1775,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1775',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
Slide460:{
lb:'Simulation slide 1',
id:460,
from:430,
to:588,
iols:0,
i360qs:false,
sdu:5.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide460c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si486',
t:1268
}
]
,
iph:[]
,
oa:'si1266Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1838:{
ts:''
}
,
570:{
ts:''
}

}

},
Slide460c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:460,
dn:'Slide460',
visible:'1'
},
si603:{
name:'Simulation_2',
type:1268,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si603c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si595',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si603c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:603,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si603',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si595:{
name:'Simulation_non_responsive_2',
type:1268,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si595c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si603',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si614',
t:1269
}
,{
n:'si634',
t:612
}
,{
n:'si1845',
t:12
}
,{
n:'si1852',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si603',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si595c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:595,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si595',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:611,
tsp:50,
ip:'dr/0611.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si614:{
name:'Click_box_2',
type:1269,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si614c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":136.51256281407035,"left":1259.1330611390285,"width":24,"height":24},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si595',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(687);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:10.89,
lcapid:'si634',
si:[{
n:'si624',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[614]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si614c:{
b:[1257,134,1281,158],
fh:false,
fw:false,
uid:614,
iso:false,
css:{
360:{
l:'129.321%',
t:'22.039%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'129.321%',
lhID:-1,
lvEID:0,
lvV:'22.039%',
lvID:-1,
w:'2.469%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'129.321%',
t:'22.039%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'129.321%',
lhID:-1,
lvEID:0,
lvV:'22.039%',
lvID:-1,
w:'2.469%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'129.321%',
t:'22.039%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'129.321%',
lhID:-1,
lvEID:0,
lvV:'22.039%',
lvID:-1,
w:'2.469%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si614',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1257,134,1281,158],
vb:[1257,134,1281,158]
},
si624:{
name:'Shape_2',
type:612,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si624c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[624]
}
]
,
stis:0,
bstiid:614,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si614',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si624c:{
b:[0,0,24,24],
fh:false,
fw:false,
uid:624,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'2.469%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'2.469%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'2.469%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si624',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,26,26],
vb:[-2,-2,26,26]
},
si634:{
name:'Rectangle_2',
type:612,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si634c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":194,"left":942,"width":300,"height":"auto"}}',
parentGroup:'si595',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:645,
stt:0,
dsr:'Default_State',
stsi:[634]
}
,{
stn:657,
stt:102,
dsr:'Failure',
stsi:[658]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si634','si647','si658','si669'],
isDD:false
},
si634c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:634,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si634',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si647:{
name:'',
type:612,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si647c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":194,"left":942,"width":300,"height":"auto"}}',
parentGroup:'si595',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si634',
stl:[{
stn:'Normal',
stt:0,
stsi:[647]
}
]
,
stis:0,
bstiid:634,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:634,
isDD:false
},
si647c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:647,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si647',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si658:{
name:'',
type:612,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si658c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":461.86275125628134,"left":615.8510259631491,"width":379.37469738012976,"height":"auto"}}',
parentGroup:'si595',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Click the pencil in the right hand corner","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":41,"style":"opacity:1"},{"offset":0,"length":41,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":41,"style":"defaultTextShadow:none"},{"offset":0,"length":41,"style":"backgroundColor:unset"},{"offset":0,"length":41,"style":"tablet-fontSize:24"},{"offset":0,"length":41,"style":"textShadowX:0px"},{"offset":0,"length":41,"style":"fontStretch:normal"},{"offset":0,"length":41,"style":"fontType:regular"},{"offset":0,"length":41,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":41,"style":"textShadowY:4px"},{"offset":0,"length":41,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":41,"style":"lineHeight:135%"},{"offset":0,"length":41,"style":"letterSpacing:0%"},{"offset":0,"length":41,"style":"textHighlightEnable:false"},{"offset":0,"length":41,"style":"textTransform:none"},{"offset":0,"length":41,"style":"color:#020C1C"},{"offset":0,"length":41,"style":"textShadowOpacity:none"},{"offset":0,"length":41,"style":"overridden:true"},{"offset":0,"length":41,"style":"textDecoration:none"},{"offset":0,"length":41,"style":"fontFamily:Georgia"},{"offset":0,"length":41,"style":"borderBottomStyle:none"},{"offset":0,"length":41,"style":"textShadowEnable:false"},{"offset":0,"length":41,"style":"fontWeight:normal"},{"offset":0,"length":41,"style":"textShadowBlur:8px"},{"offset":0,"length":41,"style":"desktop-fontSize:24"},{"offset":0,"length":41,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":41,"style":"fontStyle:normal"},{"offset":0,"length":41,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":41,"style":"textShadow:none"},{"offset":0,"length":41,"style":"mobile-fontSize:24"},{"offset":0,"length":41,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":41,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-caption_incorrect","listSize":"100%"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si634',
stl:[{
stn:'Normal',
stt:0,
stsi:[658]
}
]
,
stis:0,
bstiid:634,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:634,
isDD:false
},
si658c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:658,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.278%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.167%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si658',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0 0 L 1 0 L 1 1 L 0 1 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,3,3],
vb:[-2,-2,3,3]
},
si669:{
name:'',
type:612,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si669c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":194,"left":942,"width":300,"height":"auto"}}',
parentGroup:'si595',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si634',
stl:[{
stn:'Normal',
stt:0,
stsi:[669]
}
]
,
stis:0,
bstiid:634,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:634,
isDD:false
},
si669c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:669,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si669',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1845:{
name:'Mouse_2',
type:12,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si1845c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":true,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":1},"mousePathPoints":{"mouseStartPointX":1287.337154522613,"mouseStartPointY":67.06260469011724,"mouseEndPointX":1272.2944932998323,"mouseEndPointY":148.09929857621438}}',
parentGroup:'si595',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1845Ad',
trin:0,
trout:0,
isDD:false
},
si1845c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1845,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1845',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si1845Ad:{
src:'ar/Mouse.mp3',
from:589,
to:594,
del:10.718,
msa:1,
du:0.182
},
si1852:{
name:'Instructions_2',
type:612,
from:589,
to:915,
rp:0,
rpa:0,
mdi:'si1852c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"fiv7","text":"Click to customize","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"textShadowColor:ffffff00"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"textShadowX:0px"},{"offset":0,"length":18,"style":"textShadowY:0px"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":18,"style":"textShadowBlur:0px"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":["fillColor",60004],"appearenceProperties":{"fill":{"color":"#66C4D9FF"},"shadow":{},"stroke":{}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":988.1676612227805,"top":230.6452051926298,"width":320},"shouldRender":true}',
parentGroup:'si595',
retainState:false,
immo:false,
apsn:'Slide577',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1852]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1852c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1852,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1852',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide577:{
lb:'Simulation slide 2',
id:577,
from:589,
to:915,
iols:0,
i360qs:false,
sdu:10.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide577c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si603',
t:1268
}
]
,
iph:[]
,
oa:'si1845Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
687:{
ts:''
}

}

},
Slide577c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:577,
dn:'Slide577',
visible:'1'
},
si720:{
name:'Simulation_3',
type:1268,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si720c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si712',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si720c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:720,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si720',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si712:{
name:'Simulation_non_responsive_3',
type:1268,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si712c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":true,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si720',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1962',
t:612
}
,{
n:'si1942',
t:1269
}
,{
n:'si2107',
t:612
}
,{
n:'si2087',
t:1269
}
,{
n:'si2167',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":true,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si720',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si712c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:712,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si712',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:728,
tsp:50,
ip:'dr/0728.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1962:{
name:'Rectangle_9',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si1962c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1973,
stt:0,
dsr:'Default_State',
stsi:[1962]
}
,{
stn:1985,
stt:102,
dsr:'Failure',
stsi:[1986]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1962','si1975','si1986','si1997'],
isDD:false
},
si1962c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1962,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1962',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1975:{
name:'',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si1975c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1962',
stl:[{
stn:'Normal',
stt:0,
stsi:[1975]
}
]
,
stis:0,
bstiid:1962,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1962,
isDD:false
},
si1975c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1975,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1975',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1986:{
name:'',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si1986c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1962',
stl:[{
stn:'Normal',
stt:0,
stsi:[1986]
}
]
,
stis:0,
bstiid:1962,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1962,
isDD:false
},
si1986c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1986,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1986',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1997:{
name:'',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si1997c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1962',
stl:[{
stn:'Normal',
stt:0,
stsi:[1997]
}
]
,
stis:0,
bstiid:1962,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1962,
isDD:false
},
si1997c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1997,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1997',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1942:{
name:'Highlight_box_3',
type:1269,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si1942c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"overriddenProperties":["strokeDasharray","fillColor","fillType","fillEnable","strokeColor"],"appearenceProperties":{"fill":{"color":"#F8F7F4FF","fillType":3,"enabled":false},"shadow":{},"stroke":{"dasharray":0,"color":"#D94A4AFF"}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":421.65881490787274,"top":259.6639970686767,"width":60.67773764656616,"height":31.999955424911008},"shouldRender":true}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si1952',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1942]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1942c:{
b:[1030,24,1158,56],
fh:false,
fw:false,
uid:1942,
iso:false,
css:{
360:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1942',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1030,24,1158,56],
vb:[1030,24,1158,56]
},
si1952:{
name:'Shape_8',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si1952c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1952]
}
]
,
stis:0,
bstiid:1942,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1942',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1952c:{
b:[0,0,128,32],
fh:false,
fw:false,
uid:1952,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1952',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,130,34],
vb:[-2,-2,130,34]
},
si2107:{
name:'Rectangle_10',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si2107c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2118,
stt:0,
dsr:'Default_State',
stsi:[2107]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2107','si2120','si2131','si2142'],
isDD:false
},
si2107c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2107,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2107',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2120:{
name:'',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si2120c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2107',
stl:[{
stn:'Normal',
stt:0,
stsi:[2120]
}
]
,
stis:0,
bstiid:2107,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2107,
isDD:false
},
si2120c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2120,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2120',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2131:{
name:'',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si2131c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2107',
stl:[{
stn:'Normal',
stt:0,
stsi:[2131]
}
]
,
stis:0,
bstiid:2107,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2107,
isDD:false
},
si2131c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2131,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2131',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2142:{
name:'',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si2142c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2107',
stl:[{
stn:'Normal',
stt:0,
stsi:[2142]
}
]
,
stis:0,
bstiid:2107,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2107,
isDD:false
},
si2142c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2142,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2142',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2087:{
name:'Click_box_6',
type:1269,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si2087c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":420.40850083752093,"top":260.4437814070352,"width":75.16913997068676,"height":28.93536693886097},"shouldRender":true,"attempts":1024}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2160);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si2107',
si:[{
n:'si2097',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2087]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2087c:{
b:[1250,24,1314,88],
fh:false,
fw:false,
uid:2087,
iso:false,
css:{
360:{
l:'128.601%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'128.601%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'128.601%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'128.601%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'128.601%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'128.601%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2087',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1250,24,1314,88],
vb:[1250,24,1314,88]
},
si2097:{
name:'Shape_9',
type:612,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si2097c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2097]
}
]
,
stis:0,
bstiid:2087,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2087',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2097c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:2097,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2097',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
si2167:{
name:'Mouse_3',
type:12,
from:916,
to:1602,
rp:0,
rpa:0,
mdi:'si2167c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.9,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":true,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":1},"mousePathPoints":{"mouseStartPointX":1272.2944932998323,"mouseStartPointY":148.09929857621438,"mouseEndPointX":474.0258061139028,"mouseEndPointY":278.0524497487437}}',
parentGroup:'si712',
retainState:false,
immo:false,
apsn:'Slide694',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2167Ad',
trin:0,
trout:0,
isDD:false
},
si2167c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2167,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2167',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2167Ad:{
src:'ar/Mouse.mp3',
from:916,
to:921,
del:22.718,
msa:1,
du:0.182
},
Slide694:{
lb:'Simulation slide 3',
id:694,
from:916,
to:1602,
iols:0,
i360qs:false,
sdu:22.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide694c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si720',
t:1268
}
]
,
iph:[]
,
oa:'si2167Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2160:{
ts:''
}

}

},
Slide694c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:694,
dn:'Slide694',
visible:'1'
},
StAd1:{
from:1,
to:1809,
src:'ar/StAd0.mp3',
du:60454,
saup:[{
sn:1292,
del:0,
du:14.2531,
l:false
}
,{
sn:460,
del:0,
du:5.30204,
l:false
}
,{
sn:577,
del:0,
du:10.9204,
l:false
}
,{
sn:694,
del:0,
du:22.902,
l:false
}
,{
sn:731,
del:0,
du:7.07755,
l:false
}
]

},
si757:{
name:'Simulation_4',
type:1268,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si757c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si749',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si757c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:757,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si757',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si749:{
name:'Simulation_non_responsive_4',
type:1268,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si749c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si757',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si765',
t:1269
}
,{
n:'si785',
t:612
}
,{
n:'si2180',
t:12
}
,{
n:'si2187',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si757',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si749c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:749,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si749',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:728,
tsp:50,
ip:'dr/0728.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si765:{
name:'Click_box_3',
type:1269,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si765c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":467.2387981574539,"left":522.5561662479062,"width":69.44410365630233,"height":76.94094863968277},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si749',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(838);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:10.72,
lcapid:'si785',
si:[{
n:'si775',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[765]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si765c:{
b:[557,488,591,508],
fh:false,
fw:false,
uid:765,
iso:false,
css:{
360:{
l:'57.305%',
t:'80.263%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'57.305%',
lhID:-1,
lvEID:0,
lvV:'80.263%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'57.305%',
t:'80.263%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'57.305%',
lhID:-1,
lvEID:0,
lvV:'80.263%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'57.305%',
t:'80.263%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'57.305%',
lhID:-1,
lvEID:0,
lvV:'80.263%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si765',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[557,488,591,508],
vb:[557,488,591,508]
},
si775:{
name:'Shape_3',
type:612,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si775c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[775]
}
]
,
stis:0,
bstiid:765,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si765',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si775c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:775,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si775',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si785:{
name:'Rectangle_3',
type:612,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si785c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":548,"left":572,"width":300,"height":"auto"}}',
parentGroup:'si749',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:796,
stt:0,
dsr:'Default_State',
stsi:[785]
}
,{
stn:808,
stt:102,
dsr:'Failure',
stsi:[809]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si785','si798','si809','si820'],
isDD:false
},
si785c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:785,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si785',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si798:{
name:'',
type:612,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si798c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":548,"left":572,"width":300,"height":"auto"}}',
parentGroup:'si749',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si785',
stl:[{
stn:'Normal',
stt:0,
stsi:[798]
}
]
,
stis:0,
bstiid:785,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:785,
isDD:false
},
si798c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:798,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si798',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si809:{
name:'',
type:612,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si809c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":565.8038630653266,"left":836.1789677554439,"width":379.8589914088672,"height":"auto"}}',
parentGroup:'si749',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Click on the viridian green theme color","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":39,"style":"overridden:false"},{"offset":0,"length":39,"style":"opacity:1"},{"offset":0,"length":39,"style":"backgroundColor:unset"},{"offset":0,"length":39,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":39,"style":"textHighlightEnable:false"},{"offset":0,"length":39,"style":"textOutlineEnable:false"},{"offset":0,"length":39,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si785',
stl:[{
stn:'Normal',
stt:0,
stsi:[809]
}
]
,
stis:0,
bstiid:785,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:785,
isDD:false
},
si809c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:809,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.278%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.167%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si809',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0 0 L 1 0 L 1 1 L 0 1 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,3,3],
vb:[-2,-2,3,3]
},
si820:{
name:'',
type:612,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si820c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":548,"left":572,"width":300,"height":"auto"}}',
parentGroup:'si749',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si785',
stl:[{
stn:'Normal',
stt:0,
stsi:[820]
}
]
,
stis:0,
bstiid:785,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:785,
isDD:false
},
si820c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:820,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si820',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2180:{
name:'Mouse_4',
type:12,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si2180c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":true,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":1},"mousePathPoints":{"mouseStartPointX":474.0258061139028,"mouseStartPointY":278.0524497487437,"mouseEndPointX":575.8500314070351,"mouseEndPointY":528.0131909547738}}',
parentGroup:'si749',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2180Ad',
trin:0,
trout:0,
isDD:false
},
si2180c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2180,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2180',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2180Ad:{
src:'ar/Mouse.mp3',
from:1603,
to:1608,
del:10.518,
msa:1,
du:0.182
},
si2187:{
name:'Instructions_3',
type:612,
from:1603,
to:1924,
rp:0,
rpa:0,
mdi:'si2187c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"d52r6","text":"Choose your theme color","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"textShadowColor:ffffff00"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"textShadowY:0px"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":23,"style":"textShadowBlur:0px"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":["fillColor",60004],"appearenceProperties":{"fill":{"color":"#66C4D9FF"},"shadow":{},"stroke":{}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":606.3562604690117,"top":301.0558521775544,"width":320},"shouldRender":true}',
parentGroup:'si749',
retainState:false,
immo:false,
apsn:'Slide731',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2187]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2187c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2187,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2187',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide731:{
lb:'Simulation slide 4',
id:731,
from:1603,
to:1924,
iols:0,
i360qs:false,
sdu:10.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide731c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si757',
t:1268
}
]
,
iph:[]
,
oa:'si2180Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
838:{
ts:''
}

}

},
Slide731c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:731,
dn:'Slide731',
visible:'1'
},
si871:{
name:'Simulation_5',
type:1268,
from:1925,
to:2101,
rp:0,
rpa:0,
mdi:'si871c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide845',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si863',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si871c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:871,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si871',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si863:{
name:'Simulation_non_responsive_5',
type:1268,
from:1925,
to:2101,
rp:0,
rpa:0,
mdi:'si863c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si871',
retainState:false,
immo:false,
apsn:'Slide845',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2199',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si871',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si863c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:863,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si863',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:879,
tsp:50,
ip:'dr/0879.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2199:{
name:'Mouse_5',
type:12,
from:1925,
to:2101,
rp:0,
rpa:0,
mdi:'si2199c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.9,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":true,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":1},"mousePathPoints":{"mouseStartPointX":575.8500314070351,"mouseStartPointY":528.0131909547738,"mouseEndPointX":513.3304020100502,"mouseEndPointY":730.1174623115577}}',
parentGroup:'si863',
retainState:false,
immo:false,
apsn:'Slide845',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2199Ad',
trin:0,
trout:0,
isDD:false
},
si2199c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2199,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2199',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2199Ad:{
src:'ar/Mouse.mp3',
from:1925,
to:1930,
del:5.718,
msa:1,
du:0.182
},
Slide845:{
lb:'Simulation slide 5',
id:845,
from:1925,
to:2101,
iols:0,
i360qs:false,
sdu:5.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide845c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si871',
t:1268
}
]
,
iph:[]
,
oa:'si2199Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide845c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:845,
dn:'Slide845',
visible:'1'
},
si900:{
name:'Video_1',
type:1268,
from:2102,
to:2122,
rp:0,
rpa:0,
mdi:'si900c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide882',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si919',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si900c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:900,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si900',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si919:{
name:'SlideVideo_1',
type:365,
from:2102,
to:2122,
rp:0,
rpa:0,
mdi:'si919c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.7,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si900',
retainState:false,
immo:false,
apsn:'Slide882',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si919c:{
b:[-183,-70,1155,678],
fh:false,
fw:false,
uid:919,
iso:false,
css:{
360:{
l:'-18.827%',
t:'-11.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-18.827%',
lhID:-1,
lvEID:0,
lvV:'-11.513%',
lvID:-1,
w:'137.654%',
h:'123.026%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-18.827%',
t:'-11.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-18.827%',
lhID:-1,
lvEID:0,
lvV:'-11.513%',
lvID:-1,
w:'137.654%',
h:'123.026%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-18.827%',
t:'-11.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-18.827%',
lhID:-1,
lvEID:0,
lvV:'-11.513%',
lvID:-1,
w:'137.654%',
h:'123.026%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si919',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/0915.png',
mp4:'vr/Vi908.mp4',
vsf:0,
vst:0.7,
o:100,
vbwr:[-184,-71,1156,679],
vb:[-184,-71,1156,679]
},
Slide882:{
lb:'Simulation slide 6',
id:882,
from:2102,
to:2122,
iols:0,
i360qs:false,
sdu:0.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide882c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si900',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide882c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:882,
dn:'Slide882',
visible:'1'
},
si952:{
name:'Simulation_6',
type:1268,
from:2123,
to:2133,
rp:0,
rpa:0,
mdi:'si952c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide926',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si944',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si952c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:952,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si952',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si944:{
name:'Simulation_non_responsive_6',
type:1268,
from:2123,
to:2133,
rp:0,
rpa:0,
mdi:'si944c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si952',
retainState:false,
immo:false,
apsn:'Slide926',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2206',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si952',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si944c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:944,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si944',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:960,
tsp:50,
ip:'dr/0960.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2206:{
name:'Mouse_6',
type:12,
from:2123,
to:2133,
rp:0,
rpa:0,
mdi:'si2206c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":513.3304020100502,"mouseStartPointY":730.1174623115577,"mouseEndPointX":513.3304020100502,"mouseEndPointY":730.1174623115577}}',
parentGroup:'si944',
retainState:false,
immo:false,
apsn:'Slide926',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2206Ad',
trin:0,
trout:0,
isDD:false
},
si2206c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2206,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2206',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2206Ad:{
src:'ar/Mouse.mp3',
from:2123,
to:2128,
del:0.118,
msa:1,
du:0.182
},
Slide926:{
lb:'Simulation slide 7',
id:926,
from:2123,
to:2133,
iols:0,
i360qs:false,
sdu:0.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide926c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si952',
t:1268
}
]
,
iph:[]
,
oa:'si2206Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide926c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:926,
dn:'Slide926',
visible:'1'
},
si981:{
name:'Video_2',
type:1268,
from:2134,
to:2154,
rp:0,
rpa:0,
mdi:'si981c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide963',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1000',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si981c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:981,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si981',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1000:{
name:'SlideVideo_2',
type:365,
from:2134,
to:2154,
rp:0,
rpa:0,
mdi:'si1000c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.7,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si981',
retainState:false,
immo:false,
apsn:'Slide963',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si1000c:{
b:[-183,-70,1155,678],
fh:false,
fw:false,
uid:1000,
iso:false,
css:{
360:{
l:'-18.827%',
t:'-11.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-18.827%',
lhID:-1,
lvEID:0,
lvV:'-11.513%',
lvID:-1,
w:'137.654%',
h:'123.026%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-18.827%',
t:'-11.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-18.827%',
lhID:-1,
lvEID:0,
lvV:'-11.513%',
lvID:-1,
w:'137.654%',
h:'123.026%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-18.827%',
t:'-11.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-18.827%',
lhID:-1,
lvEID:0,
lvV:'-11.513%',
lvID:-1,
w:'137.654%',
h:'123.026%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1000',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/0996.png',
mp4:'vr/Vi989.mp4',
vsf:0,
vst:0.7,
o:100,
vbwr:[-184,-71,1156,679],
vb:[-184,-71,1156,679]
},
Slide963:{
lb:'Simulation slide 8',
id:963,
from:2134,
to:2154,
iols:0,
i360qs:false,
sdu:0.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide963c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si981',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide963c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:963,
dn:'Slide963',
visible:'1'
},
si1033:{
name:'Simulation_7',
type:1268,
from:2155,
to:2191,
rp:0,
rpa:0,
mdi:'si1033c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1007',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1025',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1033c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1033,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1033',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1025:{
name:'Simulation_non_responsive_7',
type:1268,
from:2155,
to:2191,
rp:0,
rpa:0,
mdi:'si1025c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1033',
retainState:false,
immo:false,
apsn:'Slide1007',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2213',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1033',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1025c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1025,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1025',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:1041,
tsp:50,
ip:'dr/01041.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2213:{
name:'Mouse_7',
type:12,
from:2155,
to:2191,
rp:0,
rpa:0,
mdi:'si2213c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.2,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":513.3304020100502,"mouseStartPointY":730.1174623115577,"mouseEndPointX":526.1745707705192,"mouseEndPointY":705.371335845896}}',
parentGroup:'si1025',
retainState:false,
immo:false,
apsn:'Slide1007',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2213Ad',
trin:0,
trout:0,
isDD:false
},
si2213c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2213,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2213',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2213Ad:{
src:'ar/Mouse.mp3',
from:2155,
to:2160,
del:1.018,
msa:1,
du:0.182
},
Slide1007:{
lb:'Simulation slide 9',
id:1007,
from:2155,
to:2191,
iols:0,
i360qs:false,
sdu:1.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1007c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1033',
t:1268
}
]
,
iph:[]
,
oa:'si2213Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1007c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1007,
dn:'Slide1007',
visible:'1'
},
StAd3:{
from:1925,
to:2323,
src:'ar/StAd2.mp3',
du:13444,
saup:[{
sn:845,
del:0,
du:5.91633,
l:false
}
,{
sn:882,
del:0,
du:0.7,
l:false
}
,{
sn:926,
del:0,
du:0.3,
l:false
}
,{
sn:963,
del:0,
du:0.7,
l:false
}
,{
sn:1007,
del:0,
du:1.2,
l:false
}
,{
sn:1088,
del:0,
du:4.62857,
l:false
}
]

},
si1114:{
name:'Simulation_8',
type:1268,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1114c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1106',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1114c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1114,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1114',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1106:{
name:'Simulation_non_responsive_8',
type:1268,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1106c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1114',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1125',
t:1269
}
,{
n:'si1145',
t:612
}
,{
n:'si2220',
t:12
}
,{
n:'si2227',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1114',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1106c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1106,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1106',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:1122,
tsp:50,
ip:'dr/01122.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1125:{
name:'Click_box_4',
type:1269,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1125c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":481.28768844221105,"left":426.4862332495812,"width":67.49486364112227,"height":71.79405940836996},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1106',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1198);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:7.417,
lcapid:'si1145',
si:[{
n:'si1135',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1125]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1125c:{
b:[442,505,476,525],
fh:false,
fw:false,
uid:1125,
iso:false,
css:{
360:{
l:'45.473%',
t:'83.059%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'45.473%',
lhID:-1,
lvEID:0,
lvV:'83.059%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'45.473%',
t:'83.059%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'45.473%',
lhID:-1,
lvEID:0,
lvV:'83.059%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'45.473%',
t:'83.059%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'45.473%',
lhID:-1,
lvEID:0,
lvV:'83.059%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1125',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[442,505,476,525],
vb:[442,505,476,525]
},
si1135:{
name:'Shape_4',
type:612,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1135c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1135]
}
]
,
stis:0,
bstiid:1125,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1125',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1135c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1135,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1135',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1145:{
name:'Rectangle_4',
type:612,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1145c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":565,"left":457,"width":300,"height":"auto"}}',
parentGroup:'si1106',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1156,
stt:0,
dsr:'Default_State',
stsi:[1145]
}
,{
stn:1168,
stt:102,
dsr:'Failure',
stsi:[1169]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1145','si1158','si1169','si1180'],
isDD:false
},
si1145c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1145,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1145',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1158:{
name:'',
type:612,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1158c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":565,"left":457,"width":300,"height":"auto"}}',
parentGroup:'si1106',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1145',
stl:[{
stn:'Normal',
stt:0,
stsi:[1158]
}
]
,
stis:0,
bstiid:1145,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1145,
isDD:false
},
si1158c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1158,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1158',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1169:{
name:'',
type:612,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1169c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":656.2112646566164,"left":546.9484401172529,"width":300,"height":"auto"}}',
parentGroup:'si1106',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Click on the sunglasses icon","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"desktop-fontSize:18"},{"offset":0,"length":28,"style":"mobile-fontSize:24"},{"offset":0,"length":28,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"defaultTextShadow:none"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"textShadow:none"},{"offset":0,"length":28,"style":"textShadowX:0px"},{"offset":0,"length":28,"style":"fontStretch:normal"},{"offset":0,"length":28,"style":"fontType:regular"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":28,"style":"textShadowY:4px"},{"offset":0,"length":28,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":28,"style":"lineHeight:135%"},{"offset":0,"length":28,"style":"letterSpacing:0%"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textTransform:none"},{"offset":0,"length":28,"style":"color:#020C1C"},{"offset":0,"length":28,"style":"textShadowOpacity:none"},{"offset":0,"length":28,"style":"overridden:true"},{"offset":0,"length":28,"style":"textDecoration:none"},{"offset":0,"length":28,"style":"fontFamily:Georgia"},{"offset":0,"length":28,"style":"borderBottomStyle:none"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"fontWeight:normal"},{"offset":0,"length":28,"style":"textShadowBlur:8px"},{"offset":0,"length":28,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"fontStyle:normal"},{"offset":0,"length":28,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"tablet-fontSize:24"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-caption_incorrect","listSize":"100%"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1145',
stl:[{
stn:'Normal',
stt:0,
stsi:[1169]
}
]
,
stis:0,
bstiid:1145,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1145,
isDD:false
},
si1169c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1169,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.278%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.167%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1169',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0 0 L 1 0 L 1 1 L 0 1 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,3,3],
vb:[-2,-2,3,3]
},
si1180:{
name:'',
type:612,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si1180c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":565,"left":457,"width":300,"height":"auto"}}',
parentGroup:'si1106',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1145',
stl:[{
stn:'Normal',
stt:0,
stsi:[1180]
}
]
,
stis:0,
bstiid:1145,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1145,
isDD:false
},
si1180c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1180,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1180',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2220:{
name:'Mouse_8',
type:12,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si2220c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":true,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":1},"mousePathPoints":{"mouseStartPointX":513.3304020100502,"mouseStartPointY":730.1174623115577,"mouseEndPointX":477.7488484087101,"mouseEndPointY":530.3229166666666}}',
parentGroup:'si1106',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2220Ad',
trin:0,
trout:0,
isDD:false
},
si2220c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2220,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2220',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2220Ad:{
src:'ar/Mouse.mp3',
from:2192,
to:2197,
del:7.218,
msa:1,
du:0.182
},
si2227:{
name:'Instructions_4',
type:612,
from:2192,
to:2414,
rp:0,
rpa:0,
mdi:'si2227c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"d52r6","text":"Choose an avatar","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"hlnkt:wp"},{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"textShadowColor:ffffff00"},{"offset":0,"length":16,"style":"hlnke:true"},{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"textShadowX:0px"},{"offset":0,"length":16,"style":"textShadowY:0px"},{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":16,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":16,"style":"textShadowBlur:0px"},{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"overridden:false"},{"offset":0,"length":16,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004,"fillColor"],"appearenceProperties":{"fill":{"color":"#66C4D9FF"},"shadow":{},"stroke":{}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":189.3297215242881,"top":352.54376046901166,"width":320},"shouldRender":true}',
parentGroup:'si1106',
retainState:false,
immo:false,
apsn:'Slide1088',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2227]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2227c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2227,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2227',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1088:{
lb:'Simulation slide 11',
id:1088,
from:2192,
to:2414,
iols:0,
i360qs:false,
sdu:7.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1088c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1114',
t:1268
}
]
,
iph:[]
,
oa:'si2220Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1198:{
ts:''
}

}

},
Slide1088c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1088,
dn:'Slide1088',
visible:'1'
},
si1231:{
name:'Simulation_9',
type:1268,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si1231c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1223',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1231c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1231,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1231',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1223:{
name:'Simulation_non_responsive_9',
type:1268,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si1223c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":true,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1231',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2243',
t:12
}
,{
n:'si2270',
t:612
}
,{
n:'si2250',
t:1269
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":true,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1338,"height":748},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1231',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1223c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1223,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1223',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2676,
h:1496,
id:1239,
tsp:50,
ip:'dr/01239.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2243:{
name:'Mouse_9',
type:12,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si2243c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":true,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":1},"mousePathPoints":{"mouseStartPointX":477.7488484087101,"mouseStartPointY":530.3229166666666,"mouseEndPointX":183.13777219430477,"mouseEndPointY":665.8573597152429}}',
parentGroup:'si1223',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2243Ad',
trin:0,
trout:0,
isDD:false
},
si2243c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2243,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2243',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2243Ad:{
src:'ar/Mouse.mp3',
from:2415,
to:2420,
del:17.118,
msa:1,
du:0.182
},
si2270:{
name:'Rectangle_11',
type:612,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si2270c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si1223',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2281,
stt:0,
dsr:'Default_State',
stsi:[2270]
}
,{
stn:2293,
stt:102,
dsr:'Failure',
stsi:[2294]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2270','si2283','si2294','si2305'],
isDD:false
},
si2270c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2270,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2270',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2283:{
name:'',
type:612,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si2283c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si1223',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2270',
stl:[{
stn:'Normal',
stt:0,
stsi:[2283]
}
]
,
stis:0,
bstiid:2270,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2270,
isDD:false
},
si2283c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2283,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2283',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2294:{
name:'',
type:612,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si2294c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si1223',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2270',
stl:[{
stn:'Normal',
stt:0,
stsi:[2294]
}
]
,
stis:0,
bstiid:2270,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2270,
isDD:false
},
si2294c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2294,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2294',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2305:{
name:'',
type:612,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si2305c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si1223',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2270',
stl:[{
stn:'Normal',
stt:0,
stsi:[2305]
}
]
,
stis:0,
bstiid:2270,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2270,
isDD:false
},
si2305c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2305,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2305',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2250:{
name:'Highlight_box_4',
type:1269,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si2250c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"overriddenProperties":["fillEnable","strokeDasharray","strokeColor"],"appearenceProperties":{"fill":{"enabled":false},"shadow":{},"stroke":{"dasharray":0,"color":"#D94A4AFF"}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":50.623953098827656,"top":652.4286013400334,"width":128,"height":32},"shouldRender":true}',
parentGroup:'si1223',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2260',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2250]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2250c:{
b:[1030,24,1158,56],
fh:false,
fw:false,
uid:2250,
iso:false,
css:{
360:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'105.967%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'105.967%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2250',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1030,24,1158,56],
vb:[1030,24,1158,56]
},
si2260:{
name:'Shape_10',
type:612,
from:2415,
to:2933,
rp:0,
rpa:0,
mdi:'si2260c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1205',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2260]
}
]
,
stis:0,
bstiid:2250,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2250',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2260c:{
b:[0,0,128,32],
fh:false,
fw:false,
uid:2260,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2260',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,130,34],
vb:[-2,-2,130,34]
},
Slide1205:{
lb:'Simulation slide 12',
id:1205,
from:2415,
to:2933,
iols:0,
i360qs:false,
sdu:17.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1205c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1231',
t:1268
}
]
,
iph:[]
,
oa:'si2243Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1205c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1205,
dn:'Slide1205',
visible:'1'
},
StAd4:{
from:2415,
to:2932,
src:'ar/2241.mp3',
du:17318,
saup:[{
sn:1205,
del:0,
du:17.3184,
l:false
}
]

},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
var1628var1628:{
vid:1628,
name:'variableEditBoxStr_1',
vv:'',
vvt:2,
vt:0
},
var1629var1629:{
vid:1629,
name:'variableEditBoxNum_1',
vv:0,
vvt:1,
vt:0
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned',
var1628:'variableEditBoxStr_1',
var1629:'variableEditBoxNum_1'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1366,
h:768,
iw:1366,
ih:768,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'lab2_software_sim.cpt'
},
projectThemeData:{
image_presets:'{\
  "theme_image_default": {\
    "meta": {\
      "name": "kCPImageStyleNormal",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_default--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_default--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Normal",\
        "mixBlendMode": "normal"\
      }\
    }\
  },\
\
  "theme_image_greyscale": {\
    "meta": {\
      "name": "kCPImageStyleGreyscale",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_greyscale--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Greyscale",\
        "mixBlendMode": "saturation",\
        "intensity": "var(--theme_image_greyscale--intensity)",\
        "filterColor": {\
          "fill": "#000000",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_lighten": {\
    "meta": {\
      "name": "kCPImageStyleLighten",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_lighten--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_lighten--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Lighten",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_lighten--intensity)",\
        "filterColor": {\
          "fill": "#FFFFFF",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_darken": {\
    "meta": {\
      "name": "kCPImageStyleDarken",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_darken--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_darken--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Darken",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_darken--intensity)",\
        "filterColor": {\
          "fill": "var(--black)",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_overlay": {\
    "meta": {\
      "name": "kCPImageStyleOverlay",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_overlay--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_overlay--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Overlay",\
        "mixBlendMode": "overlay",\
        "intensity": "var(--theme_image_overlay--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  },\
\
  "theme_image_colorize": {\
    "meta": {\
      "name": "kCPImageStyleColorize",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_colorize--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_colorize--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Colorize",\
        "mixBlendMode": "color",\
        "intensity": "var(--theme_image_colorize--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  }\
}\
',
meta:'{\
  "name": "kCPThemeLight",\
  "description": "kCPThemeLightDescription",\
  "version": 0.1,\
  "guid": "Default-Light-Theme",\
  "default_presets": {\
    "0": "cp_default_shape_solid_style",\
    "1": "text-body-1",\
    "2": "theme_image_default",\
    "3": "cp_default_slide_style",\
    "4": "cp_textinshape_body_1",\
    "5": "cp_default_line_shape_style",\
    "6": "cp_default_complex_shape_solid_style",\
    "7": "cp_button_style_1_textonly",\
    "8": "cp_checkbox_style_1_textonly",\
    "9": "cp_svg_style",\
    "10": "cp_dropDown_style_1",\
    "11": "cp_radiobutton_style_1_textonly",\
    "12": "cp_inputField_style_1",\
    "13": "cp_clickbox_style",\
    "14": "cp_responsive_container_style",\
    "15": "cp_default_shape_solid_style"\
  },\
  "color_palettes": [\
    {\
      "name": "Light Palette - 1",\
      "colors": [\
        "var(--color1)",\
        "var(--color2)",\
        "var(--color3)",\
        "var(--color4)",\
        "var(--color5)",\
        "var(--color6)",\
        "var(--color7)",\
        "var(--color5_light)",\
        "var(--color4_dark)"\
      ]\
    }\
  ],\
  "active_color_palette": 0\
}',
other_presets:'{\
  "cp_default_slide_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "type": 3,\
      "category": 0\
    },\
    "backgroundColor": "var(--palette-color1)",\
    "outlineColor": "var(--palette-color5)",\
    "outlineWidth": 1,\
    "outlineStyle": "solid",\
    "outlineCap": "butt",\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 0,\
            "y": 0\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_responsive_container_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 14,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": 1,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_correct": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--success)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incorrect": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--error)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incomplete": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--incomplete)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_hint": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--hint)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_retry": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--retry)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_timeout": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--timeout)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color1)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_radial_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}',
theme:'{\
  "--primary": "#F1EEE6",\
\
  "--color1": "#FFFFFF",\
  "--color2": "#F8F7F4",\
  "--color3": "#F1EEE6",\
  "--color4": "#D6D5D1",\
  "--color5": "#666666",\
  "--color6": "#333333",\
  "--color7": "#020C1C",\
  "--colorC7": "#F7F7F7",\
  "--disabledC12": "#989898",\
  "--color1_light": "#FFCD74",\
  "--color1_dark": "#C76D12",\
  "--color2_light": "#86FFFF",\
  "--color2_dark": "#00ACCC",\
  "--color3_light": "#9B5DFF",\
  "--color3_dark": "#0000CA",\
  "--color4_light": "#99FF99",\
  "--color4_dark": "#112FA7",\
  "--color5_light": "#163EE5",\
  "--color5_dark": "#00CB92",\
  "--color6_light": "#7697FF",\
  "--color6_dark": "#0040CB",\
  "--color7_light": "#FF8E64",\
  "--color7_dark": "#C5230B",\
\
  "--success": "#558564",\
  "--error": "#C83E4D",\
  "--hint": "#CB6F10",\
  "--incomplete":"#E8BD2B",\
  "--timeout": "#C74545",\
  "--retry": "#CB6F10",\
  "--white": "#ffffff",\
  "--black": "#000000",\
\
  "--greyscale1": "#FFFFFF",\
  "--greyscale2": "#F1EEE61F",\
  "--greyscale3": "#B3B3B3",\
  "--greyscale4": "#4B4B4B",\
  "--greyscale5": "#333333",\
  "--disabled": "#818181",\
\
  "--palette-color0": "var(--color1)",\
  "--palette-color1": "var(--color2)",\
  "--palette-color2": "var(--color3)",\
  "--palette-color3": "var(--color4)",\
  "--palette-color4": "var(--color5)",\
  "--palette-color5": "var(--color6)",\
  "--palette-color6": "var(--color7)",\
  "--palette-color7": "var(--color5_light)",\
  "--palette-color8": "var(--color4_dark)",\
\
  "--design-option-color1": "255, 255, 255",\
  "--design-option-color2": "248, 247, 244",\
  "--design-option-color3": "241, 238, 230",\
  "--design-option-color4": "214, 213, 209",\
  "--design-option-color5": "102, 102, 102",\
  "--design-option-color6": "51, 51, 51",\
  "--design-option-color7": "2, 12, 28",\
  "--design-option-color5_light": "22, 62, 229",\
  "--design-option-color4_dark": "17, 47, 167",\
\
  "--c1": "var(--design-option-color1)",\
  "--c2": "var(--design-option-color2)",\
  "--c3": "var(--design-option-color3)",\
  "--c4": "var(--design-option-color4)",\
  "--c5": "var(--design-option-color5)",\
  "--c6": "var(--design-option-color6)",\
  "--c7": "var(--design-option-color7)",\
  "--c8": "var(--design-option-color5_light)",\
  "--c9": "var(--design-option-color4_dark)",\
  \
  "--widget-container--fillcolor": "var(--palette-color1)",\
\
  "--font1": "Georgia",\
  "--font2": "Arial",\
  "--text-style-unset": "none",\
\
  "--text-heading-1--fontSize--desktop": "120px",\
  "--text-heading-1--fontSize--tablet": "100px",\
  "--text-heading-1--fontSize--mobile": "80px",\
  "--text-heading-1--fontFamily": "var(--font1)",\
  "--text-heading-1--fontWeight": "normal",\
  "--text-heading-1--fontType": "regular",\
  "--text-heading-1--fontStyle": "normal",\
  "--text-heading-1--fontStretch": "normal",\
  "--text-heading-1--lineHeight": "1.07",\
  "--text-heading-1--marginLeft": "0px",\
  "--text-heading-1--color": "var(--palette-color6)",\
  "--text-heading-1--borderBottomStyle": "none",\
  "--text-heading-1--textDecoration": "none",\
  "--text-heading-1--letterSpacing": "-0.01",\
  "--text-heading-1--textTransform": "none",\
  "--text-heading-1--stroke": "var(--palette-color2)",\
  "--text-heading-1--textAlign": "left",\
  "--text-heading-1--justifyContent": "flex-start",\
  "--text-heading-1--marginTop": "auto",\
  "--text-heading-1--marginBottom": "0",\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-2--fontSize--desktop": "80px",\
  "--text-heading-2--fontSize--tablet": "72px",\
  "--text-heading-2--fontSize--mobile": "60px",\
  "--text-heading-2--fontFamily": "var(--font1)",\
  "--text-heading-2--fontWeight": "normal",\
  "--text-heading-2--fontType": "regular",\
  "--text-heading-2--fontStyle": "normal",\
  "--text-heading-2--fontStretch": "normal",\
  "--text-heading-2--lineHeight": "1.1",\
  "--text-heading-2--marginLeft": "0px",\
  "--text-heading-2--color": "var(--palette-color6)",\
  "--text-heading-2--borderBottomStyle": "none",\
  "--text-heading-2--textDecoration": "none",\
  "--text-heading-2--letterSpacing": "-0.04",\
  "--text-heading-2--textTransform": "none",\
  "--text-heading-2--stroke": "var(--palette-color2)",\
  "--text-heading-2--textAlign": "left",\
  "--text-heading-2--justifyContent": "flex-start",\
  "--text-heading-2--marginTop": "auto",\
  "--text-heading-2--marginBottom": "0",\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-3--fontSize--desktop": "60px",\
  "--text-heading-3--fontSize--tablet": "52px",\
  "--text-heading-3--fontSize--mobile": "44px",\
  "--text-heading-3--fontFamily": "var(--font1)",\
  "--text-heading-3--fontWeight": "normal",\
  "--text-heading-3--fontType": "regular",\
  "--text-heading-3--fontStyle": "normal",\
  "--text-heading-3--fontStretch": "normal",\
  "--text-heading-3--lineHeight": "1.1",\
  "--text-heading-3--marginLeft": "0px",\
  "--text-heading-3--color": "var(--palette-color6)",\
  "--text-heading-3--borderBottomStyle": "none",\
  "--text-heading-3--textDecoration": "none",\
  "--text-heading-3--letterSpacing": "0.03",\
  "--text-heading-3--textTransform": "none",\
  "--text-heading-3--stroke": "var(--palette-color2)",\
  "--text-heading-3--textAlign": "left",\
  "--text-heading-3--justifyContent": "flex-start",\
  "--text-heading-3--marginTop": "auto",\
  "--text-heading-3--marginBottom": "0",\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-4--fontSize--desktop": "52px",\
  "--text-heading-4--fontSize--tablet": "40px",\
  "--text-heading-4--fontSize--mobile": "32px",\
  "--text-heading-4--fontFamily": "var(--font1)",\
  "--text-heading-4--fontWeight": "normal",\
  "--text-heading-4--fontType": "regular",\
  "--text-heading-4--fontStyle": "normal",\
  "--text-heading-4--fontStretch": "normal",\
  "--text-heading-4--lineHeight": "1.15",\
  "--text-heading-4--marginLeft": "0px",\
  "--text-heading-4--color": "var(--palette-color6)",\
  "--text-heading-4--borderBottomStyle": "none",\
  "--text-heading-4--textDecoration": "none",\
  "--text-heading-4--letterSpacing": "0.10",\
  "--text-heading-4--textTransform": "uppercase",\
  "--text-heading-4--stroke": "var(--palette-color2)",\
  "--text-heading-4--textAlign": "left",\
  "--text-heading-4--justifyContent": "flex-start",\
  "--text-heading-4--marginTop": "auto",\
  "--text-heading-4--marginBottom": "0",\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-5--fontSize--desktop": "40px",\
  "--text-heading-5--fontSize--tablet": "32px",\
  "--text-heading-5--fontSize--mobile": "28px",\
  "--text-heading-5--fontFamily": "var(--font1)",\
  "--text-heading-5--fontWeight": "normal",\
  "--text-heading-5--fontType": "regular",\
  "--text-heading-5--fontStyle": "normal",\
  "--text-heading-5--fontStretch": "normal",\
  "--text-heading-5--lineHeight": "1.2",\
  "--text-heading-5--marginLeft": "0px",\
  "--text-heading-5--color": "var(--palette-color6)",\
  "--text-heading-5--borderBottomStyle": "none",\
  "--text-heading-5--textDecoration": "none",\
  "--text-heading-5--letterSpacing": "0",\
  "--text-heading-5--textTransform": "none",\
  "--text-heading-5--stroke": "var(--palette-color2)",\
  "--text-heading-5--textAlign": "left",\
  "--text-heading-5--justifyContent": "flex-start",\
  "--text-heading-5--marginTop": "auto",\
  "--text-heading-5--marginBottom": "0",\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-6--fontSize--desktop": "36px",\
  "--text-heading-6--fontSize--tablet": "28px",\
  "--text-heading-6--fontSize--mobile": "24px",\
  "--text-heading-6--fontFamily": "var(--font2)",\
  "--text-heading-6--fontWeight": "normal",\
  "--text-heading-6--fontType": "regular",\
  "--text-heading-6--fontStyle": "normal",\
  "--text-heading-6--fontStretch": "normal",\
  "--text-heading-6--lineHeight": "1.2",\
  "--text-heading-6--marginLeft": "0px",\
  "--text-heading-6--color": "var(--palette-color6)",\
  "--text-heading-6--borderBottomStyle": "none",\
  "--text-heading-6--textDecoration": "none",\
  "--text-heading-6--letterSpacing": "0",\
  "--text-heading-6--textTransform": "none",\
  "--text-heading-6--stroke": "var(--palette-color2)",\
  "--text-heading-6--textAlign": "left",\
  "--text-heading-6--justifyContent": "flex-start",\
  "--text-heading-6--marginTop": "auto",\
  "--text-heading-6--marginBottom": "0",\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-7--fontSize--desktop": "20px",\
  "--text-heading-7--fontSize--tablet": "20px",\
  "--text-heading-7--fontSize--mobile": "20px",\
  "--text-heading-7--fontFamily": "var(--font1)",\
  "--text-heading-7--fontWeight": "normal",\
  "--text-heading-7--fontType": "regular",\
  "--text-heading-7--fontStyle": "normal",\
  "--text-heading-7--fontStretch": "normal",\
  "--text-heading-7--lineHeight": "1.35",\
  "--text-heading-7--marginLeft": "0px",\
  "--text-heading-7--color": "var(--palette-color5)",\
  "--text-heading-7--borderBottomStyle": "none",\
  "--text-heading-7--textDecoration": "none",\
  "--text-heading-7--letterSpacing": "0",\
  "--text-heading-7--textTransform": "none",\
  "--text-heading-7--stroke": "var(--palette-color2)",\
  "--text-heading-7--textAlign": "left",\
  "--text-heading-7--justifyContent": "flex-start",\
  "--text-heading-7--marginTop": "auto",\
  "--text-heading-7--marginBottom": "0",\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-8--fontSize--desktop": "72px",\
  "--text-heading-8--fontSize--tablet": "48px",\
  "--text-heading-8--fontSize--mobile": "32px",\
  "--text-heading-8--fontFamily": "var(--font1)",\
  "--text-heading-8--fontWeight": "normal",\
  "--text-heading-8--fontType": "regular",\
  "--text-heading-8--fontStyle": "normal",\
  "--text-heading-8--fontStretch": "normal",\
  "--text-heading-8--lineHeight": "1.35",\
  "--text-heading-8--marginLeft": "0px",\
  "--text-heading-8--color": "var(--palette-color5)",\
  "--text-heading-8--borderBottomStyle": "none",\
  "--text-heading-8--textDecoration": "none",\
  "--text-heading-8--letterSpacing": "0",\
  "--text-heading-8--textTransform": "none",\
  "--text-heading-8--stroke": "var(--palette-color2)",\
  "--text-heading-8--textAlign": "center",\
  "--text-heading-8--justifyContent": "flex-start",\
  "--text-heading-8--marginTop": "auto",\
  "--text-heading-8--marginBottom": "0",\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-9--fontSize--desktop": "32px",\
  "--text-heading-9--fontSize--tablet": "32px",\
  "--text-heading-9--fontSize--mobile": "32px",\
  "--text-heading-9--fontFamily": "var(--font1)",\
  "--text-heading-9--fontWeight": "normal",\
  "--text-heading-9--fontType": "regular",\
  "--text-heading-9--fontStyle": "normal",\
  "--text-heading-9--fontStretch": "normal",\
  "--text-heading-9--lineHeight": "1.35",\
  "--text-heading-9--marginLeft": "0px",\
  "--text-heading-9--color": "var(--palette-color5)",\
  "--text-heading-9--borderBottomStyle": "none",\
  "--text-heading-9--textDecoration": "none",\
  "--text-heading-9--letterSpacing": "0",\
  "--text-heading-9--textTransform": "none",\
  "--text-heading-9--stroke": "var(--palette-color2)",\
  "--text-heading-9--textAlign": "center",\
  "--text-heading-9--justifyContent": "flex-start",\
  "--text-heading-9--marginTop": "auto",\
  "--text-heading-9--marginBottom": "0",\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\
\
  "--text-body-1--fontSize--desktop": "22px",\
  "--text-body-1--fontSize--tablet": "20px",\
  "--text-body-1--fontSize--mobile": "18px",\
  "--text-body-1--fontFamily": "var(--font1)",\
  "--text-body-1--fontWeight": "normal",\
  "--text-body-1--fontType": "regular",\
  "--text-body-1--fontStyle": "normal",\
  "--text-body-1--fontStretch": "normal",\
  "--text-body-1--lineHeight": "1.3",\
  "--text-body-1--marginLeft": "0px",\
  "--text-body-1--color": "var(--palette-color5)",\
  "--text-body-1--borderBottomStyle": "none",\
  "--text-body-1--textDecoration": "none",\
  "--text-body-1--letterSpacing": "0",\
  "--text-body-1--textTransform": "none",\
  "--text-body-1--stroke": "var(--palette-color2)",\
  "--text-body-1--textAlign": "left",\
  "--text-body-1--justifyContent": "flex-start",\
  "--text-body-1--marginTop": "auto",\
  "--text-body-1--marginBottom": "0",\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-1--textShadow": "var(--text-style-unset)",\
\
  "--text-body-2--fontSize--desktop": "22px",\
  "--text-body-2--fontSize--tablet": "20px",\
  "--text-body-2--fontSize--mobile": "18px",\
  "--text-body-2--fontFamily": "var(--font2)",\
  "--text-body-2--fontWeight": "normal",\
  "--text-body-2--fontType": "regular",\
  "--text-body-2--fontStyle": "normal",\
  "--text-body-2--fontStretch": "normal",\
  "--text-body-2--lineHeight": "1.3",\
  "--text-body-2--marginLeft": "0px",\
  "--text-body-2--color": "var(--palette-color4)",\
  "--text-body-2--borderBottomStyle": "none",\
  "--text-body-2--textDecoration": "none",\
  "--text-body-2--letterSpacing": "0.03",\
  "--text-body-2--textTransform": "none",\
  "--text-body-2--Stroke": "var(--palette-color2)",\
  "--text-body-2--textAlign": "left",\
  "--text-body-2--justifyContent": "flex-start",\
  "--text-body-2--marginTop": "auto",\
  "--text-body-2--marginBottom": "0",\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-2--textShadow": "var(--text-style-unset)",\
\
  "--text-body-3--fontSize--desktop": "18px",\
  "--text-body-3--fontSize--tablet": "16px",\
  "--text-body-3--fontSize--mobile": "16px",\
  "--text-body-3--fontFamily": "var(--font1)",\
  "--text-body-3--fontWeight": "normal",\
  "--text-body-3--fontType": "regular",\
  "--text-body-3--fontStyle": "normal",\
  "--text-body-3--fontStretch": "normal",\
  "--text-body-3--lineHeight": "1.35",\
  "--text-body-3--marginLeft": "0px",\
  "--text-body-3--color": "var(--palette-color4)",\
  "--text-body-3--borderBottomStyle": "none",\
  "--text-body-3--textDecoration": "none",\
  "--text-body-3--letterSpacing": "0",\
  "--text-body-3--textTransform": "none",\
  "--text-body-3--Stroke": "var(--palette-color2)",\
  "--text-body-3--textAlign": "left",\
  "--text-body-3--justifyContent": "flex-start",\
  "--text-body-3--marginTop": "auto",\
  "--text-body-3--marginBottom": "0",\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-3--textShadow": "var(--text-style-unset)",\
\
  "--text-body-4--fontSize--desktop": "18px",\
  "--text-body-4--fontSize--tablet": "16px",\
  "--text-body-4--fontSize--mobile": "16px",\
  "--text-body-4--fontFamily": "var(--font2)",\
  "--text-body-4--fontWeight": "normal",\
  "--text-body-4--fontType": "regular",\
  "--text-body-4--fontStyle": "normal",\
  "--text-body-4--fontStretch": "normal",\
  "--text-body-4--lineHeight": "1.35",\
  "--text-body-4--marginLeft": "0px",\
  "--text-body-4--color": "var(--palette-color4)",\
  "--text-body-4--borderBottomStyle": "none",\
  "--text-body-4--textDecoration": "none",\
  "--text-body-4--letterSpacing": "0",\
  "--text-body-4--textTransform": "none",\
  "--text-body-4--Stroke": "var(--palette-color2)",\
  "--text-body-4--textAlign": "left",\
  "--text-body-4--justifyContent": "flex-start",\
  "--text-body-4--marginTop": "auto",\
  "--text-body-4--marginBottom": "0",\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-4--textShadow": "var(--text-style-unset)",\
\
  "--text-body-5--fontSize--desktop": "18px",\
  "--text-body-5--fontSize--tablet": "16px",\
  "--text-body-5--fontSize--mobile": "16px",\
  "--text-body-5--fontFamily": "var(--font1)",\
  "--text-body-5--fontWeight": "normal",\
  "--text-body-5--fontType": "italic",\
  "--text-body-5--fontStyle": "normal",\
  "--text-body-5--fontStretch": "normal",\
  "--text-body-5--lineHeight": "1.35",\
  "--text-body-5--marginLeft": "0px",\
  "--text-body-5--color": "var(--palette-color4)",\
  "--text-body-5--borderBottomStyle": "none",\
  "--text-body-5--textDecoration": "none",\
  "--text-body-5--letterSpacing": "0",\
  "--text-body-5--textTransform": "none",\
  "--text-body-5--Stroke": "var(--palette-color2)",\
  "--text-body-5--textAlign": "center",\
  "--text-body-5--justifyContent": "flex-start",\
  "--text-body-5--marginTop": "auto",\
  "--text-body-5--marginBottom": "0",\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-5--textShadow": "var(--text-style-unset)",\
\
  "--text-body-6--fontSize--desktop": "16px",\
  "--text-body-6--fontSize--tablet": "14px",\
  "--text-body-6--fontSize--mobile": "14px",\
  "--text-body-6--fontFamily": "var(--font2)",\
  "--text-body-6--fontWeight": "normal",\
  "--text-body-6--fontType": "regular",\
  "--text-body-6--fontStyle": "normal",\
  "--text-body-6--fontStretch": "normal",\
  "--text-body-6--lineHeight": "1.35",\
  "--text-body-6--marginLeft": "0px",\
  "--text-body-6--color": "var(--palette-color4)",\
  "--text-body-6--borderBottomStyle": "none",\
  "--text-body-6--textDecoration": "none",\
  "--text-body-6--letterSpacing": "0",\
  "--text-body-6--textTransform": "none",\
  "--text-body-6--Stroke": "var(--palette-color2)",\
  "--text-body-6--textAlign": "left",\
  "--text-body-6--justifyContent": "flex-start",\
  "--text-body-6--marginTop": "auto",\
  "--text-body-6--marginBottom": "0",\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-6--textShadow": "var(--text-style-unset)",\
\
  "--text-component-1--fontSize--desktop": "22px",\
  "--text-component-1--fontSize--tablet": "20px",\
  "--text-component-1--fontSize--mobile": "20px",\
  "--text-component-1--fontFamily": "var(--font1)",\
  "--text-component-1--fontWeight": "normal",\
  "--text-component-1--fontType": "regular",\
  "--text-component-1--fontStyle": "normal",\
  "--text-component-1--fontStretch": "normal",\
  "--text-component-1--lineHeight": "1.35",\
  "--text-component-1--marginLeft": "0px",\
  "--text-component-1--color": "var(--color6)",\
  "--text-component-1--borderBottomStyle": "none",\
  "--text-component-1--textDecoration": "none",\
  "--text-component-1--letterSpacing": "0",\
  "--text-component-1--textTransform": "none",\
  "--text-component-1--stroke": "var(--palette-color2)",\
  "--text-component-1--textAlign": "left",\
  "--text-component-1--justifyContent": "flex-start",\
  "--text-component-1--marginTop": "auto",\
  "--text-component-1--marginBottom": "0",\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-1--textShadow": "var(--text-style-unset)",\
\
  "--text-component-2--fontSize--desktop": "24px",\
  "--text-component-2--fontSize--tablet": "20px",\
  "--text-component-2--fontSize--mobile": "20px",\
  "--text-component-2--fontFamily": "var(--font1)",\
  "--text-component-2--fontWeight": "normal",\
  "--text-component-2--fontType": "regular",\
  "--text-component-2--fontStyle": "normal",\
  "--text-component-2--fontStretch": "normal",\
  "--text-component-2--lineHeight": "1.35",\
  "--text-component-2--marginLeft": "0px",\
  "--text-component-2--color": "var(--palette-color1)",\
  "--text-component-2--borderBottomStyle": "none",\
  "--text-component-2--textDecoration": "none",\
  "--text-component-2--letterSpacing": "0.16",\
  "--text-component-2--textTransform": "none",\
  "--text-component-2--stroke": "var(--palette-color2)",\
  "--text-component-2--textAlign": "left",\
  "--text-component-2--justifyContent": "flex-start",\
  "--text-component-2--marginTop": "auto",\
  "--text-component-2--marginBottom": "0",\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-2--textShadow": "var(--text-style-unset)",\
\
  "--text-component-3--fontSize--desktop": "14px",\
  "--text-component-3--fontSize--tablet": "14px",\
  "--text-component-3--fontSize--mobile": "14px",\
  "--text-component-3--fontFamily": "var(--font1)",\
  "--text-component-3--fontWeight": "normal",\
  "--text-component-3--fontType": "regular",\
  "--text-component-3--fontStyle": "normal",\
  "--text-component-3--fontStretch": "normal",\
  "--text-component-3--lineHeight": "1.35",\
  "--text-component-3--marginLeft": "0px",\
  "--text-component-3--color": "var(--palette-color6)",\
  "--text-component-3--borderBottomStyle": "none",\
  "--text-component-3--textDecoration": "none",\
  "--text-component-3--letterSpacing": "0.2",\
  "--text-component-3--textTransform": "uppercase",\
  "--text-component-3--stroke": "var(--palette-color2)",\
  "--text-component-3--textAlign": "center",\
  "--text-component-3--justifyContent": "flex-start",\
  "--text-component-3--marginTop": "auto",\
  "--text-component-3--marginBottom": "0",\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-3--textShadow": "var(--text-style-unset)",\
\
  "--text-component-4--fontSize--desktop": "22px",\
  "--text-component-4--fontSize--tablet": "20px",\
  "--text-component-4--fontSize--mobile": "20px",\
  "--text-component-4--fontFamily": "var(--font1)",\
  "--text-component-4--fontWeight": "normal",\
  "--text-component-4--fontType": "regular",\
  "--text-component-4--fontStyle": "normal",\
  "--text-component-4--fontStretch": "normal",\
  "--text-component-4--lineHeight": "1.35",\
  "--text-component-4--marginLeft": "0px",\
  "--text-component-4--color": "var(--color6)",\
  "--text-component-4--borderBottomStyle": "none",\
  "--text-component-4--textDecoration": "none",\
  "--text-component-4--letterSpacing": "0.02",\
  "--text-component-4--textTransform": "none",\
  "--text-component-4--stroke": "var(--palette-color2)",\
  "--text-component-4--textAlign": "left",\
  "--text-component-4--justifyContent": "flex-start",\
  "--text-component-4--marginTop": "auto",\
  "--text-component-4--marginBottom": "0",\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-1--fontSize--desktop": "36px",\
  "--text-subheading-1--fontSize--tablet": "32px",\
  "--text-subheading-1--fontSize--mobile": "28px",\
  "--text-subheading-1--fontFamily": "var(--font2)",\
  "--text-subheading-1--fontWeight": "normal",\
  "--text-subheading-1--fontType": "regular",\
  "--text-subheading-1--fontStyle": "normal",\
  "--text-subheading-1--fontStretch": "normal",\
  "--text-subheading-1--lineHeight": "1.1",\
  "--text-subheading-1--marginLeft": "0px",\
  "--text-subheading-1--color": "var(--palette-color6)",\
  "--text-subheading-1--borderBottomStyle": "none",\
  "--text-subheading-1--textDecoration": "none",\
  "--text-subheading-1--letterSpacing": "0.05",\
  "--text-subheading-1--textTransform": "uppercase",\
  "--text-subheading-1--stroke": "var(--palette-color2)",\
  "--text-subheading-1--textAlign": "left",\
  "--text-subheading-1--justifyContent": "flex-start",\
  "--text-subheading-1--marginTop": "auto",\
  "--text-subheading-1--marginBottom": "0",\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-2--fontSize--desktop": "28px",\
  "--text-subheading-2--fontSize--tablet": "24px",\
  "--text-subheading-2--fontSize--mobile": "20px",\
  "--text-subheading-2--fontFamily": "var(--font2)",\
  "--text-subheading-2--fontWeight": "normal",\
  "--text-subheading-2--fontType": "bold",\
  "--text-subheading-2--fontStyle": "normal",\
  "--text-subheading-2--fontStretch": "normal",\
  "--text-subheading-2--lineHeight": "1.15",\
  "--text-subheading-2--marginLeft": "0px",\
  "--text-subheading-2--color": "var(--palette-color6)",\
  "--text-subheading-2--borderBottomStyle": "none",\
  "--text-subheading-2--textDecoration": "none",\
  "--text-subheading-2--letterSpacing": "0.05",\
  "--text-subheading-2--textTransform": "none",\
  "--text-subheading-2--stroke": "var(--palette-color2)",\
  "--text-subheading-2--textAlign": "left",\
  "--text-subheading-2--justifyContent": "flex-start",\
  "--text-subheading-2--marginTop": "auto",\
  "--text-subheading-2--marginBottom": "0",\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-3--fontSize--desktop": "26px",\
  "--text-subheading-3--fontSize--tablet": "22px",\
  "--text-subheading-3--fontSize--mobile": "18px",\
  "--text-subheading-3--fontFamily": "var(--font2)",\
  "--text-subheading-3--fontWeight": "normal",\
  "--text-subheading-3--fontType": "regular",\
  "--text-subheading-3--fontStyle": "normal",\
  "--text-subheading-3--fontStretch": "normal",\
  "--text-subheading-3--lineHeight": "1.15",\
  "--text-subheading-3--marginLeft": "0px",\
  "--text-subheading-3--color": "var(--palette-color6)",\
  "--text-subheading-3--borderBottomStyle": "none",\
  "--text-subheading-3--textDecoration": "none",\
  "--text-subheading-3--letterSpacing": "0",\
  "--text-subheading-3--textTransform": "none",\
  "--text-subheading-3--stroke": "var(--palette-color2)",\
  "--text-subheading-3--textAlign": "center",\
  "--text-subheading-3--justifyContent": "flex-start",\
  "--text-subheading-3--marginTop": "auto",\
  "--text-subheading-3--marginBottom": "0",\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-4--fontSize--desktop": "24px",\
  "--text-subheading-4--fontSize--tablet": "20px",\
  "--text-subheading-4--fontSize--mobile": "16px",\
  "--text-subheading-4--fontFamily": "var(--font2)",\
  "--text-subheading-4--fontWeight": "normal",\
  "--text-subheading-4--fontType": "bold",\
  "--text-subheading-4--fontStyle": "normal",\
  "--text-subheading-4--fontStretch": "normal",\
  "--text-subheading-4--lineHeight": "1.15",\
  "--text-subheading-4--marginLeft": "0px",\
  "--text-subheading-4--color": "var(--palette-color0)",\
  "--text-subheading-4--borderBottomStyle": "none",\
  "--text-subheading-4--textDecoration": "none",\
  "--text-subheading-4--letterSpacing": "0.05",\
  "--text-subheading-4--textTransform": "none",\
  "--text-subheading-4--stroke": "var(--palette-color2)",\
  "--text-subheading-4--textAlign": "left",\
  "--text-subheading-4--justifyContent": "flex-start",\
  "--text-subheading-4--marginTop": "auto",\
  "--text-subheading-4--marginBottom": "0",\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-5--fontSize--desktop": "24px",\
  "--text-subheading-5--fontSize--tablet": "20px",\
  "--text-subheading-5--fontSize--mobile": "16px",\
  "--text-subheading-5--fontFamily": "var(--font1)",\
  "--text-subheading-5--fontWeight": "normal",\
  "--text-subheading-5--fontType": "bold",\
  "--text-subheading-5--fontStyle": "normal",\
  "--text-subheading-5--fontStretch": "normal",\
  "--text-subheading-5--lineHeight": "1.15",\
  "--text-subheading-5--marginLeft": "0px",\
  "--text-subheading-5--color": "var(--palette-color5)",\
  "--text-subheading-5--borderBottomStyle": "none",\
  "--text-subheading-5--textDecoration": "none",\
  "--text-subheading-5--letterSpacing": "-0.05",\
  "--text-subheading-5--textTransform": "none",\
  "--text-subheading-5--stroke": "var(--palette-color2)",\
  "--text-subheading-5--textAlign": "left",\
  "--text-subheading-5--justifyContent": "flex-start",\
  "--text-subheading-5--marginTop": "auto",\
  "--text-subheading-5--marginBottom": "0",\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-6--fontSize--desktop": "18px",\
  "--text-subheading-6--fontSize--tablet": "16px",\
  "--text-subheading-6--fontSize--mobile": "14px",\
  "--text-subheading-6--fontFamily": "var(--font2)",\
  "--text-subheading-6--fontWeight": "normal",\
  "--text-subheading-6--fontType": "bold",\
  "--text-subheading-6--fontStyle": "normal",\
  "--text-subheading-6--fontStretch": "normal",\
  "--text-subheading-6--lineHeight": "1.25",\
  "--text-subheading-6--marginLeft": "0px",\
  "--text-subheading-6--color": "var(--palette-color5)",\
  "--text-subheading-6--borderBottomStyle": "none",\
  "--text-subheading-6--textDecoration": "none",\
  "--text-subheading-6--letterSpacing": "0",\
  "--text-subheading-6--textTransform": "none",\
  "--text-subheading-6--stroke": "var(--palette-color2)",\
  "--text-subheading-6--textAlign": "left",\
  "--text-subheading-6--justifyContent": "flex-start",\
  "--text-subheading-6--marginTop": "auto",\
  "--text-subheading-6--marginBottom": "0",\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-1--fontSize--desktop": "20px",\
  "--text-detail-1--fontSize--tablet": "18px",\
  "--text-detail-1--fontSize--mobile": "16px",\
  "--text-detail-1--fontFamily": "var(--font2)",\
  "--text-detail-1--fontWeight": "normal",\
  "--text-detail-1--fontType": "regular",\
  "--text-detail-1--fontStyle": "normal",\
  "--text-detail-1--fontStretch": "normal",\
  "--text-detail-1--lineHeight": "1.2",\
  "--text-detail-1--marginLeft": "0px",\
  "--text-detail-1--color": "var(--palette-color6)",\
  "--text-detail-1--borderBottomStyle": "none",\
  "--text-detail-1--textDecoration": "none",\
  "--text-detail-1--letterSpacing": "0",\
  "--text-detail-1--textTransform": "uppercase",\
  "--text-detail-1--stroke": "var(--palette-color5)",\
  "--text-detail-1--textAlign": "left",\
  "--text-detail-1--justifyContent": "flex-start",\
  "--text-detail-1--marginTop": "auto",\
  "--text-detail-1--marginBottom": "0",\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-2--fontSize--desktop": "16px",\
  "--text-detail-2--fontSize--tablet": "14px",\
  "--text-detail-2--fontSize--mobile": "12px",\
  "--text-detail-2--fontFamily": "var(--font2)",\
  "--text-detail-2--fontWeight": "normal",\
  "--text-detail-2--fontType": "bold",\
  "--text-detail-2--fontStyle": "normal",\
  "--text-detail-2--fontStretch": "normal",\
  "--text-detail-2--lineHeight": "1.3",\
  "--text-detail-2--marginLeft": "0px",\
  "--text-detail-2--color": "var(--palette-color6)",\
  "--text-detail-2--borderBottomStyle": "none",\
  "--text-detail-2--textDecoration": "none",\
  "--text-detail-2--letterSpacing": "0",\
  "--text-detail-2--textTransform": "uppercase",\
  "--text-detail-2--stroke": "var(--palette-color2)",\
  "--text-detail-2--textAlign": "left",\
  "--text-detail-2--justifyContent": "flex-start",\
  "--text-detail-2--marginTop": "auto",\
  "--text-detail-2--marginBottom": "0",\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-3--fontSize--desktop": "16px",\
  "--text-detail-3--fontSize--tablet": "14px",\
  "--text-detail-3--fontSize--mobile": "12px",\
  "--text-detail-3--fontFamily": "var(--font2)",\
  "--text-detail-3--fontWeight": "normal",\
  "--text-detail-3--fontType": "regular",\
  "--text-detail-3--fontStyle": "normal",\
  "--text-detail-3--fontStretch": "normal",\
  "--text-detail-3--lineHeight": "1.35",\
  "--text-detail-3--marginLeft": "0px",\
  "--text-detail-3--color": "var(--palette-color4)",\
  "--text-detail-3--borderBottomStyle": "none",\
  "--text-detail-3--textDecoration": "none",\
  "--text-detail-3--letterSpacing": "0.2",\
  "--text-detail-3--textTransform": "uppercase",\
  "--text-detail-3--stroke": "var(--palette-color2)",\
  "--text-detail-3--textAlign": "left",\
  "--text-detail-3--justifyContent": "flex-start",\
  "--text-detail-3--marginTop": "auto",\
  "--text-detail-3--marginBottom": "0",\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-4--fontSize--desktop": "22px",\
  "--text-detail-4--fontSize--tablet": "20px",\
  "--text-detail-4--fontSize--mobile": "20px",\
  "--text-detail-4--fontFamily": "var(--font1)",\
  "--text-detail-4--fontWeight": "normal",\
  "--text-detail-4--fontType": "regular",\
  "--text-detail-4--fontStyle": "normal",\
  "--text-detail-4--fontStretch": "normal",\
  "--text-detail-4--lineHeight": "1.35",\
  "--text-detail-4--marginLeft": "0px",\
  "--text-detail-4--color": "var(--palette-color5)",\
  "--text-detail-4--borderBottomStyle": "none",\
  "--text-detail-4--textDecoration": "none",\
  "--text-detail-4--letterSpacing": "0",\
  "--text-detail-4--textTransform": "none",\
  "--text-detail-4--stroke": "var(--palette-color2)",\
  "--text-detail-4--textAlign": "center",\
  "--text-detail-4--justifyContent": "flex-start",\
  "--text-detail-4--marginTop": "auto",\
  "--text-detail-4--marginBottom": "0",\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-1--fontSize--desktop": "36px",\
  "--text-variable-1--fontSize--tablet": "32px",\
  "--text-variable-1--fontSize--mobile": "30px",\
  "--text-variable-1--fontFamily": "var(--font2)",\
  "--text-variable-1--fontWeight": "normal",\
  "--text-variable-1--fontType": "bold",\
  "--text-variable-1--fontStyle": "normal",\
  "--text-variable-1--fontStretch": "normal",\
  "--text-variable-1--lineHeight": "1.2",\
  "--text-variable-1--marginLeft": "0px",\
  "--text-variable-1--color": "var(--palette-color7)",\
  "--text-variable-1--borderBottomStyle": "none",\
  "--text-variable-1--textDecoration": "none",\
  "--text-variable-1--letterSpacing": "0.02",\
  "--text-variable-1--textTransform": "none",\
  "--text-variable-1--stroke": "var(--palette-color2)",\
  "--text-variable-1--textAlign": "left",\
  "--text-variable-1--justifyContent": "flex-start",\
  "--text-variable-1--marginTop": "auto",\
  "--text-variable-1--marginBottom": "0",\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-2--fontSize--desktop": "24px",\
  "--text-variable-2--fontSize--tablet": "22px",\
  "--text-variable-2--fontSize--mobile": "20px",\
  "--text-variable-2--fontFamily": "var(--font2)",\
  "--text-variable-2--fontWeight": "normal",\
  "--text-variable-2--fontType": "bold",\
  "--text-variable-2--fontStyle": "normal",\
  "--text-variable-2--fontStretch": "normal",\
  "--text-variable-2--lineHeight": "1.15",\
  "--text-variable-2--marginLeft": "0px",\
  "--text-variable-2--color": "var(--palette-color6)",\
  "--text-variable-2--borderBottomStyle": "none",\
  "--text-variable-2--textDecoration": "none",\
  "--text-variable-2--letterSpacing": "0",\
  "--text-variable-2--textTransform": "none",\
  "--text-variable-2--stroke": "var(--palette-color2)",\
  "--text-variable-2--textAlign": "left",\
  "--text-variable-2--justifyContent": "flex-start",\
  "--text-variable-2--marginTop": "auto",\
  "--text-variable-2--marginBottom": "0",\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-3--fontSize--desktop": "20px",\
  "--text-variable-3--fontSize--tablet": "18px",\
  "--text-variable-3--fontSize--mobile": "16px",\
  "--text-variable-3--fontFamily": "var(--font1)",\
  "--text-variable-3--fontWeight": "normal",\
  "--text-variable-3--fontType": "bold",\
  "--text-variable-3--fontStyle": "normal",\
  "--text-variable-3--fontStretch": "normal",\
  "--text-variable-3--lineHeight": "1.2",\
  "--text-variable-3--marginLeft": "0px",\
  "--text-variable-3--color": "var(--palette-color6)",\
  "--text-variable-3--borderBottomStyle": "none",\
  "--text-variable-3--textDecoration": "none",\
  "--text-variable-3--letterSpacing": "0",\
  "--text-variable-3--textTransform": "none",\
  "--text-variable-3--stroke": "var(--palette-color2)",\
  "--text-variable-3--textAlign": "left",\
  "--text-variable-3--justifyContent": "flex-start",\
  "--text-variable-3--marginTop": "auto",\
  "--text-variable-3--marginBottom": "0",\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-4--fontSize--desktop": "16px",\
  "--text-variable-4--fontSize--tablet": "14px",\
  "--text-variable-4--fontSize--mobile": "12px",\
  "--text-variable-4--fontFamily": "var(--font2)",\
  "--text-variable-4--fontWeight": "normal",\
  "--text-variable-4--fontType": "bold",\
  "--text-variable-4--fontStyle": "normal",\
  "--text-variable-4--fontStretch": "normal",\
  "--text-variable-4--lineHeight": "1.3",\
  "--text-variable-4--marginLeft": "0px",\
  "--text-variable-4--color": "var(--palette-color6)",\
  "--text-variable-4--borderBottomStyle": "none",\
  "--text-variable-4--textDecoration": "none",\
  "--text-variable-4--letterSpacing": "0.02",\
  "--text-variable-4--textTransform": "none",\
  "--text-variable-4--stroke": "var(--palette-color2)",\
  "--text-variable-4--textAlign": "left",\
  "--text-variable-4--justifyContent": "flex-start",\
  "--text-variable-4--marginTop": "auto",\
  "--text-variable-4--marginBottom": "0",\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\
\
  "--text-question-1--fontSize--desktop": "48px",\
  "--text-question-1--fontSize--tablet": "20px",\
  "--text-question-1--fontSize--mobile": "20px",\
  "--text-question-1--fontFamily": "var(--font1)",\
  "--text-question-1--fontWeight": "normal",\
  "--text-question-1--fontType": "regular",\
  "--text-question-1--fontStyle": "normal",\
  "--text-question-1--fontStretch": "normal",\
  "--text-question-1--lineHeight": "1.35",\
  "--text-question-1--marginLeft": "0px",\
  "--text-question-1--color": "var(--palette-color5)",\
  "--text-question-1--borderBottomStyle": "none",\
  "--text-question-1--textDecoration": "none",\
  "--text-question-1--letterSpacing": "0",\
  "--text-question-1--textTransform": "none",\
  "--text-question-1--stroke": "var(--palette-color2)",\
  "--text-question-1--textAlign": "left",\
  "--text-question-1--justifyContent": "flex-start",\
  "--text-question-1--marginTop": "auto",\
  "--text-question-1--marginBottom": "0",\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-1--textShadow": "var(--text-style-unset)",\
\
  "--text-question-2--fontSize--desktop": "24px",\
  "--text-question-2--fontSize--tablet": "20px",\
  "--text-question-2--fontSize--mobile": "20px",\
  "--text-question-2--fontFamily": "var(--font1)",\
  "--text-question-2--fontWeight": "normal",\
  "--text-question-2--fontType": "bold",\
  "--text-question-2--fontStyle": "normal",\
  "--text-question-2--fontStretch": "normal",\
  "--text-question-2--lineHeight": "1.35",\
  "--text-question-2--marginLeft": "0px",\
  "--text-question-2--color": "var(--palette-color5)",\
  "--text-question-2--borderBottomStyle": "none",\
  "--text-question-2--textDecoration": "none",\
  "--text-question-2--letterSpacing": "0",\
  "--text-question-2--textTransform": "none",\
  "--text-question-2--stroke": "var(--palette-color2)",\
  "--text-question-2--textAlign": "left",\
  "--text-question-2--justifyContent": "flex-start",\
  "--text-question-2--marginTop": "auto",\
  "--text-question-2--marginBottom": "0",\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-1--fontSize--desktop": "16px",\
  "--text-button-1--fontSize--tablet": "16px",\
  "--text-button-1--fontSize--mobile": "16px",\
  "--text-button-1--fontFamily": "var(--font2)",\
  "--text-button-1--fontWeight": "normal",\
  "--text-button-1--fontType": "regular",\
  "--text-button-1--fontStyle": "normal",\
  "--text-button-1--fontStretch": "normal",\
  "--text-button-1--lineHeight": "1.25",\
  "--text-button-1--marginLeft": "0px",\
  "--text-button-1--color": "var(--palette-color7)",\
  "--text-button-1--borderBottomStyle": "none",\
  "--text-button-1--textDecoration": "none",\
  "--text-button-1--letterSpacing": "0.12",\
  "--text-button-1--textTransform": "uppercase",\
  "--text-button-1--stroke": "var(--palette-color2)",\
  "--text-button-1--textAlign": "center",\
  "--text-button-1--justifyContent": "flex-start",\
  "--text-button-1--marginTop": "auto",\
  "--text-button-1--marginBottom": "0",\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-1--textShadow": "var(--text-style-unset)",\
\
  "--text-button-2--fontSize--desktop": "16px",\
  "--text-button-2--fontSize--tablet": "16px",\
  "--text-button-2--fontSize--mobile": "16px",\
  "--text-button-2--fontFamily": "var(--font2)",\
  "--text-button-2--fontWeight": "normal",\
  "--text-button-2--fontType": "regular",\
  "--text-button-2--fontStyle": "normal",\
  "--text-button-2--fontStretch": "normal",\
  "--text-button-2--lineHeight": "1.25",\
  "--text-button-2--marginLeft": "0px",\
  "--text-button-2--color": "var(--palette-color0)",\
  "--text-button-2--borderBottomStyle": "none",\
  "--text-button-2--textDecoration": "none",\
  "--text-button-2--letterSpacing": "0.12",\
  "--text-button-2--textTransform": "uppercase",\
  "--text-button-2--stroke": "var(--palette-color2)",\
  "--text-button-2--textAlign": "center",\
  "--text-button-2--justifyContent": "flex-start",\
  "--text-button-2--marginTop": "auto",\
  "--text-button-2--marginBottom": "0",\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-3--fontSize--desktop": "16px",\
  "--text-button-3--fontSize--tablet": "16px",\
  "--text-button-3--fontSize--mobile": "16px",\
  "--text-button-3--fontFamily": "var(--font2)",\
  "--text-button-3--fontWeight": "normal",\
  "--text-button-3--fontType": "regular",\
  "--text-button-3--fontStyle": "normal",\
  "--text-button-3--fontStretch": "normal",\
  "--text-button-3--lineHeight": "1.25",\
  "--text-button-3--marginLeft": "0px",\
  "--text-button-3--color": "var(--palette-color5)",\
  "--text-button-3--borderBottomStyle": "none",\
  "--text-button-3--textDecoration": "none",\
  "--text-button-3--letterSpacing": "0.12",\
  "--text-button-3--textTransform": "uppercase",\
  "--text-button-3--stroke": "var(--palette-color2)",\
  "--text-button-3--textAlign": "center",\
  "--text-button-3--justifyContent": "flex-start",\
  "--text-button-3--marginTop": "auto",\
  "--text-button-3--marginBottom": "0",\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-3--textShadow": "var(--text-style-unset)",\
\
  "--text-button-4--fontSize--desktop": "16px",\
  "--text-button-4--fontSize--tablet": "16px",\
  "--text-button-4--fontSize--mobile": "16px",\
  "--text-button-4--fontFamily": "var(--font2)",\
  "--text-button-4--fontWeight": "normal",\
  "--text-button-4--fontType": "regular",\
  "--text-button-4--fontStyle": "normal",\
  "--text-button-4--fontStretch": "normal",\
  "--text-button-4--lineHeight": "1.25",\
  "--text-button-4--marginLeft": "0px",\
  "--text-button-4--color": "var(--palette-color4)",\
  "--text-button-4--borderBottomStyle": "none",\
  "--text-button-4--textDecoration": "none",\
  "--text-button-4--letterSpacing": "0.12",\
  "--text-button-4--textTransform": "uppercase",\
  "--text-button-4--stroke": "var(--palette-color2)",\
  "--text-button-4--textAlign": "center",\
  "--text-button-4--justifyContent": "flex-start",\
  "--text-button-4--marginTop": "auto",\
  "--text-button-4--marginBottom": "0",\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-1--fontSize--desktop": "18px",\
  "--text-uic-1--fontSize--tablet": "18px",\
  "--text-uic-1--fontSize--mobile": "18px",\
  "--text-uic-1--fontFamily": "var(--font1)",\
  "--text-uic-1--fontWeight": "normal",\
  "--text-uic-1--fontType": "italic",\
  "--text-uic-1--fontStyle": "normal",\
  "--text-uic-1--fontStretch": "normal",\
  "--text-uic-1--lineHeight": "1.35",\
  "--text-uic-1--marginLeft": "0px",\
  "--text-uic-1--color": "var(--palette-color4)",\
  "--text-uic-1--borderBottomStyle": "none",\
  "--text-uic-1--textDecoration": "none",\
  "--text-uic-1--letterSpacing": "0",\
  "--text-uic-1--textTransform": "none",\
  "--text-uic-1--stroke": "var(--palette-color2)",\
  "--text-uic-1--textAlign": "left",\
  "--text-uic-1--justifyContent": "flex-start",\
  "--text-uic-1--marginTop": "auto",\
  "--text-uic-1--marginBottom": "0",\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-2--fontSize--desktop": "18px",\
  "--text-uic-2--fontSize--tablet": "18px",\
  "--text-uic-2--fontSize--mobile": "18px",\
  "--text-uic-2--fontFamily": "var(--font1)",\
  "--text-uic-2--fontWeight": "normal",\
  "--text-uic-2--fontType": "italic",\
  "--text-uic-2--fontStyle": "normal",\
  "--text-uic-2--fontStretch": "normal",\
  "--text-uic-2--lineHeight": "1.35",\
  "--text-uic-2--marginLeft": "0px",\
  "--text-uic-2--color": "var(--palette-color1)",\
  "--text-uic-2--borderBottomStyle": "none",\
  "--text-uic-2--textDecoration": "none",\
  "--text-uic-2--letterSpacing": "0",\
  "--text-uic-2--textTransform": "none",\
  "--text-uic-2--stroke": "var(--palette-color2)",\
  "--text-uic-2--textAlign": "left",\
  "--text-uic-2--justifyContent": "flex-start",\
  "--text-uic-2--marginTop": "auto",\
  "--text-uic-2--marginBottom": "0",\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-3--fontSize--desktop": "22px",\
  "--text-uic-3--fontSize--tablet": "22px",\
  "--text-uic-3--fontSize--mobile": "22px",\
  "--text-uic-3--fontFamily": "var(--font1)",\
  "--text-uic-3--fontWeight": "normal",\
  "--text-uic-3--fontType": "regular",\
  "--text-uic-3--fontStyle": "normal",\
  "--text-uic-3--fontStretch": "normal",\
  "--text-uic-3--lineHeight": "1.25",\
  "--text-uic-3--marginLeft": "0px",\
  "--text-uic-3--color": "var(--palette-color5)",\
  "--text-uic-3--borderBottomStyle": "none",\
  "--text-uic-3--textDecoration": "none",\
  "--text-uic-3--letterSpacing": "0",\
  "--text-uic-3--textTransform": "none",\
  "--text-uic-3--stroke": "var(--palette-color2)",\
  "--text-uic-3--textAlign": "left",\
  "--text-uic-3--justifyContent": "flex-start",\
  "--text-uic-3--marginTop": "auto",\
  "--text-uic-3--marginBottom": "0",\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-4--fontSize--desktop": "22px",\
  "--text-uic-4--fontSize--tablet": "22px",\
  "--text-uic-4--fontSize--mobile": "22px",\
  "--text-uic-4--fontFamily": "var(--font1)",\
  "--text-uic-4--fontWeight": "normal",\
  "--text-uic-4--fontType": "regular",\
  "--text-uic-4--fontStyle": "normal",\
  "--text-uic-4--fontStretch": "normal",\
  "--text-uic-4--lineHeight": "1.25",\
  "--text-uic-4--marginLeft": "0px",\
  "--text-uic-4--color": "var(--palette-color4)",\
  "--text-uic-4--borderBottomStyle": "none",\
  "--text-uic-4--textDecoration": "none",\
  "--text-uic-4--letterSpacing": "0",\
  "--text-uic-4--textTransform": "none",\
  "--text-uic-4--stroke": "var(--palette-color2)",\
  "--text-uic-4--textAlign": "left",\
  "--text-uic-4--justifyContent": "flex-start",\
  "--text-uic-4--marginTop": "auto",\
  "--text-uic-4--marginBottom": "0",\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-5--fontSize--desktop": "22px",\
  "--text-uic-5--fontSize--tablet": "22px",\
  "--text-uic-5--fontSize--mobile": "22px",\
  "--text-uic-5--fontFamily": "var(--font1)",\
  "--text-uic-5--fontWeight": "normal",\
  "--text-uic-5--fontType": "regular",\
  "--text-uic-5--fontStyle": "normal",\
  "--text-uic-5--fontStretch": "normal",\
  "--text-uic-5--lineHeight": "1.25",\
  "--text-uic-5--marginLeft": "0px",\
  "--text-uic-5--color": "var(--palette-color3)",\
  "--text-uic-5--borderBottomStyle": "none",\
  "--text-uic-5--textDecoration": "none",\
  "--text-uic-5--letterSpacing": "0",\
  "--text-uic-5--textTransform": "none",\
  "--text-uic-5--stroke": "var(--palette-color2)",\
  "--text-uic-5--textAlign": "left",\
  "--text-uic-5--justifyContent": "flex-start",\
  "--text-uic-5--marginTop": "auto",\
  "--text-uic-5--marginBottom": "0",\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-6--fontSize--desktop": "16px",\
  "--text-uic-6--fontSize--tablet": "16px",\
  "--text-uic-6--fontSize--mobile": "16px",\
  "--text-uic-6--fontFamily": "var(--font2)",\
  "--text-uic-6--fontWeight": "normal",\
  "--text-uic-6--fontType": "bold",\
  "--text-uic-6--fontStyle": "normal",\
  "--text-uic-6--fontStretch": "normal",\
  "--text-uic-6--lineHeight": "1.5",\
  "--text-uic-6--marginLeft": "0px",\
  "--text-uic-6--color": "var(--palette-color7)",\
  "--text-uic-6--borderBottomStyle": "none",\
  "--text-uic-6--textDecoration": "none",\
  "--text-uic-6--letterSpacing": "0.12",\
  "--text-uic-6--textTransform": "none",\
  "--text-uic-6--stroke": "var(--palette-color2)",\
  "--text-uic-6--textAlign": "left",\
  "--text-uic-6--justifyContent": "flex-start",\
  "--text-uic-6--marginTop": "auto",\
  "--text-uic-6--marginBottom": "0",\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\
\
  "--text-closedcaptions--fontSize--desktop": "24px",\
  "--text-closedcaptions--fontSize--tablet": "24px",\
  "--text-closedcaptions--fontSize--mobile": "24px",\
  "--text-closedcaptions--fontFamily": "var(--font1)",\
  "--text-closedcaptions--fontWeight": "normal",\
  "--text-closedcaptions--fontType": "regular",\
  "--text-closedcaptions--fontStyle": "normal",\
  "--text-closedcaptions--fontStretch": "normal",\
  "--text-closedcaptions--lineHeight": "1.35",\
  "--text-closedcaptions--marginLeft": "0px",\
  "--text-closedcaptions--color": "var(--white)",\
  "--text-closedcaptions--borderBottomStyle": "none",\
  "--text-closedcaptions--textDecoration": "none",\
  "--text-closedcaptions--letterSpacing": "0",\
  "--text-closedcaptions--textTransform": "none",\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\
  "--text-closedcaptions--textAlign": "center",\
  "--text-closedcaptions--justifyContent": "flex-start",\
  "--text-closedcaptions--marginTop": "auto",\
  "--text-closedcaptions--marginBottom": "0",\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\
\
  "--text-caption--fontSize--desktop": "24px",\
  "--text-caption--fontSize--tablet": "24px",\
  "--text-caption--fontSize--mobile": "24px",\
  "--text-caption--fontFamily": "var(--font1)",\
  "--text-caption--fontWeight": "normal",\
  "--text-caption--fontType": "regular",\
  "--text-caption--fontStyle": "normal",\
  "--text-caption--fontStretch": "normal",\
  "--text-caption--lineHeight": "1.35",\
  "--text-caption--marginLeft": "0px",\
  "--text-caption--color": "var(--palette-color6)",\
  "--text-caption--borderBottomStyle": "none",\
  "--text-caption--textDecoration": "none",\
  "--text-caption--letterSpacing": "0",\
  "--text-caption--textTransform": "none",\
  "--text-caption--stroke": "var(--palette-color2)",\
  "--text-caption--textAlign": "center",\
  "--text-caption--justifyContent": "flex-start",\
  "--text-caption--marginTop": "auto",\
  "--text-caption--marginBottom": "0",\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_correct--fontSize--desktop": "24px",\
  "--text-caption_correct--fontSize--tablet": "24px",\
  "--text-caption_correct--fontSize--mobile": "24px",\
  "--text-caption_correct--fontFamily": "var(--font1)",\
  "--text-caption_correct--fontWeight": "normal",\
  "--text-caption_correct--fontType": "regular",\
  "--text-caption_correct--fontStyle": "normal",\
  "--text-caption_correct--fontStretch": "normal",\
  "--text-caption_correct--lineHeight": "1.35",\
  "--text-caption_correct--marginLeft": "0px",\
  "--text-caption_correct--color": "var(--palette-color6)",\
  "--text-caption_correct--borderBottomStyle": "none",\
  "--text-caption_correct--textDecoration": "none",\
  "--text-caption_correct--letterSpacing": "0",\
  "--text-caption_correct--textTransform": "none",\
  "--text-caption_correct--stroke": "var(--palette-color2)",\
  "--text-caption_correct--textAlign": "center",\
  "--text-caption_correct--justifyContent": "flex-start",\
  "--text-caption_correct--marginTop": "auto",\
  "--text-caption_correct--marginBottom": "0",\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incorrect--fontSize--desktop": "24px",\
  "--text-caption_incorrect--fontSize--tablet": "24px",\
  "--text-caption_incorrect--fontSize--mobile": "24px",\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\
  "--text-caption_incorrect--fontWeight": "normal",\
  "--text-caption_incorrect--fontType": "regular",\
  "--text-caption_incorrect--fontStyle": "normal",\
  "--text-caption_incorrect--fontStretch": "normal",\
  "--text-caption_incorrect--lineHeight": "1.35",\
  "--text-caption_incorrect--marginLeft": "0px",\
  "--text-caption_incorrect--color": "var(--palette-color6)",\
  "--text-caption_incorrect--borderBottomStyle": "none",\
  "--text-caption_incorrect--textDecoration": "none",\
  "--text-caption_incorrect--letterSpacing": "0",\
  "--text-caption_incorrect--textTransform": "none",\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\
  "--text-caption_incorrect--textAlign": "center",\
  "--text-caption_incorrect--justifyContent": "flex-start",\
  "--text-caption_incorrect--marginTop": "auto",\
  "--text-caption_incorrect--marginBottom": "0",\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incomplete--fontSize--desktop": "24px",\
  "--text-caption_incomplete--fontSize--tablet": "24px",\
  "--text-caption_incomplete--fontSize--mobile": "24px",\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\
  "--text-caption_incomplete--fontWeight": "normal",\
  "--text-caption_incomplete--fontType": "regular",\
  "--text-caption_incomplete--fontStyle": "normal",\
  "--text-caption_incomplete--fontStretch": "normal",\
  "--text-caption_incomplete--lineHeight": "1.35",\
  "--text-caption_incomplete--marginLeft": "0px",\
  "--text-caption_incomplete--color": "var(--palette-color6)",\
  "--text-caption_incomplete--borderBottomStyle": "none",\
  "--text-caption_incomplete--textDecoration": "none",\
  "--text-caption_incomplete--letterSpacing": "0",\
  "--text-caption_incomplete--textTransform": "none",\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\
  "--text-caption_incomplete--textAlign": "center",\
  "--text-caption_incomplete--justifyContent": "flex-start",\
  "--text-caption_incomplete--marginTop": "auto",\
  "--text-caption_incomplete--marginBottom": "0",\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_hint--fontSize--desktop": "24px",\
  "--text-caption_hint--fontSize--tablet": "24px",\
  "--text-caption_hint--fontSize--mobile": "24px",\
  "--text-caption_hint--fontFamily": "var(--font1)",\
  "--text-caption_hint--fontWeight": "normal",\
  "--text-caption_hint--fontType": "regular",\
  "--text-caption_hint--fontStyle": "normal",\
  "--text-caption_hint--fontStretch": "normal",\
  "--text-caption_hint--lineHeight": "1.35",\
  "--text-caption_hint--marginLeft": "0px",\
  "--text-caption_hint--color": "var(--palette-color6)",\
  "--text-caption_hint--borderBottomStyle": "none",\
  "--text-caption_hint--textDecoration": "none",\
  "--text-caption_hint--letterSpacing": "0",\
  "--text-caption_hint--textTransform": "none",\
  "--text-caption_hint--stroke": "var(--palette-color2)",\
  "--text-caption_hint--textAlign": "center",\
  "--text-caption_hint--justifyContent": "flex-start",\
  "--text-caption_hint--marginTop": "auto",\
  "--text-caption_hint--marginBottom": "0",\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_retry--fontSize--desktop": "24px",\
  "--text-caption_retry--fontSize--tablet": "24px",\
  "--text-caption_retry--fontSize--mobile": "24px",\
  "--text-caption_retry--fontFamily": "var(--font1)",\
  "--text-caption_retry--fontWeight": "normal",\
  "--text-caption_retry--fontType": "regular",\
  "--text-caption_retry--fontStyle": "normal",\
  "--text-caption_retry--fontStretch": "normal",\
  "--text-caption_retry--lineHeight": "1.35",\
  "--text-caption_retry--marginLeft": "0px",\
  "--text-caption_retry--color": "var(--palette-color6)",\
  "--text-caption_retry--borderBottomStyle": "none",\
  "--text-caption_retry--textDecoration": "none",\
  "--text-caption_retry--letterSpacing": "0",\
  "--text-caption_retry--textTransform": "none",\
  "--text-caption_retry--stroke": "var(--palette-color2)",\
  "--text-caption_retry--textAlign": "center",\
  "--text-caption_retry--justifyContent": "flex-start",\
  "--text-caption_retry--marginTop": "auto",\
  "--text-caption_retry--marginBottom": "0",\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_timeout--fontSize--desktop": "24px",\
  "--text-caption_timeout--fontSize--tablet": "24px",\
  "--text-caption_timeout--fontSize--mobile": "24px",\
  "--text-caption_timeout--fontFamily": "var(--font1)",\
  "--text-caption_timeout--fontWeight": "normal",\
  "--text-caption_timeout--fontType": "regular",\
  "--text-caption_timeout--fontStyle": "normal",\
  "--text-caption_timeout--fontStretch": "normal",\
  "--text-caption_timeout--lineHeight": "1.35",\
  "--text-caption_timeout--marginLeft": "0px",\
  "--text-caption_timeout--color": "var(--palette-color6)",\
  "--text-caption_timeout--borderBottomStyle": "none",\
  "--text-caption_timeout--textDecoration": "none",\
  "--text-caption_timeout--letterSpacing": "0",\
  "--text-caption_timeout--textTransform": "none",\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\
  "--text-caption_timeout--textAlign": "center",\
  "--text-caption_timeout--justifyContent": "flex-start",\
  "--text-caption_timeout--marginTop": "auto",\
  "--text-caption_timeout--marginBottom": "0",\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_1--fontSize--desktop": "18px",\
  "--text-caption_1--fontSize--tablet": "18px",\
  "--text-caption_1--fontSize--mobile": "16px",\
  "--text-caption_1--fontFamily": "var(--font2)",\
  "--text-caption_1--fontWeight": "normal",\
  "--text-caption_1--fontType": "regular",\
  "--text-caption_1--fontStyle": "normal",\
  "--text-caption_1--fontStretch": "normal",\
  "--text-caption_1--lineHeight": "1.2",\
  "--text-caption_1--marginLeft": "0px",\
  "--text-caption_1--color": "#FFFFFF",\
  "--text-caption_1--borderBottomStyle": "none",\
  "--text-caption_1--textDecoration": "none",\
  "--text-caption_1--letterSpacing": "0",\
  "--text-caption_1--textTransform": "none",\
  "--text-caption_1--stroke": "#00000000",\
  "--text-caption_1--textAlign": "left",\
  "--text-caption_1--justifyContent": "flex-start",\
  "--text-caption_1--marginTop": "auto",\
  "--text-caption_1--marginBottom": "0",\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_2--fontSize--desktop": "20px",\
  "--text-caption_2--fontSize--tablet": "20px",\
  "--text-caption_2--fontSize--mobile": "18px",\
  "--text-caption_2--fontFamily": "var(--font2)",\
  "--text-caption_2--fontWeight": "normal",\
  "--text-caption_2--fontType": "bold",\
  "--text-caption_2--fontStyle": "normal",\
  "--text-caption_2--fontStretch": "normal",\
  "--text-caption_2--lineHeight": "1.2",\
  "--text-caption_2--marginLeft": "0px",\
  "--text-caption_2--color": "#FFFFFF",\
  "--text-caption_2--borderBottomStyle": "none",\
  "--text-caption_2--textDecoration": "none",\
  "--text-caption_2--letterSpacing": "0",\
  "--text-caption_2--textTransform": "none",\
  "--text-caption_2--stroke": "#00000000",\
  "--text-caption_2--textAlign": "left",\
  "--text-caption_2--justifyContent": "flex-start",\
  "--text-caption_2--marginTop": "auto",\
  "--text-caption_2--marginBottom": "0",\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_3--fontSize--desktop": "24px",\
  "--text-caption_3--fontSize--tablet": "24px",\
  "--text-caption_3--fontSize--mobile": "22px",\
  "--text-caption_3--fontFamily": "var(--font1)",\
  "--text-caption_3--fontWeight": "normal",\
  "--text-caption_3--fontType": "italic",\
  "--text-caption_3--fontStyle": "normal",\
  "--text-caption_3--fontStretch": "normal",\
  "--text-caption_3--lineHeight": "1.2",\
  "--text-caption_3--marginLeft": "0px",\
  "--text-caption_3--color": "#FFFFFF",\
  "--text-caption_3--borderBottomStyle": "none",\
  "--text-caption_3--textDecoration": "none",\
  "--text-caption_3--letterSpacing": "0",\
  "--text-caption_3--textTransform": "none",\
  "--text-caption_3--stroke": "#00000000",\
  "--text-caption_3--textAlign": "left",\
  "--text-caption_3--justifyContent": "flex-start",\
  "--text-caption_3--marginTop": "auto",\
  "--text-caption_3--marginBottom": "0",\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_4--fontSize--desktop": "22px",\
  "--text-caption_4--fontSize--tablet": "22px",\
  "--text-caption_4--fontSize--mobile": "20px",\
  "--text-caption_4--fontFamily": "var(--font2)",\
  "--text-caption_4--fontWeight": "normal",\
  "--text-caption_4--fontType": "italic",\
  "--text-caption_4--fontStyle": "normal",\
  "--text-caption_4--fontStretch": "normal",\
  "--text-caption_4--lineHeight": "1.3",\
  "--text-caption_4--marginLeft": "0px",\
  "--text-caption_4--color": "#666666",\
  "--text-caption_4--borderBottomStyle": "none",\
  "--text-caption_4--textDecoration": "none",\
  "--text-caption_4--letterSpacing": "0",\
  "--text-caption_4--textTransform": "none",\
  "--text-caption_4--stroke": "#00000000",\
  "--text-caption_4--textAlign": "left",\
  "--text-caption_4--justifyContent": "flex-start",\
  "--text-caption_4--marginTop": "auto",\
  "--text-caption_4--marginBottom": "0",\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\
\
  "--text-comment-box--fontSize--desktop": "20px",\
  "--text-comment-box--fontSize--tablet": "20px",\
  "--text-comment-box--fontSize--mobile": "20px",\
  "--text-comment-box--fontFamily": "var(--font1)",\
  "--text-comment-box--fontWeight": "normal",\
  "--text-comment-box--fontType": "regular",\
  "--text-comment-box--fontStyle": "normal",\
  "--text-comment-box--fontStretch": "normal",\
  "--text-comment-box--lineHeight": "1.35",\
  "--text-comment-box--marginLeft": "0px",\
  "--text-comment-box--color": "var(--palette-color6)",\
  "--text-comment-box--borderBottomStyle": "none",\
  "--text-comment-box--textDecoration": "none",\
  "--text-comment-box--letterSpacing": "0",\
  "--text-comment-box--textTransform": "none",\
  "--text-comment-box--stroke": "var(--palette-color2)",\
  "--text-comment-box--textAlign": "center",\
  "--text-comment-box--justifyContent": "flex-start",\
  "--text-comment-box--marginTop": "auto",\
  "--text-comment-box--marginBottom": "0",\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\
\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\
\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_greyscale--intensity": 100,\
\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_lighten--intensity": 80,\
\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_darken--intensity": 80,\
\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_overlay--intensity": 80,\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\
\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_colorize--intensity": 80,\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\
\
\
  "--button-normal--primaryColor": "var(--palette-color7)",\
  "--button-normal--borderColor": "var(--palette-color7)",\
  "--button-normal--shadowColor": "var(--greyscale3)",\
  "--text-button-normal--color": "var(--palette-color0)",\
  "--text-button-normal--fontFamily": "var(--font2)",\
  "--text-button-normal--fontType": "regular",\
  "--text-button-normal--fontSize--desktop": "16px",\
  "--text-button-normal--fontSize--tablet": "16px",\
  "--text-button-normal--fontSize--mobile": "16px",\
\
  "--button-selected--primaryColor": "var(--palette-color5)",\
  "--button-selected--borderColor": "var(--palette-color5)",\
  "--button-selected--shadowColor": "var(--greyscale3)",\
  "--text-button-selected--color": "var(--palette-color0)",\
  "--text-button-selected--fontFamily": "var(--font2)",\
  "--text-button-selected--fontType": "regular",\
  "--text-button-selected--fontSize--desktop": "16px",\
  "--text-button-selected--fontSize--tablet": "16px",\
  "--text-button-selected--fontSize--mobile": "16px",\
\
  "--button-disabled--primaryColor": "var(--palette-color3)",\
  "--button-disabled--borderColor": "var(--palette-color3)",\
  "--button-disabled--shadowColor": "var(--greyscale3)",\
  "--text-button-disabled--color": "var(--palette-color4)",\
  "--text-button-disabled--fontFamily": "var(--font2)",\
  "--text-button-disabled--fontType": "regular",\
  "--text-button-disabled--fontSize--desktop": "16px",\
  "--text-button-disabled--fontSize--tablet": "16px",\
  "--text-button-disabled--fontSize--mobile": "16px",\
\
  "--button-hover--primaryColor": "#112FA7",\
  "--button-hover--borderColor": "#112FA7",\
  "--button-hover--shadowColor": "var(--greyscale3)",\
  "--text-button-hover--color": "var(--palette-color0)",\
  "--text-button-hover--fontFamily": "var(--font2)",\
  "--text-button-hover--fontType": "regular",\
  "--text-button-hover--fontSize--desktop": "16px",\
  "--text-button-hover--fontSize--tablet": "16px",\
  "--text-button-hover--fontSize--mobile": "16px",\
\
  "--button-visited--primaryColor": "#112FA780",\
  "--button-visited--borderColor": "#112FA780",\
  "--button-visited--shadowColor": "var(--greyscale3)",\
  "--text-button-visited--color": "var(--palette-color0)",\
  "--text-button-visited--fontFamily": "var(--font2)",\
  "--text-button-visited--fontType": "regular",\
  "--text-button-visited--fontSize--desktop": "16px",\
  "--text-button-visited--fontSize--tablet": "16px",\
  "--text-button-visited--fontSize--mobile": "16px",\
\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-normal--color": "var(--palette-color4)",\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\
  "--text-checkbox-normal--fontType": "regular",\
  "--text-checkbox-normal--fontSize--desktop": "22px",\
  "--text-checkbox-normal--fontSize--tablet": "20px",\
  "--text-checkbox-normal--fontSize--mobile": "20px",\
\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-selected--color": "var(--palette-color4)",\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\
  "--text-checkbox-selected--fontType": "regular",\
  "--text-checkbox-selected--fontSize--desktop": "22px",\
  "--text-checkbox-selected--fontSize--tablet": "20px",\
  "--text-checkbox-selected--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-checked--fontType": "regular",\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\
\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-hover--color": "var(--palette-color5)",\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\
  "--text-checkbox-hover--fontType": "regular",\
  "--text-checkbox-hover--fontSize--desktop": "22px",\
  "--text-checkbox-hover--fontSize--tablet": "20px",\
  "--text-checkbox-hover--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \
  "--inputfield-normal--borderColor": "var(--palette-color3)",\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-normal--color": "var(--palette-color4)",\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\
  "--text-inputfield-normal--fontType": "regular",\
  "--text-inputfield-normal--fontSize--desktop": "18px",\
  "--text-inputfield-normal--fontSize--tablet": "20px",\
  "--text-inputfield-normal--fontSize--mobile": "20px",\
\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\
  "--inputfield-active--borderColor": "var(--palette-color7)",\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\
  "--text-inputfield-active--color": "var(--palette-color4)",\
  "--text-inputfield-active--fontFamily": "var(--font1)",\
  "--text-inputfield-active--fontType": "regular",\
  "--text-inputfield-active--fontSize--desktop": "18px",\
  "--text-inputfield-active--fontSize--tablet": "20px",\
  "--text-inputfield-active--fontSize--mobile": "20px",\
\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\
  "--text-inputfield-disabled--fontType": "regular",\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\
\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\
  "--text-inputfield-focusLost--fontType": "regular",\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\
\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\
  "--inputfield-error--borderColor": "var(--error)",\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-error--color": "var(--palette-color4)",\
  "--text-inputfield-error--fontFamily": "var(--font1)",\
  "--text-inputfield-error--fontType": "regular",\
  "--text-inputfield-error--fontSize--desktop": "18px",\
  "--text-inputfield-error--fontSize--tablet": "20px",\
  "--text-inputfield-error--fontSize--mobile": "20px",\
\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-normal--color": "var(--palette-color4)",\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\
  "--text-dropdown-normal--fontType": "italic",\
  "--text-dropdown-normal--fontSize--desktop": "18px",\
  "--text-dropdown-normal--fontSize--tablet": "18px",\
  "--text-dropdown-normal--fontSize--mobile": "18px",\
\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-selected--color": "var(--palette-color4)",\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\
  "--text-dropdown-selected--fontType": "italic",\
  "--text-dropdown-selected--fontSize--desktop": "18px",\
  "--text-dropdown-selected--fontSize--tablet": "18px",\
  "--text-dropdown-selected--fontSize--mobile": "18px",\
\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\
  "--text-dropdown-disabled--fontType": "italic",\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\
\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-hover--color": "var(--palette-color4)",\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\
  "--text-dropdown-hover--fontType": "italic",\
  "--text-dropdown-hover--fontSize--desktop": "18px",\
  "--text-dropdown-hover--fontSize--tablet": "18px",\
  "--text-dropdown-hover--fontSize--mobile": "18px",\
\
  "--radio-normal--primaryColor": "var(--palette-color0)",\
  "--radio-normal--borderColor": "var(--palette-color3)",\
  "--radio-normal--shadowColor": "var(--greyscale3)",\
  "--text-radio-normal--color": "var(--palette-color4)",\
  "--text-radio-normal--fontFamily": "var(--font1)",\
  "--text-radio-normal--fontType": "regular",\
  "--text-radio-normal--fontSize--desktop": "22px",\
  "--text-radio-normal--fontSize--tablet": "20px",\
  "--text-radio-normal--fontSize--mobile": "20px",\
\
  "--radio-selected--primaryColor": "var(--palette-color0)",\
  "--radio-selected--borderColor": "var(--palette-color4)",\
  "--radio-selected--shadowColor": "var(--greyscale3)",\
  "--text-radio-selected--color": "var(--palette-color4)",\
  "--text-radio-selected--fontFamily": "var(--font1)",\
  "--text-radio-selected--fontType": "regular",\
  "--text-radio-selected--fontSize--desktop": "22px",\
  "--text-radio-selected--fontSize--tablet": "20px",\
  "--text-radio-selected--fontSize--mobile": "20px",\
\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-checked--fontType": "regular",\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\
\
  "--radio-hover--primaryColor": "var(--palette-color0)",\
  "--radio-hover--borderColor": "var(--palette-color3)",\
  "--radio-hover--shadowColor": "var(--greyscale3)",\
  "--text-radio-hover--color": "var(--palette-color5)",\
  "--text-radio-hover--fontFamily": "var(--font1)",\
  "--text-radio-hover--fontType": "regular",\
  "--text-radio-hover--fontSize--desktop": "22px",\
  "--text-radio-hover--fontSize--tablet": "20px",\
  "--text-radio-hover--fontSize--mobile": "20px",\
\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-unchecked--fontType": "regular",\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--video_preset-color": "#666666",\
  "--video_preset-borderColor": "#666666",\
  \
  "--clickbox-preset-fill-color": "#3F80E4",\
\
  "--drag-object-default-state-fill-color": "255, 255, 255",\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drag-object-default-state-border-color": "214, 213, 209",\
  "--drag-object-hover-state-border-color": "214, 213, 209",\
  "--drag-object-transition-state-border-color": "214, 213, 209",\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\
\
  "--drop-object-default-state-fill-color": "255, 255, 255",\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drop-object-default-state-border-color": "42, 49, 62",\
  "--drop-object-hover-state-border-color": "230, 132, 80",\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\
}',
uic_presets:'{\
  "cp_button_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 1,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "--button-selected--shadowColor",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-visited--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style": {\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "#707070",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_hover": {\
    "fill": "#9ec4f3",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--black)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_selected": {\
    "fill": "var(--palette-color5)",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_visited": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_disabled": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_active": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-active--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-active--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-active--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_focusLost": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-focusLost--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-focusLost--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-focusLost--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_error": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-error--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-error--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-error--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 14,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.78\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "video_preset_style": {\
    "fillEnable": 0,\
    "strokeEnable": 0,\
    "shadowEnable": 0,\
    "fill": "var(--video_preset-color)",\
    "fillOpacity": 1,\
    "stroke": "var(--video_preset-border)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_comment_box_shape_1_solid_style": {\
    "fill": "#F2B807",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clickbox_shape_solid_style": {\
    "fill": "var(--clickbox-preset-fill-color)",\
    "fillOpacity": 0.6,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "2, 3",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#333333",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#000000",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#D6D5D1",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clicktoreveal_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#ffffff",\
    "fillOpacity": 1,\
    "stroke": "#ffffff",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 3,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color7)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color8)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_blue": {\
    "fill": "#ADD8E6",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:1,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
slideAudios:'StAd1,StAd3,StAd4',
vestr:0,
vim:0,
slides:'Slide1292,Slide460,Slide577,Slide694,Slide731,Slide845,Slide882,Slide926,Slide963,Slide1007,Slide1088,Slide1205',
slideVideos:['si919','si1000'],
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Blank 1","type":"slide","parentId":null,"id":"Slide1292","isVisible":true,"slideVisited":false,"originalId":1292,"labelShouldBeInSync":true},{"label":"Simulation slide 1","type":"slide","parentId":null,"id":"Slide460","isVisible":true,"slideVisited":false,"originalId":460,"labelShouldBeInSync":true},{"label":"Simulation slide 2","type":"slide","parentId":null,"id":"Slide577","isVisible":true,"slideVisited":false,"originalId":577,"labelShouldBeInSync":true},{"label":"Simulation slide 3","type":"slide","parentId":null,"id":"Slide694","isVisible":true,"slideVisited":false,"originalId":694,"labelShouldBeInSync":true},{"label":"Simulation slide 4","type":"slide","parentId":null,"id":"Slide731","isVisible":true,"slideVisited":false,"originalId":731,"labelShouldBeInSync":true},{"label":"Simulation slide 5","type":"slide","parentId":null,"id":"Slide845","isVisible":true,"slideVisited":false,"originalId":845,"labelShouldBeInSync":true},{"label":"Simulation slide 6","type":"slide","parentId":null,"id":"Slide882","isVisible":true,"slideVisited":false,"originalId":882,"labelShouldBeInSync":true},{"label":"Simulation slide 7","type":"slide","parentId":null,"id":"Slide926","isVisible":true,"slideVisited":false,"originalId":926,"labelShouldBeInSync":true},{"label":"Simulation slide 8","type":"slide","parentId":null,"id":"Slide963","isVisible":true,"slideVisited":false,"originalId":963,"labelShouldBeInSync":true},{"label":"Simulation slide 9","type":"slide","parentId":null,"id":"Slide1007","isVisible":true,"slideVisited":false,"originalId":1007,"labelShouldBeInSync":true},{"label":"Simulation slide 11","type":"slide","parentId":null,"id":"Slide1088","isVisible":true,"slideVisited":false,"originalId":1088,"labelShouldBeInSync":true},{"label":"Simulation slide 12","type":"slide","parentId":null,"id":"Slide1205","isVisible":true,"slideVisited":false,"originalId":1205,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":true,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:1292,
text:['""']
}
,{
link:460,
text:['""']
}
,{
link:577,
text:['""']
}
,{
link:694,
text:['""']
}
,{
link:731,
text:['""']
}
,{
link:845,
text:['""']
}
,{
link:882,
text:['""']
}
,{
link:926,
text:['""']
}
,{
link:963,
text:['""']
}
,{
link:1007,
text:['""']
}
,{
link:1088,
text:['""']
}
,{
link:1205,
text:['""']
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/01041.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01122.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01239.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02082.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0494.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0611.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0728.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0879.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0915.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0960.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0996.png',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
'vr/Vi908.mp4',
'vr/Vi989.mp4'
];
cp.model.tocVideos=[
];
cp.model.audios=[
'ar/Mouse.mp3',
'ar/StAd0.mp3',
'ar/StAd2.mp3',
'ar/2241.mp3'
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',12,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
cp.cv('variableEditBoxNum_1','',0,15,0);
cp.cv('variableEditBoxStr_1','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,variableEditBoxNum_1,variableEditBoxStr_1,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
